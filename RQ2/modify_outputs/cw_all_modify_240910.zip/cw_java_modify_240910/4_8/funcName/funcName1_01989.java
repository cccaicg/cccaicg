/**
	 * Shuts down the ServiceLocator and releases any used resources.
	 */
public synchronized void Shutdown()
{