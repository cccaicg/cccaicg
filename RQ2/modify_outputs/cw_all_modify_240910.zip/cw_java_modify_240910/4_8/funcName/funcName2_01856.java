/**
 * Set the negative button text and it's listener
 * @param negativeButtonText
 * @param listener
 * @return
 */
public Builder set_negative_button(String negativeButtonText,
        DialogInterface.OnClickListener listener)
{