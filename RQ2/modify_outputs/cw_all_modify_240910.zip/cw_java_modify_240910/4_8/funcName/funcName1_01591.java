/**
 * Converts all separators to the Windows separator of backslash.
 * 
 * @param path
 *            the path to be changed, null ignored
 * @return the updated path
 */
public static String SeparatorsToWindows(String path)
{