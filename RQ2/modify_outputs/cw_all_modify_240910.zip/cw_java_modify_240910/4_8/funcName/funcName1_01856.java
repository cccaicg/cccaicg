/**
 * Set the negative button text and it's listener
 * @param negativeButtonText
 * @param listener
 * @return
 */
public Builder SetNegativeButton(String negativeButtonText,
        DialogInterface.OnClickListener listener)
{