/**
 * Transforms all path delimiters to use the Windows backslash separator.
 * 
 * @param path
 *            the path to modify, null values are ignored
 * @return the modified path
 */
public static String separatorsToWindows(String path)
{