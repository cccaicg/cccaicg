/**
 * Assign text and set a listener for the negative button
 * @param negativeButtonText
 * @param listener
 * @return
 */
public Builder setNegativeButton(String negativeButtonText,
        DialogInterface.OnClickListener listener)
{