/**
 * Set up the shake event listener
 * @param threshold
 * 			the least amount of acceleration change to detect shaking
 * @param interval
 * 			the shortest time span between consecutive shake events
 */
public static void configure(int threshold, int interval)
{