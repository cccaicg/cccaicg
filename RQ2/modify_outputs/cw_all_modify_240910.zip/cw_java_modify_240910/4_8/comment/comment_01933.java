/**
 * Sets up the Activity when it is initially created. You must at least
 * invoke {@link android.app.Activity#setContentView setContentView()} to
 * define what will appear on the screen.
 */
@Override
	protected void onCreate(Bundle savedInstanceState)
{