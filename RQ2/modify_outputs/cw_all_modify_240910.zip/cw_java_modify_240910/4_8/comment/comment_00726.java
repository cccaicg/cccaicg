// Retrieve a list of all planets belonging to the active player. By convention, player number 1 is always considered the active player.
public List<Planet> MyPlanets()
{