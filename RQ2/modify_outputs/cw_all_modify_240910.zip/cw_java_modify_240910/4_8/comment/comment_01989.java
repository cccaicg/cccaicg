/**
	 * Deactivates the ServiceLocator and frees all allocated resources.
	 */
public synchronized void shutdown()
{