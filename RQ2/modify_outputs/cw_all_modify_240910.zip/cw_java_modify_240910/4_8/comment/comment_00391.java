/**
 * Enable this by setting to true if you want TestRun to display details of 
 * successful property tests, in addition to those that fail. Example usage:
 * 
 * <pre>new TestRun().setVerbose(true).runOn(SomeInvariants.class, 1000);</pre>
 */
public TestRun setVerbose(boolean b)
{