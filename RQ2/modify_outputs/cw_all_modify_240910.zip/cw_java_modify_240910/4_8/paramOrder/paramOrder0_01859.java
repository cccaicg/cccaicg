/**
 * Configure the listener for shaking
 * @param interval
 * 			minimum interval between to shake events
 * @param threshold
 * 			minimum acceleration variation for considering shaking
 */
public static void configure(int interval, int threshold)
{