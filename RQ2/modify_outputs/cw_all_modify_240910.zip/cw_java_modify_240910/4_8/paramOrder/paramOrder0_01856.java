/**
 * Set the negative button text and it's listener
 * @param listener
 * @param negativeButtonText
 * @return
 */
public Builder setNegativeButton(DialogInterface.OnClickListener listener, String negativeButtonText)
{