/**
 * Set the negative button text and it's listener
 * @param negative_button_text
 * @param listener
 * @return
 */
public Builder setNegativeButton(String negative_button_text,
        DialogInterface.OnClickListener listener)
{