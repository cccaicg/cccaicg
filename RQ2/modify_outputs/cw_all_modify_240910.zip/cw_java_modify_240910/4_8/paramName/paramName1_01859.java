/**
 * Configure the listener for shaking
 * @param Threshold
 * 			minimum acceleration variation for considering shaking
 * @param Interval
 * 			minimum Interval between to shake events
 */
public static void configure(int Threshold, int Interval)
{