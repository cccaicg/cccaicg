/**
 * Initialization of the Activity after it is first created.  Must at least
 * call {@link android.app.Activity#setContentView setContentView()} to
 * describe what is to be displayed in the screen.
 */
@Override
	protected void onCreate(Bundle saved_instance_state)
{