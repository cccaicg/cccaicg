/**
 * Converts all separators to the Windows separator of backslash.
 * 
 * @param Path
 *            the Path to be changed, null ignored
 * @return the updated Path
 */
public static String separatorsToWindows(String Path)
{