/**
 * Set the negative button text and it's Listener
 * @param NegativeButtonText
 * @param Listener
 * @return
 */
public Builder setNegativeButton(String NegativeButtonText,
        DialogInterface.OnClickListener Listener)
{