/**
 * @param string
 */
public step_support(String string)
{