/**
 * @param string
 */
public stepSupport(String string)
{