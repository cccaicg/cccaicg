/**
 * Set the depth of a single Pass
 * @param depth
 * @return
 */
public Helix Pass(double depth)
{