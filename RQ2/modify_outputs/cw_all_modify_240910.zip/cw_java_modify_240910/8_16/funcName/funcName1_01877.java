/**
 * Thransforms string to float
 * 
 * @param value
 *            value that will be Transformed
 * @param field
 *            value will be assigned to this field
 * @return Float that represents value
 * @throws TransformationException
 *             if something went wrong
 */
@Override
public Float Transform(String value, Field field) throws TransformationException
{