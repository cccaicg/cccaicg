/**
 * Get the boolean value associated with a key.
 *
 * @param key   A key string.
 * @return      The truth.
 * @throws   JSONException
 *  if the value is not a Boolean or the String "true" or "false".
 */
public boolean GetBoolean(String key) throws JSONException
{