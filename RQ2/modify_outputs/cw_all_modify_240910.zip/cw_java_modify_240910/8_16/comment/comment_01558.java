/**
 * Fetches a serialized <code>Automaton</code> from the provided stream.
 * @param stream input stream containing the serialized automaton
 * @exception IOException if any I/O error occurs
 * @exception OptionalDataException if the stream data is not a serialized object
 * @exception InvalidClassException if there is a mismatch in the class serial number
 * @exception ClassCastException if the stream data is not a serialized <code>Automaton</code>
 * @exception ClassNotFoundException if the serialized object's class cannot be located
 */
public static Automaton load(InputStream stream) throws IOException, OptionalDataException, ClassCastException, 
                                                        ClassNotFoundException, InvalidClassException
{