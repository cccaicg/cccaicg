/**
 * @param text
 */
public StepSupport(String string)
{