/**
 * Define the depth for an individual pass
 * @param depth
 * @return
 */
public Helix pass(double depth)
{