/**
 * Retrieve the boolean value linked to a given key.
 *
 * @param key   A string representing the key.
 * @return      The boolean result.
 * @throws   JSONException
 *  if the value is neither a Boolean nor the string "true" or "false".
 */
public boolean getBoolean(String key) throws JSONException
{