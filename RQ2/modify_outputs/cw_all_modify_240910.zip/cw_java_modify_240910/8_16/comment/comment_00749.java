/**
 * @return the last marked position, or -1 if a mark has not been established.
 *
 * @throws IllegalStateException if invoked when automatic marking is turned off.
 */
public int getMarkedPosition()
{