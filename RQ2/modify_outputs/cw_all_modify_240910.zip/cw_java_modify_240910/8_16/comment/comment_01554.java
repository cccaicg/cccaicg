/**
 * Toggles the allow mutate flag on or off.
 * When this flag is enabled, any automata operations can alter the input automata;
 * if disabled, operations will keep input automata languages unchanged.
 * The default state of the flag is disabled.
 * @param flag if true, the flag will be enabled
 * @return the flag's prior value
 */
static public boolean setAllowMutate(boolean flag)
{