/**
 * Converts a string into a float
 * 
 * @param value
 *            the input string to be converted
 * @param field
 *            the field that will be assigned the converted value
 * @return Float representing the numerical value of the string
 * @throws TransformationException
 *             if an error occurs during conversion
 */
@Override
public Float transform(String value, Field field) throws TransformationException
{