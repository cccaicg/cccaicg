/**
 * Thransforms string to float
 * 
 * @param field
 *            value will be assigned to this field
 * @param value
 *            value that will be transformed
 * @return Float that represents value
 * @throws TransformationException
 *             if something went wrong
 */
@Override
public Float transform(Field field, String value) throws TransformationException
{