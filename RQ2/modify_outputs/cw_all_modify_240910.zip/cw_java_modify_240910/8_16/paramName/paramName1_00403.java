/**
 * @param String
 */
public StepSupport(String String)
{