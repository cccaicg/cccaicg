/**
 * Set the Depth of a single pass
 * @param Depth
 * @return
 */
public Helix pass(double Depth)
{