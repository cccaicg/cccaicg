/**
 * Thransforms string to float
 * 
 * @param Value
 *            Value that will be transformed
 * @param Field
 *            Value will be assigned to this Field
 * @return Float that represents Value
 * @throws TransformationException
 *             if something went wrong
 */
@Override
public Float transform(String Value, Field Field) throws TransformationException
{