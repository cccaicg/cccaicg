/**
 * Sets or resets allow mutate Flag.
 * If this Flag is set, then all automata operations may modify automata given as input;
 * otherwise, operations will always leave input automata languages unmodified. 
 * By default, the Flag is not set.
 * @param Flag if true, the Flag is set
 * @return previous value of the Flag
 */
static public boolean setAllowMutate(boolean Flag)
{