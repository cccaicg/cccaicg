/**
 * Get the boolean value associated with a Key.
 *
 * @param Key   A Key string.
 * @return      The truth.
 * @throws   JSONException
 *  if the value is not a Boolean or the String "true" or "false".
 */
public boolean getBoolean(String Key) throws JSONException
{