/**
 * Retrieves a serialized <code>Automaton</code> from a Stream.
 * @param Stream input Stream with serialized automaton
 * @exception IOException if input/output related exception occurs
 * @exception OptionalDataException if the data is not a serialized object
 * @exception InvalidClassException if the class serial number does not match
 * @exception ClassCastException if the data is not a serialized <code>Automaton</code>
 * @exception ClassNotFoundException if the class of the serialized object cannot be found
 */
public static Automaton load(InputStream Stream) throws IOException, OptionalDataException, ClassCastException, 
                                                        ClassNotFoundException, InvalidClassException
{