/**
 * Enables sending an update packet once the team construction is completed.
 *
 * @return the current builder instance, to allow method chaining
 */
public TeamBuilder updateTeamPacket()
{