/**
 * Animate the modification of text size
 */
public static void updateTextSize(final TextView textView, float fromSize, float toSize)
{