/**
 * @return Potential cause of failure, provided {@link #isSuccess()} returns false
 * @throws IllegalStateException when {@link #isSuccess()} returns true
 */
public Optional<Throwable> getError()
{