/**
 * Define the input stream for the serialized byte data of this record collection.
 *
 * @param in
 *          input stream
 * @return builder
 */
public Builder setInputStream(InputStream in)
{