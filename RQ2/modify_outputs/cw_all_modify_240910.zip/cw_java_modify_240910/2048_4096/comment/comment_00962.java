// Manually terminate the connection to the database
public void releaseConn()
{