// Action to open the camera
@Override
    protected void onSaveInstanceState(Bundle outState)
{