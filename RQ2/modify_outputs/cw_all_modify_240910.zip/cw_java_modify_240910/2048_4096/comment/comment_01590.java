/**
 * Determines whether the error activity should display the button for error details.
 * Set to true to reveal the full stack trace and device information,
 * or false to keep it concealed.
 * True is the default setting.
 */
@NonNull
public Builder showErrorDetails(boolean showErrorDetails)
{