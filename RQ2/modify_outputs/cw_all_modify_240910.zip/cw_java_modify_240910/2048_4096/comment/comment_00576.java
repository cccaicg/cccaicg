/**
 * Define the color for the checked state border
 *
 * @param strokeCheckedColor
 * @return
 */
public T setStrokeCheckedColor(int strokeCheckedColor)
{