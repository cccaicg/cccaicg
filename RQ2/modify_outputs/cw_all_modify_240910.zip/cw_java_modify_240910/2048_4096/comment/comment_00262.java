/**
 * Generates a string composed of random digits with a specified length
 *
 * @param length
 *            desired string length
 * @return random string
 */
public static String captchaNumber(int length)
{