/**
 * Assigns a listener for state change upon selection
 *
 * @param listener
 * @return
 */
public T setOnSelectedChangeListener(OnSelectedChangeListener listener)
{