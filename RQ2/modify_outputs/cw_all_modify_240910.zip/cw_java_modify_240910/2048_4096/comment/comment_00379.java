//Retrieve the height of the status bar
public static int getStatusBarHeight(Context context)
{