/**
 * Location within the Namespace.
 *
 * @param uri
 *          the URI for the namespace location.
 * @see DistributedLogNamespace
 * @return a builder for the namespace.
 */
public DistributedLogNamespaceBuilder uri(URI uri)
{