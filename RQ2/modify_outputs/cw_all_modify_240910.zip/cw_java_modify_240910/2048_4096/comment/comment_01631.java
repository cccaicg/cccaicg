/**
 * Determines whether the preview feature is enabled
 * @param preview
 * @return
 */
public Builder setEnablePreview(boolean preview)
{