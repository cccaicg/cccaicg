/**
 * Establishes the required duration between application failures to decide if a crash loop is not occurring.
 * Should a crash happen within this specified interval, the error activity will not initiate, 
 * instead, the system crash screen will be triggered. Default set to 3000.
 */
@NonNull
public Builder minTimeBetweenCrashesMs(int minTimeBetweenCrashesMs)
{