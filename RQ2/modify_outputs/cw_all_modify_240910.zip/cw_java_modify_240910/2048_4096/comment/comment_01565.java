/**
 * Inform the DraggableListener that the view has been closed towards the left
 */
private void notifyCloseToLeftListener()
{