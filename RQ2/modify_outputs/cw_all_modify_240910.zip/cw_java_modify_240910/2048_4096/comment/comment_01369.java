/**
 * Centralized thread processing
 * @param <T>
 * @return
 */
public static <T> FlowableTransformer<T, T> rxSchedulerHelper()
{