/**
 * Specifies the drawable resource for the default error activity image.
 * Adjust this if you prefer an alternative image to the default.
 * By default, it uses R.drawable.customactivityoncrash_error_image (a charming upside-down bug).
 */
@NonNull
public Builder errorDrawable(@Nullable @DrawableRes Integer errorDrawable)
{