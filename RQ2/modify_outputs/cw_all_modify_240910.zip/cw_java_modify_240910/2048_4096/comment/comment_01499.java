/** configure color for title underline (配置标题下划线颜色) */
public NormalDialog titleLineColor(int titleLineColor)
{