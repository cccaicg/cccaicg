/**
 * Assigns the primary activity class that should be started by the error activity after a crash event.
 * In the absence of a specified value or if assigned null, the standard launch activity will be utilized.
 * If no launch activities exist in your app and this is unspecified, the default error activity will terminate.
 */
@NonNull
public Builder restartActivity(@Nullable Class<? extends Activity> restartActivityClass)
{