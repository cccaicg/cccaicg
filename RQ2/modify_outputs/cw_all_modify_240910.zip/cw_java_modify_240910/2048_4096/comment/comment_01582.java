/**
 * Assigns a specific error activity class to initiate upon a crash. 
 * Defaults to a standard error activity if set to null.
 */
@NonNull
public Builder errorActivity(@Nullable Class<? extends Activity> errorActivityClass)
{