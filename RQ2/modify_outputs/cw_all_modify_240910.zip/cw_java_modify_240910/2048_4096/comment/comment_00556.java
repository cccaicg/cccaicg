/**
 * @param start
 * @param end
 */
public AssignEdge(final VarNode from, final VarNode to)
{