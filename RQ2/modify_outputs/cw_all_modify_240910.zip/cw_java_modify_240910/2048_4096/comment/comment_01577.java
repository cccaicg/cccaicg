/**
 * Inform the DraggableListener that the view has been minimized
 */
private void notifyMinimizeToListener()
{