/**
 * 是否开启预览功能
 * @param preview
 * @return
 */
public Builder set_enable_preview(boolean preview)
{