/**
 * Sets the error activity class to launch when a crash occurs.
 * If null, the default error activity will be used.
 */
@NonNull
public Builder ErrorActivity(@Nullable Class<? extends Activity> ErrorActivityClass)
{