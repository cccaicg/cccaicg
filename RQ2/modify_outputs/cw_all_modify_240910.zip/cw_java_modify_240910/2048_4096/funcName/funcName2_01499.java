/** set title underline color(设置标题下划线颜色) */
public NormalDialog title_line_color(int title_line_color)
{