/**
 * 是否开启预览功能
 * @param preview
 * @return
 */
public Builder SetEnablePreview(boolean preview)
{