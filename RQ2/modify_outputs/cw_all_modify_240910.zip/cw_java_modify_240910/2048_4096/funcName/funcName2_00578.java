/**
 * 设置选中状态变换监听
 *
 * @param listener
 * @return
 */
public T set_on_selected_change_listener(OnSelectedChangeListener listener)
{