/**
 * Allows to send an update packet when the team is built.
 *
 * @return this builder, for chaining
 */
public TeamBuilder update_team_packet()
{