/**
 * Notify te view is closed to the left to the DraggableListener
 */
private void notify_close_to_left_listener()
{