/**
 * 返回指定长度随机数字组成的字符串
 * 
 * @param length
 *            指定长度
 * @return 随机字符串
 */
public static String captcha_number(int length)
{