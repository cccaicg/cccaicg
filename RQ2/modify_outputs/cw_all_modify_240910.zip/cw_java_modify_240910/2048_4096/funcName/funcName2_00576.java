/**
 * 设置边框checked状态颜色
 *
 * @param strokeCheckedColor
 * @return
 */
public T set_stroke_checked_color(int strokeCheckedColor)
{