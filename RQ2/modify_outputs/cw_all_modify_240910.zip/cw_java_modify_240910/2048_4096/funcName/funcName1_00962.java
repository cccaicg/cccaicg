//主动结束和数据库的连接
public void ReleaseConn()
{