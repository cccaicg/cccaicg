/**
 * Update text size with animation
 */
public static void UpdateTextSize(final TextView textView, float fromSize, float toSize)
{