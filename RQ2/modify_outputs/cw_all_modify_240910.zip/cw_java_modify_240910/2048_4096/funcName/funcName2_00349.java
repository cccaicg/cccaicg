/**
 * Update text size with animation
 */
public static void update_text_size(final TextView textView, float fromSize, float toSize)
{