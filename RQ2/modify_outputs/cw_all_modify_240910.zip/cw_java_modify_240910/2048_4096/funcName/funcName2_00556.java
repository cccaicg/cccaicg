/**
 * @param from
 * @param to
 */
public assign_edge(final VarNode from, final VarNode to)
{