/**
 * Notify te view is minimized to the DraggableListener
 */
private void notify_minimize_to_listener()
{