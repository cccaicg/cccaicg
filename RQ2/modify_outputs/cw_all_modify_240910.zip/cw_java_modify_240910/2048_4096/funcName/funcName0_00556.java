/**
 * @param from
 * @param to
 */
public assignEdge(final VarNode from, final VarNode to)
{