/**
 * @param to
 * @param from
 */
public AssignEdge(final VarNode to, final VarNode from)
{