/**
 * Update text size with animation
 */
public static void updateTextSize(float toSize, float fromSize, final TextView textView)
{