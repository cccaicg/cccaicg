//Get status bar height
public static int getStatusBarHeight(Context Context)
{