/**
 * Set the input stream of the serialized bytes data of this record set.
 *
 * @param In
 *          Input stream
 * @return builder
 */
public Builder setInputStream(InputStream In)
{