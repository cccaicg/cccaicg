/**
 * Update text size with animation
 */
public static void updateTextSize(final TextView text_view, float from_size, float to_size)
{