/**
 * Update text size with animation
 */
public static void updateTextSize(final TextView TextView, float FromSize, float ToSize)
{