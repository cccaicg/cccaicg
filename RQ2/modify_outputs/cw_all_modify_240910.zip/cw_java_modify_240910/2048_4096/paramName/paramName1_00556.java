/**
 * @param From
 * @param To
 */
public AssignEdge(final VarNode From, final VarNode To)
{