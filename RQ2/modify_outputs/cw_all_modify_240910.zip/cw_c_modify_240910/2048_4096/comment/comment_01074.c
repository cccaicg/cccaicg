/* Establish a universal callback to obtain the handle
 * return 0 if successful */
int wolfSSL_SetHandleCb(wolfSSL_DSP_Handle_cb in)
{