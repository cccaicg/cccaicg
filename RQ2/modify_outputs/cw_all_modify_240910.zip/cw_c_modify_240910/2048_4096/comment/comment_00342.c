/**
  * @brief Perform the FMC_ISPCMD_READ operation to retrieve a word from flash memory.
  * @param[in]  u32Addr The address in flash memory to read.
  *             Ensure the address is word-aligned.
  * @return The word-sized data obtained from the given flash memory address.
  */
uint32_t FMC_Read(uint32_t u32Addr)
{