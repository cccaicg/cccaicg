// Coordinates for the first point (x1, y1)
// Coordinates for the second point (x2, y2)
void LCD_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2)
{