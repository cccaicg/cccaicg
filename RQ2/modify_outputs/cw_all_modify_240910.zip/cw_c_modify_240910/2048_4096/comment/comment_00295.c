```c
/*
** Flag all prepared statements linked to a database connection as invalid.
**
** An invalid statement suggests that the statement should be recompiled.
** Statements become invalidated when events occur that render their
** programs outdated. Such events include the removal of user-defined
** functions or collation sequences, or modifications to an authorization
** function, which can lead to prepared statements becoming outdated.
*/
```
SQLITE_PRIVATE void sqlite3ExpirePreparedStatements(sqlite3 *db)
{