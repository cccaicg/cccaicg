```c
/*
 * Auxiliary functions for calculating gradient-dot-residual vectors (1D to 4D).
 * Be aware that these generate gradients exceeding unit length. To closely
 * align with the value range of traditional Perlin noise, it's necessary to
 * rescale the final noise outputs. For a statistical match with RenderMan noise,
 * the approximate scaling factors (derived from empirical test renderings) are:
 * 1D noise requires a scaling factor of 0.188
 * 2D noise requires a scaling factor of 0.507
 * 3D noise requires a scaling factor of 0.936
 * 4D noise requires a scaling factor of 0.87
 * These noise functions represent the most effective and useful signed
 * version of Perlin noise. To produce values following the RenderMan
 * specification as in the SL noise() and pnoise() functions, the noise
 * outputs must be scaled and shifted to the range [0,1], like this:
 * float SLnoise = (noise3(x,y,z) + 1.0) * 0.5;
 */
```
float grad1( int hash, float x )
{