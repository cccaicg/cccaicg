//
//X1,Y1:
//X2,Y2:յ
void LCD_DrawLine(u16 X1, u16 Y1, u16 X2, u16 Y2)
{