//
//x_1,y_1:
//x_2,y_2:յ
void LCD_DrawLine(u16 x_1, u16 y_1, u16 x_2, u16 y_2)
{