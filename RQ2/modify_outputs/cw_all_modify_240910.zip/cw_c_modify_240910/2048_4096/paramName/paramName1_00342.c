/**
  * @brief Execute FMC_ISPCMD_READ command to read a word from flash.
  * @param[in]  U32Addr Address of the flash location to be read.
  *             It must be a word aligned address.
  * @return The word data read from specified flash address.
  */
uint32_t FMC_Read(uint32_t U32Addr)
{