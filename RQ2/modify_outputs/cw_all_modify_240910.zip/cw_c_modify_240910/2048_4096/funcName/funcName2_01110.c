//
//x1,y1:
//x2,y2:յ
void l_c_d__draw_line(u16 x1, u16 y1, u16 x2, u16 y2)
{