/* Set global callback for getting handle to use
 * return 0 on success */
int WolfSSLSetHandleCb(wolfSSL_DSP_Handle_cb in)
{