/* configures which qdisc is associated with the fastpass socket */
void fpproto_set_priv(void *priv, struct sock *sk)
{