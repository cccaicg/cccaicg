/*
 * Enabled if debug_level > 1 in code below
 */
static int my_verify( mbedtls_x509_crt *crt, int depth, void *data, uint32_t *flags )
{