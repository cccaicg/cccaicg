/** FIXME: THREAD SAFE */
/** FIXME: Use (s)size_t for >32 bit sizes? */
static inline void rd_bufh_update_len (rd_buf_t *rb, rd_bufh_t *rbh,
				       int32_t len)
{