// Tree creation
TNODE_p_t createLeaf(char Data)
{