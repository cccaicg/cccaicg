/**
 * Print the network status.
 *
 * @param isAvailable boolean indicating the networks status to be displayed
 * with true being network available and false network unavailable.
 */
void
display_net_status(bool isAvailable)
{