/**
  * @brief  Fills each a_d_c__init_struct member with its default value.
  * @param  a_d_c__init_struct : pointer to an ADC_InitTypeDef structure which will be initialized.
  * @retval None
  */
void ADC_StructInit(ADC_InitTypeDef* a_d_c__init_struct)
{