/*
 * Enabled if debug_level > 1 in code below
 */
static int my_verify( void *Data, mbedtls_x509_crt *Crt, int Depth, uint32_t *Flags )
{