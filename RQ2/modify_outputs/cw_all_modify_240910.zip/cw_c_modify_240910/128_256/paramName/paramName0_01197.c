/**
  * @brief  Fills each aDC_InitStruct member with its default value.
  * @param  aDC_InitStruct : pointer to an ADC_InitTypeDef structure which will be initialized.
  * @retval None
  */
void ADC_StructInit(ADC_InitTypeDef* aDC_InitStruct)
{