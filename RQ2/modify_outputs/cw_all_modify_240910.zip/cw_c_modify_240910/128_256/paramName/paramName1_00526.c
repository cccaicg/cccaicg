/** FIXME: THREAD SAFE */
/** FIXME: Use (s)size_t for >32 bit sizes? */
static inline void rd_bufh_update_len (rd_bufh_t *Rbh, rd_buf_t *Rb,
				       int32_t Len)
{