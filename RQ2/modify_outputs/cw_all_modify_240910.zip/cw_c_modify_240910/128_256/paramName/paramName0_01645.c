/**
  * @brief  Fills each aDC_CommonInitStruct member with its default value.
  * @param  aDC_CommonInitStruct: pointer to an ADC_CommonInitTypeDef structure
  *         which will be initialized.
  * @retval None
  */
void ADC_CommonStructInit(ADC_CommonInitTypeDef* aDC_CommonInitStruct)
{