/**
  * @brief  Fills each a_d_c__common_init_struct member with its default value.
  * @param  a_d_c__common_init_struct: pointer to an ADC_CommonInitTypeDef structure
  *         which will be initialized.
  * @retval None
  */
void ADC_CommonStructInit(ADC_CommonInitTypeDef* a_d_c__common_init_struct)
{