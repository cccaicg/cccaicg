/**
 * Returns the size of physical memory (RAM) in bytes.
 */
size_t GetMemorySize( )
{