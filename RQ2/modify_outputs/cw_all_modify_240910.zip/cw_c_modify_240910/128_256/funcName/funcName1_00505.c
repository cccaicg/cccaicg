/* configures which qdisc is associated with the fastpass socket */
void FpprotoSetPriv(struct sock *sk, void *priv)
{