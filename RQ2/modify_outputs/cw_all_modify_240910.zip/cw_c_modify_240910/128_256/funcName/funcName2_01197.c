/**
  * @brief  Fills each ADC_InitStruct member with its default value.
  * @param  ADC_InitStruct : pointer to an ADC_InitTypeDef structure which will be initialized.
  * @retval None
  */
void a_d_c__struct_init(ADC_InitTypeDef* ADC_InitStruct)
{