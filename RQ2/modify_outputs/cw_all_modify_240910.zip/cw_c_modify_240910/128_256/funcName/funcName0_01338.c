/*
 * Free global mutexes
 */
void mbedtlsThreadingFreeAlt( void )
{