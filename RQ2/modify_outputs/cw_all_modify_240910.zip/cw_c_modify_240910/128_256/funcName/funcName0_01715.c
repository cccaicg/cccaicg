/**@brief Clear bond information from persistent storage.
 */
static void deleteBonds(void)
{