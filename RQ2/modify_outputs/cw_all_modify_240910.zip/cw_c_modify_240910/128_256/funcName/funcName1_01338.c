/*
 * Free global mutexes
 */
void MbedtlsThreadingFreeAlt( void )
{