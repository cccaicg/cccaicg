/**
 * Print the network status.
 *
 * @param is_available boolean indicating the networks status to be displayed
 * with true being network available and false network unavailable.
 */
void
displayNetStatus(bool is_available)
{