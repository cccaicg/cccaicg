/* MSVC pre-VS2015 has broken snprintf/vsnprintf implementations which are incompatible with C99. */
int X264Snprintf( char *s, size_t n, const char *fmt, ... )
{