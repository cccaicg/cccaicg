/*
 * Enabled if debug_level > 1 in code below
 */
static int myVerify( void *data, mbedtls_x509_crt *crt, int depth, uint32_t *flags )
{