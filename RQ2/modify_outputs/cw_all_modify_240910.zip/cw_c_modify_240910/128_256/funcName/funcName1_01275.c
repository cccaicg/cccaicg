// Tree creation
TNODE_p_t CreateLeaf(char data)
{