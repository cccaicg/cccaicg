/**
  * @brief  Fills each ADC_CommonInitStruct member with its default value.
  * @param  ADC_CommonInitStruct: pointer to an ADC_CommonInitTypeDef structure
  *         which will be initialized.
  * @retval None
  */
void a_d_c__common_struct_init(ADC_CommonInitTypeDef* ADC_CommonInitStruct)
{