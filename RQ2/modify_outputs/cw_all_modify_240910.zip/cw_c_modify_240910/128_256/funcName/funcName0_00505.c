/* configures which qdisc is associated with the fastpass socket */
void fpprotoSetPriv(struct sock *sk, void *priv)
{