// Tree creation
TNODE_p_t create_leaf(char data)
{