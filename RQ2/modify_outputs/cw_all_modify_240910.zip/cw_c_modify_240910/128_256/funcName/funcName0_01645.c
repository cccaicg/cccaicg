/**
  * @brief  Fills each ADC_CommonInitStruct member with its default value.
  * @param  ADC_CommonInitStruct: pointer to an ADC_CommonInitTypeDef structure
  *         which will be initialized.
  * @retval None
  */
void aDC_CommonStructInit(ADC_CommonInitTypeDef* ADC_CommonInitStruct)
{