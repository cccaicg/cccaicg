/**
 * Formats int data into a buffer.
 */
static char *
formatIntData(char * buf, size_t buf_size, const char * desc, const char * units, int data, bool valid)
{