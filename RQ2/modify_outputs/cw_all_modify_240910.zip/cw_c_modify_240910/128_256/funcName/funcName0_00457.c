/*++
  Purpose:

    Set the caption of the window. For compatibility with SDL2 only.

  Parameters:

    [IN]  lpszCaption - the new caption of the window.

    [IN]  lpReserved - not used, for compatibility only.

  Return value:

    None.

--*/
VOID
sDL_WM_SetCaption(
   LPCSTR         lpszCaption,
   LPVOID         lpReserved
)
{