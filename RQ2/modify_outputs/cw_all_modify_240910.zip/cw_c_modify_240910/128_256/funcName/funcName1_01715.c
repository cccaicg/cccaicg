/**@brief Clear bond information from persistent storage.
 */
static void DeleteBonds(void)
{