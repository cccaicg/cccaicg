/**@brief Remove stored bond details from permanent memory.
 */
static void delete_bonds(void)
{