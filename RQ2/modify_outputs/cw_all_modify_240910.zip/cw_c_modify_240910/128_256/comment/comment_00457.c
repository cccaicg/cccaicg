```c
/*++
  Objective:

    Update the window's title. Intended solely for SDL2 compatibility.

  Arguments:

    [IN]  lpszCaption - specifies the window's updated title.

    [IN]  lpReserved - unused, included for compatibility purposes.

  Outcome:

    Void.

--*/
```
VOID
SDL_WM_SetCaption(
   LPCSTR         lpszCaption,
   LPVOID         lpReserved
)
{