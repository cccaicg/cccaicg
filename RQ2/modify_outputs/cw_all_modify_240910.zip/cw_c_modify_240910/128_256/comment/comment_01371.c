/*************************** Extra APIs Tailored for Free RTOS *****************/
/**
* @brief  Manages the increment of the tick counter
* @param  none.
* @retval none.
*/
void osSystickHandler(void)
{