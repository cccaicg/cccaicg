/**
  * @brief  Sets every ADC_InitStruct property to its standard default setting.
  * @param  ADC_InitStruct : pointer to an ADC_InitTypeDef structure destined for initialization.
  * @retval None
  */
void ADC_StructInit(ADC_InitTypeDef* ADC_InitStruct)
{