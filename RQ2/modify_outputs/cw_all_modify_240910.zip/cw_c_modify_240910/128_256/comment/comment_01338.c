// Release universal locks
void mbedtls_threading_free_alt( void )
{