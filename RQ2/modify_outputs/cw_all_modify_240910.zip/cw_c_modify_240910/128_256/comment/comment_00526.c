/** TODO: ENSURE THREAD SAFETY */
/** TODO: Consider (s)size_t for sizes exceeding 32 bits */
static inline void rd_bufh_update_len (rd_bufh_t *rbh, rd_buf_t *rb,
				       int32_t len)
{