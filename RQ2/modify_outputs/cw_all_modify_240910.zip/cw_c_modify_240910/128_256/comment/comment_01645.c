/**
  * @brief  Initializes each member of ADC_CommonInitStruct with default settings.
  * @param  ADC_CommonInitStruct: a pointer to an ADC_CommonInitTypeDef structure
  *         that will be set up.
  * @retval None
  */
void ADC_CommonStructInit(ADC_CommonInitTypeDef* ADC_CommonInitStruct)
{