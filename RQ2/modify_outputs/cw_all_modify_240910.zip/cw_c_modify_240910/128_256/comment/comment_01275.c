// Constructing the tree
TNODE_p_t createLeaf(char data)
{