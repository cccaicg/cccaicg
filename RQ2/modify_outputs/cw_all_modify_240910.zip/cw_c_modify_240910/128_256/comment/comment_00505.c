/* sets up the qdisc linked to the fastpass socket */
void fpproto_set_priv(struct sock *sk, void *priv)
{