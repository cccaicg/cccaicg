/**
  * @brief  Clears the specified calibration registers of the ADC.
  * @param  ADCx: x may be 1, 2, or 3 to identify the ADC peripheral.
  * @retval None
  */
void ADC_ResetCalibration(ADC_TypeDef* ADCx)
{