/* MSVC versions before VS2015 have faulty snprintf/vsnprintf implementations that don't comply with C99 standards. */
int x264_snprintf( char *s, size_t n, const char *fmt, ... )
{