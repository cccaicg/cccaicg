/**
 * Display the state of the network.
 *
 * @param is_available boolean that represents the network's condition to be shown,
 * where true means the network is accessible and false means it is not accessible.
 */
void
display_net_status(bool is_available)
{