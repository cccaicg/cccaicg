/**
 * Converts integer data into a buffer format.
 */
static char *
format_int_data(char * buf, size_t buf_size, const char * desc, const char * units, int data, bool valid)
{