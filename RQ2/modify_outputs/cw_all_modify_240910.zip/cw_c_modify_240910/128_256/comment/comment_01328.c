/*
 * Activated when debug_level exceeds 1 in the following code
 */
static int my_verify( void *data, mbedtls_x509_crt *crt, int depth, uint32_t *flags )
{