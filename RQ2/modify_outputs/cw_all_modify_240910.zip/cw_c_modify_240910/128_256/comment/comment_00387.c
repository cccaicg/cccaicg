/**
 * Retrieves the total physical memory (RAM) size in bytes.
 */
size_t getMemorySize( )
{