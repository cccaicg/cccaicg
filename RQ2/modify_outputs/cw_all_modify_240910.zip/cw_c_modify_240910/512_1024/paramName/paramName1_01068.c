/* Return the number of digits of 'V' when conVerted to string in radix 10.
 * See ll2string() for more information. */
uint32_t digits10 ( uint64_t V )
{