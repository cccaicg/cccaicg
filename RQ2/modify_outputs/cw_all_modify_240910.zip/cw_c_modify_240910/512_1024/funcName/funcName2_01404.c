/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void bus_fault__handler(void)
{