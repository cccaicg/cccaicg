/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void busFault_Handler(void)
{