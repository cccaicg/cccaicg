// prepare our transmission and keep the end for
// the next transmission as the delay between packets
// may prevent the de bruijn exploit from working
void do_tx()
{