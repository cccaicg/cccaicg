/**
  * @brief  Locks the FLASH Program Erase Controller.
  * @note   This function can be used for all STM32F10x devices.
  *         - For STM32F10X_XL devices this function Locks Bank1 and Bank2.
  *         - For all other devices it Locks Bank1 and it is equivalent 
  *           to f_l_a_s_h__lockBank1 function.
  * @param  None
  * @retval None
  */
void f_l_a_s_h__lock(void)
{