// Set up the current transmission and reserve the ending segment for the following transmission, because packet delays could hinder the de Bruijn sequence exploit.
void doTx()
{