/**
  * @brief This function manages Pre-fetch and memory access faults.
  */
void BusFault_Handler(void)
{