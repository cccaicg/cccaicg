/* Calculate and return the digit count of 'v' when it's converted to a string in base 10.
 * Refer to ll2string() for further details. */
uint32_t digits10 ( uint64_t v )
{