/**
  * @brief  Secures the FLASH Program Erase Controller.
  * @note   Applicable to all STM32F10x devices.
  *         - For STM32F10X_XL devices, both Bank1 and Bank2 are secured.
  *         - For other devices, this secures Bank1 and acts like the 
  *           FLASH_LockBank1 function.
  * @param  None
  * @retval None
  */
void FLASH_Lock(void)
{