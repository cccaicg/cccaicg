def diffText1(self, diffs):
    """Compute and return the source text (all equalities and deletions).
    
    Args:
      diffs: Array of diff tuples.
    
    Returns:
      Source text.
    """
    
