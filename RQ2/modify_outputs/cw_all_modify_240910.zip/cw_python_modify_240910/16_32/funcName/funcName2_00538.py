def append_frame_nr(self, filename, framenr):
    """Append the frame number to a file name.
    
    Returns the new file name.
    """
    
