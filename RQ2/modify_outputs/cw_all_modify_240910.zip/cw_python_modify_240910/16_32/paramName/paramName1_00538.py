def _appendFrameNr(Self, FileName, FrameNr):
    """Append the frame number to a file name.
    
    Returns the new file name.
    """
    
