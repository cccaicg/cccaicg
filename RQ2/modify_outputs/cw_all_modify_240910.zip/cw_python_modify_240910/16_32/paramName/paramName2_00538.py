def _appendFrameNr(self, file_name, frame_nr):
    """Append the frame number to a file name.
    
    Returns the new file name.
    """
    
