def diff_text1(Self, Diffs):
    """Compute and return the source text (all equalities and deletions).
    
    Args:
      Diffs: Array of diff tuples.
    
    Returns:
      Source text.
    """
    
