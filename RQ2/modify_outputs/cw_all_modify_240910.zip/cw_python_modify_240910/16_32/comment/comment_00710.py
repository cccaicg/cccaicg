def input_sequence(self, char_sequence):
    """Modifies the DFA's present state using a series of inputs."""
