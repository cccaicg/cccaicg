def _appendFrameNr(self, filename, framenr):
    """Add the frame number to the end of a file name.
    
    Returns the modified file name.
    """
