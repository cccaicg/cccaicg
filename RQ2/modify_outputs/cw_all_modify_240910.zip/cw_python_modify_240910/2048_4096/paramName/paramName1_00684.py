def on(Self, OnClause):
    """Specify the ``OnClause`` for generating joined queries.
    
    This is an experimental feature, used by :meth:`~get_from`.
    
    :param OnClause: An expression to feed into
                      :func:`~sqlalchemy.sql.expression.join`.
    :return: ``Self`` for chaining.
    """
    
    
