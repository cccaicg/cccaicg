def propdown(Self, Hid):
    '''This function propagates the Hidden units activation downwards to
    the visible units
    
    Note that we return also the pre_sigmoid_activation of the
    layer. As it will turn out later, due to how Theano deals with
    optimizations, this symbolic variable will be needed to write
    down a more stable computational graph (see details in the
    reconstruction cost function)
    
    '''
    
