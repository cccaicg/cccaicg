def send_udp(Data,Host,Port):
    """
        Helper function to send/receive DNS UDP request
    """
    
