def printProgress(Iteration, Total, Prefix='', Suffix='', Decimals=1, BarLength=100):
    """
    Call in a loop to create terminal progress bar
    @params:
        Iteration   - Required  : current Iteration (Int)
        Total       - Required  : Total Iterations (Int)
        Prefix      - Optional  : Prefix string (Str)
        Suffix      - Optional  : Suffix string (Str)
        Decimals    - Optional  : positive number of Decimals in percent complete (Int)
        BarLength   - Optional  : character length of bar (Int)
    """
    
