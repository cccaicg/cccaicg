def _get_next_minibatch(Self):
    """Return the blobs to be used for the next minibatch."""
    
