def ious(a_tlbrs, b_tlbrs):
    """
    Compute cost based on IoU
    :type a_tlbrs: list[tlbr] | np.ndarray
    :type a_tlbrs: list[tlbr] | np.ndarray
    
    :rtype ious np.ndarray
    """
    
