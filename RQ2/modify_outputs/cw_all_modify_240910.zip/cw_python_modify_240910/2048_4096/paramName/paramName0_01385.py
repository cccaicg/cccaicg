def build_inputs_with_special_tokens(self, tokenIds0, tokenIds1=None):
    """
    Build model inputs from a sequence or a pair of sequence for sequence classification tasks
    by concatenating and adding special tokens.
    A RoBERTa sequence has the following format:
        single sequence: <s> X </s>
        pair of sequences: <s> A </s></s> B </s>
    """
    
