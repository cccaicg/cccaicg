def im_list_to_blob(Ims):
    """Convert a list of images into a network input.
    
    Assumes images are already prepared (means subtracted, BGR order, ...).
    """
    
