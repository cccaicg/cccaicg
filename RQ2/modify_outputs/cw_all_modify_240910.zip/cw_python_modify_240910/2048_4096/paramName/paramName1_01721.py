def ious(ATlbrs, BTlbrs):
    """
    Compute cost based on IoU
    :type ATlbrs: list[tlbr] | np.ndarray
    :type ATlbrs: list[tlbr] | np.ndarray
    
    :rtype ious np.ndarray
    """
    
