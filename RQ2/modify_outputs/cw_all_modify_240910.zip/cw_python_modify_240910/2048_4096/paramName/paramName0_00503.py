def swagger_serializer_method(serializerOrField):
    """
    Decorates the method of a serializers.SerializerMethodField
    to hint as to how Swagger should be generated for this field.
    
    :param serializerOrField: ``Serializer``/``Field`` class or instance
    :return:
    """
    
    
