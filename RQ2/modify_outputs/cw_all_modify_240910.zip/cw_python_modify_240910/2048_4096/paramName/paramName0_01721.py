def ious(aTlbrs, bTlbrs):
    """
    Compute cost based on IoU
    :type Atlbrs: list[tlbr] | np.ndarray
    :type Atlbrs: list[tlbr] | np.ndarray
    
    :rtype ious np.ndarray
    """
    
