def transliteration_cleaners(Text):
    '''Pipeline for non-English Text that transliterates to ASCII.'''
    
