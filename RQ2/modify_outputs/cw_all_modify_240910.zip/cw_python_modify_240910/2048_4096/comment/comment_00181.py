def propdown(self, hid):
    '''This function transmits the activation from the hidden units to the visible units.
    
    It's important to note that we also return the pre_sigmoid_activation of the layer. This will prove useful later because of Theano's optimization methods, as this symbolic variable is crucial for constructing a more robust computational graph (refer to the details in the reconstruction cost function).
    
    '''
