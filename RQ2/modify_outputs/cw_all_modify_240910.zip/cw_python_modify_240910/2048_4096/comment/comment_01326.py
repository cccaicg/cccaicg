def _get_next_minibatch(self):
    """Get the blobs required for the upcoming minibatch."""
