def im_list_to_blob(ims):
    """
    Transform a collection of images into a format suitable for network input.
    
    It is assumed that images have been preprocessed (mean values removed, in BGR format, etc.).
    """
