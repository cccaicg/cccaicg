def get_stored_username():
    """Retrieve saved username if present."""
