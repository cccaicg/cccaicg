def find_odd_number(nums):
    """ Identify a single number in the array that is unique,
        or appears an odd number of times.
    """
