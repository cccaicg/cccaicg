def get_new_username():
    """Request input for a new username."""
