def build_inputs_with_special_tokens(self, token_ids_0, token_ids_1=None):
    ```python
    """
    Construct inputs for the model using a single sequence or a pair of sequences for tasks involving sequence classification,
    by joining sequences with special tokens.
    The format for a RoBERTa sequence is as follows:
        single sequence: <s> X </s>
        paired sequences: <s> A </s></s> B </s>
    """
    ```
