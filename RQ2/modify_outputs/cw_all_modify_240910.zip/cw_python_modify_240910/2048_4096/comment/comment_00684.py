def on(self, on_clause):
    ```python
    """Define the ``on_clause`` for creating joined queries.
    
    This feature is experimental and is utilized by :meth:`~get_from`.
    
    :param on_clause: An expression provided to
                      :func:`~sqlalchemy.sql.expression.join`.
    :return: Returns ``self`` to allow method chaining.
    """
    ```
