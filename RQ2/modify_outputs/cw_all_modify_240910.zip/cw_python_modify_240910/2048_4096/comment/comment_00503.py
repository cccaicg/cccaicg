def swagger_serializer_method(serializer_or_field):
    """
    Applies a decorator to a method of a `serializers.SerializerMethodField`
    to provide guidance for generating Swagger documentation for this field.
    
    :param serializer_or_field: Instance or class of ``Serializer``/``Field``
    :return:
    """
