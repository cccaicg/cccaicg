def ious(atlbrs, btlbrs):
    """
    Calculate the cost utilizing IoU
    :type atlbrs: list[tlbr] | np.ndarray
    :type atlbrs: list[tlbr] | np.ndarray
    
    :rtype ious np.ndarray
    """
