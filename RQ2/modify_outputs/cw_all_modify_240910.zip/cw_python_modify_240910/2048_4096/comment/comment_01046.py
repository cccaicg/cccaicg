def send_udp(data,host,port):
    """
        Utility function for handling DNS UDP communication
    """
