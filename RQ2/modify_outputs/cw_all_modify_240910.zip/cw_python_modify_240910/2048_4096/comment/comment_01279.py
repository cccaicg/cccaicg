def set_subword_regularization(self, nbest, alpha):
    """Configure parameters for subword regularization
    
    To learn more, visit the official SentencePiece repository:
    
    https://github.com/google/sentencepiece
    
    Parameters
    ----------
    nbest
    alpha
    
    Returns
    -------
    
    """
