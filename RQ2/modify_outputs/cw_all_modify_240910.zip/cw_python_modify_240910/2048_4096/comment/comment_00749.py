def transliteration_cleaners(text):
    '''Pipeline for handling non-English text by converting it to ASCII characters.'''
