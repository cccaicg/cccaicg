def printProgress(iteration, total, prefix='', suffix='', decimals=1, barLength=100):
    """
    Use within a loop to generate a progress bar in the terminal
    @params:
        iteration   - Required  : current step (Int)
        total       - Required  : total number of steps (Int)
        prefix      - Optional  : string shown before the progress bar (Str)
        suffix      - Optional  : string shown after the progress bar (Str)
        decimals    - Optional  : number of decimal places in percentage (Int)
        barLength   - Optional  : length of the progress bar in characters (Int)
    """
    
