def set_subword_regularization(self, alpha, nbest):
    """Set the subword-regularization parameters
    
    For more details, you may refer to the official SentencePiece library:
    
    https://github.com/google/sentencepiece
    
    Parameters
    ----------
    alpha
    nbest
    
    Returns
    -------
    
    """
    
