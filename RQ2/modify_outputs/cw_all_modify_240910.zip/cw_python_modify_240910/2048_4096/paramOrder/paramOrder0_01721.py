def ious(btlbrs, atlbrs):
    """
    Compute cost based on IoU
    :type atlbrs: list[tlbr] | np.ndarray
    :type atlbrs: list[tlbr] | np.ndarray
    
    :rtype ious np.ndarray
    """
    
