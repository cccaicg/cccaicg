def send_udp(port, host, data):
    """
        Helper function to send/receive DNS UDP request
    """
    
