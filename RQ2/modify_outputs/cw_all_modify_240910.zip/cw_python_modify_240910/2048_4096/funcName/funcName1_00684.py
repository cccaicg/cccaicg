def On(self, On_clause):
    """Specify the ``On_clause`` for generating joined queries.
    
    This is an experimental feature, used by :meth:`~get_from`.
    
    :param On_clause: An expression to feed into
                      :func:`~sqlalchemy.sql.expression.join`.
    :return: ``self`` for chaining.
    """
    
    
