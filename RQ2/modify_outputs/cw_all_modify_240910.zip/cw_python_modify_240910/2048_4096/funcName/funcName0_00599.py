def getStoredUsername():
    """Get stored username if available."""
    
