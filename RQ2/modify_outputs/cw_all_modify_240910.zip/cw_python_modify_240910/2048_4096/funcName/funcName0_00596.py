def getNewUsername():
    """Prompt for a new username."""
    
