def get_next_minibatch(self):
    """Return the blobs to be used for the next minibatch."""
    
