def setSubwordRegularization(self, nbest, alpha):
    """Set the subword-regularization parameters
    
    For more details, you may refer to the official SentencePiece library:
    
    https://github.com/google/sentencepiece
    
    Parameters
    ----------
    nbest
    alpha
    
    Returns
    -------
    
    """
    
