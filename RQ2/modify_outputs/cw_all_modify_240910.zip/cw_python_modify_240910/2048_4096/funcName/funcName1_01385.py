def BuildInputsWithSpecialTokens(self, token_ids_0, token_ids_1=None):
    """
    Build model inputs from a sequence or a pair of sequence for sequence classification tasks
    by concatenating and adding special tokens.
    A RoBERTa sequence has the following format:
        single sequence: <s> X </s>
        pair of sequences: <s> A </s></s> B </s>
    """
    
