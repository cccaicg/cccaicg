def ImListToBlob(ims):
    """Convert a list of images into a network input.
    
    Assumes images are already prepared (means subtracted, BGR order, ...).
    """
    
