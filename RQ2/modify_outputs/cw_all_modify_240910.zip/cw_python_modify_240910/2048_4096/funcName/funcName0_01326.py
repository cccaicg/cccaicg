def getNextMinibatch(self):
    """Return the blobs to be used for the next minibatch."""
    
