def SwaggerSerializerMethod(serializer_or_field):
    """
    Decorates the method of a serializers.SerializerMethodField
    to hint as to how Swagger should be generated for this field.
    
    :param serializer_or_field: ``Serializer``/``Field`` class or instance
    :return:
    """
    
    
