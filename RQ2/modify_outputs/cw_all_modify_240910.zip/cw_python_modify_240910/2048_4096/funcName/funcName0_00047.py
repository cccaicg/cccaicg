def findOddNumber(nums):
    """ Find one number in array which is not duplicated,
        or exsits odd times.
    """
    
