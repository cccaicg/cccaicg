def SendUdp(data,host,port):
    """
        Helper function to send/receive DNS UDP request
    """
    
