def GetNewUsername():
    """Prompt for a new username."""
    
