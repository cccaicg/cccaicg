def choose(k, n):
    """
    A fast way to calculate binomial coefficients by Andrew Dalke (contrib).
    """
    
