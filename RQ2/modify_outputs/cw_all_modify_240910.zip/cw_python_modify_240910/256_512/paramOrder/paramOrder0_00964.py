def __init__(self, basesearch, searchprovider, startpage, timeout, savesearch, filename, verboseactive, maxperpage, maxpages):
    """Define variables and show options on run."""
    
