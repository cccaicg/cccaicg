def _load_paths(self, traverses, paths):
    """ @brief Stores paths and traverses then refreshes canvas
        @details Should only be called from main thread
    """
    
