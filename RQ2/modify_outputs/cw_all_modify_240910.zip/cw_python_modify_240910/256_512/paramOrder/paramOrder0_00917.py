def triggerAfter(timeout, f):
    """call 'f' after timeout seconds"""
    
