def __init__(self, basesearch, searchprovider, maxperpage, maxpages, startpage, timeout, savesearch, filename, verboseactive):
    """Initialize variables and display options at execution."""
