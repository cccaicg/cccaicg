def triggerAfter(f, timeout):
    """invoke 'f' following a delay of timeout seconds"""
