def choose(n, k):
    """
    An efficient method for computing binomial coefficients, contributed by Andrew Dalke.
    """
