def swapEvaluator(newEvaluator):
    """Replace the evaluator, and return the previous one for potential restoration later"""
