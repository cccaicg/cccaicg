def direction(self):
    """An instance of :class:`constants.Direction`
    
    This attribute signifies the orientation the actor is currently in.
    It is modifiable and can be assigned a new value.
    
    Raises:
        AttributeError: In case the `walkabout` property is missing on the instance.
        TypeError: If there is an attempt to remove this property
    
    """
