def pil2imgdata(img, format='PNG'):
    """transform a PIL Image into PNG byte format"""
