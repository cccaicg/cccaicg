def read_images_from_disk(input_queue):
    """Takes a single filename along with a label formatted as a string separated by spaces.
    Args:
      filename_and_label_tensor: A single string tensor.
    Returns:
      A pair of tensors: the image that is decoded, and the label as a string.
    """
