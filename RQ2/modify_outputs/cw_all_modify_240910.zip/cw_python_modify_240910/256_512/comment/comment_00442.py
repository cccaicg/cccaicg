def ln(input, s, b, epsilon = 1e-5, max = 1000):
    """ Applies layer normalization to a 4D tensor across its second dimension, representing the batch """
    
