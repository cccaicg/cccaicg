def setdefaulttimeout(timeout):
    """
    Configure the global timeout duration for connections.
    
    timeout: specifies default socket timeout value in seconds.
    """
