def _load_paths(self, paths, traverses):
    """ @brief Manages path storage and navigation, then updates the canvas
        @details Must be invoked exclusively from the main thread
    """
