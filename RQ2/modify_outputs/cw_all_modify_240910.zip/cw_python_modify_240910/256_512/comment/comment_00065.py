def disable():
    """Turns off color output."""
