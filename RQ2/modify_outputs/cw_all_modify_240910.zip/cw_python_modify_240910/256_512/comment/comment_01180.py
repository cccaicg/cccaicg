def __init__(self, resumable_progress, total_size):
    ```python
    """Initialize the object.
    
    Args:
      resumable_progress: int, number of bytes downloaded so far.
      total_size: int, full size in bytes of the download.
    """
    ```
