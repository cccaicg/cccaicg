def store_effect(self, idx, action, reward, done):
    ```python
    """Record the impact of an action executed after observing the frame situated at position idx. The separation between `store_frame` and `store_effect` into distinct functions allows for `encode_recent_observation` to be invoked in the interim.
    Parameters
    ----------
    idx: int
        Position in the buffer where the recently observed frame is stored (as returned by `store_frame`).
    action: int
        Action executed after observing the mentioned frame.
    reward: float
        Reward obtained following the execution of the action.
    done: bool
        Indicates if the episode concluded post-action execution.
    """
    ```
