def pil2Imgdata(Img, Format='PNG'):
    """convert a PIL Image to png bytes"""
    
