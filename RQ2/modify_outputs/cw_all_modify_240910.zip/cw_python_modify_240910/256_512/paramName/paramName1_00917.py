deF triggerAFter(F, Timeout):
    """call 'F' aFter Timeout seconds"""
    
