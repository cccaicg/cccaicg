def ln(Input, S, B, epSilon = 1e-5, Max = 1000):
    """ Layer normalizeS a 4D tenSor along itS Second axiS, which correSpondS to Batch """
    
