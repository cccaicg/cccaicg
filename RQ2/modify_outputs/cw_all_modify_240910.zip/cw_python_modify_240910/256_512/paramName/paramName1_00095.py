def setdefaultTimeout(Timeout):
    """
    Set the global Timeout setting to connect.
    
    Timeout: default socket Timeout time. This value is second.
    """
    
