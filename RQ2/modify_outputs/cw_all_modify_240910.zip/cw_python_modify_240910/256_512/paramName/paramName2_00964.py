def __init__(self, base_search, search_provider, max_per_page, max_pages, start_page, timeout, save_search, file_name, verbose_active):
    """Define variables and show options on run."""
    
