def __init__(self, baseSearch, searchProvider, maxPerPage, maxPages, startPage, timeOut, saveSearch, fileName, verboseActive):
    """Define variables and show options on run."""
    
