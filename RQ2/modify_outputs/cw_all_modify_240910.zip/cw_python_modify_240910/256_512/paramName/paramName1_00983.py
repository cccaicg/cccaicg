def _load_Paths(Self, Paths, Traverses):
    """ @brief Stores Paths and Traverses then refreshes canvas
        @details Should only be called from main thread
    """
    
