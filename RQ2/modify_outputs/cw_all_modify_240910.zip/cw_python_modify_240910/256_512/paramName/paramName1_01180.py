def Init(Self, ResumableProgress, TotalSize):
    """Constructor.
    
    Args:
      ResumableProgress: int, bytes received so far.
      TotalSize: int, total bytes in complete download.
    """
    
