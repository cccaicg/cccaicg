def __init__(Self, BaseSearch, SearchProvider, MaxPerPage, MaxPages, StartPage, Timeout, SaveSearch, FileName, VerboseActive):
    """Define variables and show options on run."""
    
