def store_effect(Self, Idx, Action, Reward, Done):
    """Store effects of action taken after obeserving frame stored
    at index idx. The reason `store_frame` and `store_effect` is broken
    up into two functions is so that once can call `encode_recent_observation`
    in between.
    Paramters
    ---------
    Idx: int
        Index in buffer of recently observed frame (returned by `store_frame`).
    Action: int
        Action that was performed upon observing this frame.
    Reward: float
        Reward that was received when the actions was performed.
    Done: bool
        True if episode was finished after performing that action.
    """
    
