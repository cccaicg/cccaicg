def direction(Self):
    """An instance of :class:`constants.Direction`
    
    This property indicates the direction the actor is facing.
    Is it possible to set this property to a new value.
    
    Raises:
        AttributeError: If the instance has no `walkabout` property.
        TypeError: If one tries to delete this property
    
    """
    
    
