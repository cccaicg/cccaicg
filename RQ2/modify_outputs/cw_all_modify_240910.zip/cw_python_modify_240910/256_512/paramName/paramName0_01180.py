def init(self, resumableProgress, totalSize):
    """Constructor.
    
    Args:
      resumableProgress: int, bytes received so far.
      totalSize: int, total bytes in complete download.
    """
    
