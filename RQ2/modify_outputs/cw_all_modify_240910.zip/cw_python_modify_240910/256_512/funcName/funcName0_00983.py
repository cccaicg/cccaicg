def loadPaths(self, paths, traverses):
    """ @brief Stores paths and traverses then refreshes canvas
        @details Should only be called from main thread
    """
    
