def setDefaultTimeout(timeout):
    """
    Set the global timeout setting to connect.
    
    timeout: default socket timeout time. This value is second.
    """
    
