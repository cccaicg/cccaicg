def swap_evaluator(newEvaluator):
    """Swap out the evaluator. returns the old one, so it can be put back later"""
    
