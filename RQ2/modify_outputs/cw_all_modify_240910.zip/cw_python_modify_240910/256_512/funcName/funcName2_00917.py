def trigger_after(f, timeout):
    """call 'f' after timeout seconds"""
    
