def pil_2_img_data(img, format='PNG'):
    """convert a PIL Image to png bytes"""
    
