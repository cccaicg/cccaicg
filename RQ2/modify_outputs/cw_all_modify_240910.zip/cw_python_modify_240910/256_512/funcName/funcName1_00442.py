def Ln(input, s, b, epsilon = 1e-5, max = 1000):
    """ Layer normalizes a 4D tensor along its second axis, which corresponds to batch """
    
