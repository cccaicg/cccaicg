def TriggerAfter(f, timeout):
    """call 'f' after timeout seconds"""
    
