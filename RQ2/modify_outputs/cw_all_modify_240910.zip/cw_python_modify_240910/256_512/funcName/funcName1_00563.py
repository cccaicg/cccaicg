def Pil2ImgData(img, format='PNG'):
    """convert a PIL Image to png bytes"""
    
