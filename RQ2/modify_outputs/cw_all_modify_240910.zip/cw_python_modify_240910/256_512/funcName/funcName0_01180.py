def __init__(self, resumable_progress, total_size):
    """Constructor.
    
    Args:
      resumable_progress: int, bytes received so far.
      total_size: int, total bytes in complete download.
    """
    
