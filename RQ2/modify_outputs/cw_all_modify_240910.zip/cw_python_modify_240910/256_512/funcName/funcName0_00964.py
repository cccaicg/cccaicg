def init(self, basesearch, searchprovider, maxperpage, maxpages, startpage, timeout, savesearch, filename, verboseactive):
    """Define variables and show options on run."""
    
