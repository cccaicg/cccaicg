def Disable():
    """Disables colors."""
    
