/* CONFIG_RTW_MACADDR_ACL */
bool rtwIsPreLinkSta(struct sta_priv *stapriv, u8 *addr)
{