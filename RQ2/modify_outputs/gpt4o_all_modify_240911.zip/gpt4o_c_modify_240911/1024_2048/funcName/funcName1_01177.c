/* CONFIG_RTW_MACADDR_ACL */
bool RtwIsPreLinkSta(struct sta_priv *stapriv, u8 *addr)
{