/**
 * Set a sequencer event to be a timer event.
 * @param evt Sequencer event structure
 * @param data User supplied data pointer
 */
void
fluidEventTimer(fluid_event_t *evt, void *data)
{