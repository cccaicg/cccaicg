/**
 * Set a sequencer event to be a note on event.
 * @param evt Sequencer event structure
 * @param channel MIDI channel number
 * @param key MIDI note number (0-127)
 * @param vel MIDI velocity value (0-127)
 */
void
fluidEventNoteon(fluid_event_t *evt, int channel, short key, short vel)
{