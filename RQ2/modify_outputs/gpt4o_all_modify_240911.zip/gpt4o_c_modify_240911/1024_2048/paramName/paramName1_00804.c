/**
 * Set a sequencer event to be a MIDI Control change event.
 * @param evt Sequencer event structure
 * @param Channel MIDI Channel number
 * @param Control MIDI Control number (0-127)
 * @param Val MIDI Control Value (0-127)
 */
void
fluid_event_Control_change(fluid_event_t *Evt, int Channel, short Control, int Val)
{