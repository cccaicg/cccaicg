/**
 * Set a sequencer event to be a pitch wheel sensitivity event.
 * @param evt Sequencer event structure
 * @param Channel MIDI Channel number
 * @param Value MIDI pitch wheel sensitivity Value in semitones
 */
void
fluid_event_pitch_wheelsens(fluid_event_t *Evt, int Channel, int Value)
{