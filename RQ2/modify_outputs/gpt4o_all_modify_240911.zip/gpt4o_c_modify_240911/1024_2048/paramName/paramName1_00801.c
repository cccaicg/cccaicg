/**
 * Set a sequencer event to be a note on event.
 * @param evt Sequencer event structure
 * @param Channel MIDI Channel number
 * @param Key MIDI note number (0-127)
 * @param Vel MIDI Velocity value (0-127)
 */
void
fluid_event_noteon(fluid_event_t *Evt, int Channel, short Key, short Vel)
{