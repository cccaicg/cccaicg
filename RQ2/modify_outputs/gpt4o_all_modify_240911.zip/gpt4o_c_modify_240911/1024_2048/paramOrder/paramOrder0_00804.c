/**
 * Set a sequencer event to be a MIDI control change event.
 * @param channel MIDI channel number
 * @param control MIDI control number (0-127)
 * @param evt Sequencer event structure
 * @param val MIDI control value (0-127)
 */
void
fluid_event_control_change(int channel, short control, fluid_event_t *evt, int val)
{