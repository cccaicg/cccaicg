/**
 * Set a sequencer event to be a pitch wheel sensitivity event.
 * @param value MIDI pitch wheel sensitivity value in semitones
 * @param channel MIDI channel number
 * @param evt Sequencer event structure
 */
void
fluid_event_pitch_wheelsens(int value, int channel, fluid_event_t *evt)
{