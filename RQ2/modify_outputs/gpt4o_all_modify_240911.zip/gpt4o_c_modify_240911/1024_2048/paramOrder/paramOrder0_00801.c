/**
 * Set a sequencer event to be a note on event.
 * @param vel MIDI velocity value (0-127)
 * @param channel MIDI channel number
 * @param evt Sequencer event structure
 * @param key MIDI note number (0-127)
 */
void
fluid_event_noteon(short vel, int channel, fluid_event_t *evt, short key)
{