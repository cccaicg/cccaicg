/**
 * Set a sequencer event to be a timer event.
 * @param data User supplied data pointer
 * @param evt Sequencer event structure
 */
void
fluid_event_timer(void *data, fluid_event_t *evt)
{