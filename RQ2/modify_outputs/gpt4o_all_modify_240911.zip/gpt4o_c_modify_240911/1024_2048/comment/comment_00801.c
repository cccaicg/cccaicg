/**
 * Configure the sequencer event to function as a note-on event.
 * @param evt Structure for the sequencer event
 * @param channel Number for the MIDI channel
 * @param key Number representing the MIDI note (range 0-127)
 * @param vel Value representing the MIDI velocity (range 0-127)
 */
void
fluid_event_noteon(fluid_event_t *evt, int channel, short key, short vel)
{