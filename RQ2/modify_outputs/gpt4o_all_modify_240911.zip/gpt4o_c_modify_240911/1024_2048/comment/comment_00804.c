/**
 * Configure a sequencer event as a MIDI control change event.
 * @param evt The structure for the sequencer event
 * @param channel The MIDI channel identifier
 * @param control The MIDI control number (ranges from 0 to 127)
 * @param val The MIDI control value (ranges from 0 to 127)
 */
void
fluid_event_control_change(fluid_event_t *evt, int channel, short control, int val)
{