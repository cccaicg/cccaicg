/* MAC address access control configuration for RTW */
bool rtw_is_pre_link_sta(struct sta_priv *stapriv, u8 *addr)
{