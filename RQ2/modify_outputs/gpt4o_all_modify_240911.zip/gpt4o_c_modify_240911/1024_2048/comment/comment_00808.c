/**
 * Configure the sequencer event to handle a pitch wheel sensitivity event.
 * @param evt Structure for the sequencer event
 * @param channel Number representing the MIDI channel
 * @param value Semitones value for MIDI pitch wheel sensitivity
 */
void
fluid_event_pitch_wheelsens(fluid_event_t *evt, int channel, int value)
{