/**
 * Convert a sequencer event into a timer event.
 * @param evt The structure for the sequencer event
 * @param data Pointer to the user-provided data
 */
void
fluid_event_timer(fluid_event_t *evt, void *data)
{