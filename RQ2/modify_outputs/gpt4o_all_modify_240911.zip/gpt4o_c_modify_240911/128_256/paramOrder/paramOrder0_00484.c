/* в,eQĶͷԪ,OK,򷵻ERROR */
Status GetHead(QElemType *e, SqQueue Q)
{