/* Search and remove an element */
static int dictDelete(const void *key, dict *ht)
{