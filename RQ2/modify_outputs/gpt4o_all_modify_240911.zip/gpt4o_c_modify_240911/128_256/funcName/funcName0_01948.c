/**
 * briskDashEntryButtonClassInit:
 *
 * Handle class initialisation
 */
static void briskDashEntryButtonClassInit(BriskDashEntryButtonClass *klazz)
{