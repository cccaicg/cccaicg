/* в,eQĶͷԪ,OK,򷵻ERROR */
Status get_head(SqQueue Q,QElemType *e)
{