/* Search and remove an element */
static int DictDelete(dict *ht, const void *key)
{