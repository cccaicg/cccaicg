/**
  * @brief  Fills each USART_InitStruct member with its default value.
  * @param  USART_InitStruct: pointer to a USART_InitTypeDef structure which will
  *         be initialized.
  * @retval None
  */
void uSART_StructInit(USART_InitTypeDef* USART_InitStruct)
{