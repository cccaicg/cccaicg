/* в,eQĶͷԪ,OK,򷵻ERROR */
Status getHead(SqQueue Q,QElemType *e)
{