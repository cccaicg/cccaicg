/* input samplerate */
int
LameSetInSamplerate(lame_global_flags * gfp, int in_samplerate)
{