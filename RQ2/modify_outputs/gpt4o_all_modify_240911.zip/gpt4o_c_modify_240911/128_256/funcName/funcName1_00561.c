/*
 * -----------------------------------------------------------
 * The Idle task.
 * ----------------------------------------------------------
 *
 * The portTASK_FUNCTION() macro is used to allow port/compiler specific
 * language extensions.  The equivalent prototype for this function is:
 *
 * void PrvIdleTask( void *pvParameters );
 *
 */
static void PrvIdleTask(void *pvParameters)
{