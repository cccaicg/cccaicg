/* Search and remove an element */
static int dict_delete(dict *ht, const void *key)
{