/**@brief Function for initializing power management.
 */
static void powerManagementInit(void)
{