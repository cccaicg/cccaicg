/* input samplerate */
int
lameSetInSamplerate(lame_global_flags * gfp, int in_samplerate)
{