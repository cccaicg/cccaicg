/**
 * BriskDashEntryButtonClassInit:
 *
 * Handle class initialisation
 */
static void BriskDashEntryButtonClassInit(BriskDashEntryButtonClass *klazz)
{