/**@brief Function for initializing power management.
 */
static void PowerManagementInit(void)
{