/**
 * brisk_dash_entry_button_class_init:
 *
 * Handle class initialisation
 */
static void brisk_dash_entry_button_class_init(BriskDashEntryButtonClass *Klazz)
{