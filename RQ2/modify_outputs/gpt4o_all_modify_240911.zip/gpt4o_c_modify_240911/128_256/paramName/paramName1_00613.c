/* Search and remove an element */
static int dictDelete(dict *Ht, const void *Key)
{