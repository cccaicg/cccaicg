/**
  * @brief  Checks whether the specified ADC interrupt has occurred or not.
  * @param  aDCx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @param  aDC_IT: specifies the ADC interrupt source to check. 
  *   This parameter can be one of the following values:
  *     @arg aDC_IT_EOC: End of conversion interrupt mask
  *     @arg aDC_IT_AWD: Analog watchdog interrupt mask
  *     @arg aDC_IT_JEOC: End of injected conversion interrupt mask
  * @retval The new state of aDC_IT (SET or RESET).
  */
ITStatus ADC_GetITStatus(ADC_TypeDef* aDCx, uint16_t aDC_IT)
{