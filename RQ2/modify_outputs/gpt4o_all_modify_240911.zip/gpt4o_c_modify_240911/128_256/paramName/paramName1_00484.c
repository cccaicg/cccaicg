/* в,eQĶͷԪ,OK,򷵻ERROR */
Status GetHead(SqQueue Q,QElemType *E)
{