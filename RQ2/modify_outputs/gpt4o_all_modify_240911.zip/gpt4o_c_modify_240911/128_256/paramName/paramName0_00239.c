/**
  * @brief  Fills each uSART_InitStruct member with its default value.
  * @param  uSART_InitStruct: pointer to a USART_InitTypeDef structure which will
  *         be initialized.
  * @retval None
  */
void USART_StructInit(USART_InitTypeDef* uSART_InitStruct)
{