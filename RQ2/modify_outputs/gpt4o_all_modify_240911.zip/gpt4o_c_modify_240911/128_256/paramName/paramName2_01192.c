/**
  * @brief  Checks whether the specified ADC interrupt has occurred or not.
  * @param  a_d_cx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @param  a_d_c__i_t: specifies the ADC interrupt source to check. 
  *   This parameter can be one of the following values:
  *     @arg a_d_c__i_t_EOC: End of conversion interrupt mask
  *     @arg a_d_c__i_t_AWD: Analog watchdog interrupt mask
  *     @arg a_d_c__i_t_JEOC: End of injected conversion interrupt mask
  * @retval The new state of a_d_c__i_t (SET or RESET).
  */
ITStatus ADC_GetITStatus(ADC_TypeDef* a_d_cx, uint16_t a_d_c__i_t)
{