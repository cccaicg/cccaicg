/* в,eqĶͷԪ,OK,򷵻ERROR */
Status GetHead(Sqqueue q,qElemType *e)
{