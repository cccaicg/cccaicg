/**
  * @brief  Fills each u_s_a_r_t__init_struct member with its default value.
  * @param  u_s_a_r_t__init_struct: pointer to a USART_InitTypeDef structure which will
  *         be initialized.
  * @retval None
  */
void USART_StructInit(USART_InitTypeDef* u_s_a_r_t__init_struct)
{