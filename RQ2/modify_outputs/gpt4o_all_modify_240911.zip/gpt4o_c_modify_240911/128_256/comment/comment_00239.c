/**
  * @brief  Assigns default settings to every member of the USART_InitStruct.
  * @param  USART_InitStruct: pointer to a USART_InitTypeDef structure that is 
  *         to be set up.
  * @retval None
  */
void USART_StructInit(USART_InitTypeDef* USART_InitStruct)
{