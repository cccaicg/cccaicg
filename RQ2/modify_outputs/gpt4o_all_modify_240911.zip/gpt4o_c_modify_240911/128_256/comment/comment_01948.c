```c
/**
 * brisk_dash_entry_button_class_init:
 *
 * Manage the initialization of the class
 */
```
static void brisk_dash_entry_button_class_init(BriskDashEntryButtonClass *klazz)
{