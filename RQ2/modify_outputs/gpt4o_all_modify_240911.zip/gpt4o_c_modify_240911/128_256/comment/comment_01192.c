/**
  * @brief  Determines if a specific ADC interrupt has been triggered.
  * @param  ADCx: where x may be 1, 2, or 3 to select the relevant ADC peripheral.
  * @param  ADC_IT: identifies the ADC interrupt source to be checked. 
  *   This parameter can be one of the following values:
  *     @arg ADC_IT_EOC: Mask for end of conversion interrupt
  *     @arg ADC_IT_AWD: Mask for analog watchdog interrupt
  *     @arg ADC_IT_JEOC: Mask for end of injected conversion interrupt
  * @retval Returns the current status of ADC_IT (SET or RESET).
  */
ITStatus ADC_GetITStatus(ADC_TypeDef* ADCx, uint16_t ADC_IT)
{