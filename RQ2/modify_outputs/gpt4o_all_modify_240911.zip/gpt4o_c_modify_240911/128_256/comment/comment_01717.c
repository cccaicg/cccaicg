/**@brief Initializes power management functionality.
 */
static void power_management_init(void)
{