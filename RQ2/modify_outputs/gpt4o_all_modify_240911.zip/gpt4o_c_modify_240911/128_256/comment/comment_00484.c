/* Return OK or ERROR based on conditions */
Status GetHead(SqQueue Q,QElemType *e)
{