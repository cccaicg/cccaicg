/* Locate and delete a specific element */
static int dictDelete(dict *ht, const void *key)
{