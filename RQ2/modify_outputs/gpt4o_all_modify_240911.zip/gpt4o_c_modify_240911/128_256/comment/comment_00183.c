/**
  * @brief  Initialize each field of @ref LL_ADC_InitTypeDef with default settings.
  * @param  ADC_InitStruct Pointer to an @ref LL_ADC_InitTypeDef structure
  *                        where fields are initialized to default values.
  * @retval None
  */
void LL_ADC_StructInit(LL_ADC_InitTypeDef *ADC_InitStruct)
{