/* enter the sampling rate */
int
lame_set_in_samplerate(lame_global_flags * gfp, int in_samplerate)
{