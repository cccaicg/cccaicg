```c
/*
 * -----------------------------------------------------------
 * The Idle task functionality.
 * -----------------------------------------------------------
 *
 * The portTASK_FUNCTION() macro is utilized to support specific
 * port/compiler language extensions. The function prototype
 * is equivalently defined as:
 *
 * void prvIdleTask( void *pvParameters );
 *
 */
```
static void prvIdleTask(void *pvParameters)
{