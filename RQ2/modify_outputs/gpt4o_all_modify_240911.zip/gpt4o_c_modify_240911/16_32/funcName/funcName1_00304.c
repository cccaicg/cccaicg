/* Normally, IRQs 0 to 7 are mapped to entries 8 to 15.  This
 * is a problem in protected mode, because IDT entry 8 is a
 * Double Fault!  Without remapping, every time IRQ0 fires,
 * you get a Double Fault Exception, which is NOT actually
 * what's happening.  We send commands to the PIC in order to
 * make IRQ0 to 15 be remapped to IDT entries 32 to 47 */
void IrqRemap()
{