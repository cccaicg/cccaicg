/* Print an error message, plus a message for err and exit with error err */
void ErrExit(int err, char *fmt, ...)
{