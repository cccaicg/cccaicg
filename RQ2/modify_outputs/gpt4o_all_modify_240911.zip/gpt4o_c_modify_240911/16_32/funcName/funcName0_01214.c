/* Print an error message, plus a message for err and exit with error err */
void errExit(int err, char *fmt, ...)
{