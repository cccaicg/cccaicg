/* Display an error message along with the message for err, then terminate with error err */
void err_exit(int err, char *fmt, ...)
{