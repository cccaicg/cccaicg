/* Typically, IRQs 0 through 7 correspond to entries 8 through 15 in the IDT. 
 * This poses an issue in protected mode, as IDT entry 8 is reserved for a 
 * Double Fault. Without remapping, an IRQ0 trigger results in a Double Fault 
 * Exception, which is misleading. To resolve this, we issue commands to 
 * the PIC to remap IRQ0 to 15 to IDT entries 32 to 47. */
void irq_remap()
{