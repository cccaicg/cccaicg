def FixBoto():
    # Google Compute Engine instances install some Python-2-only boto plugins that
    # conflict with boto running under Python 3. Disable boto's default configuration
    # file prior to importing boto so that GCE's plugin is not loaded:
    
