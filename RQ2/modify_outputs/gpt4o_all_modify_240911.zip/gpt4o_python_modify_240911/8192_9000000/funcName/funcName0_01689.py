def init(self, data):
    """
    Inititates the variables data and h. h is a list of 5 8-digit Hexadecimal
    numbers corresponding to (1732584193, 4023233417, 2562383102, 271733878, 3285377520)
    respectively. We will start with this as a message digest. 0x is how you write
    Hexadecimal numbers in Python
    """
    
