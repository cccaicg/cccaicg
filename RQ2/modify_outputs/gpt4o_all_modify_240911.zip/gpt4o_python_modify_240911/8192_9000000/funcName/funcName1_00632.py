def OnResetStats():
    """
    Event handler that get triggered on click of web UI Reset Stats button
    """
    
