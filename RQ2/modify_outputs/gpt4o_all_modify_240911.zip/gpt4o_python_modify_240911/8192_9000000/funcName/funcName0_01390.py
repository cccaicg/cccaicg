def unknownMsg(self, msgfunc):
    '''Define message which will be used when unknown key was found
    
    “Unknown” is a key that was not provided at the initialization and via 
    :py:meth:`Spec.update` and did not match any ``keyfunc`` provided via 
    :py:meth:`Spec.unknown_spec`.
    
    :param msgfunc:
    	Function that takes that unknown key as an argument and returns the 
    	message text. Text will appear at the top (start of the sentence).
    
    :return: self.
    '''
    
