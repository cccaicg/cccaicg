def Init(self, width=0, height=0):
    """初始化方法"""
    
