def TestNounChunksIsParsedDe(de_tokenizer):
    """Test that noun_chunks raises Value Error for 'de' language if Doc is not parsed."""
    
