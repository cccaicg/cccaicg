def __init__(self, page_number, box, pos, box_info):
    """
    Construct the class
    :param self: ApDisplayInfo
    :param pos: position of the line in the ap selection page
    :param page_number: page number of the ap selection
    :param box: the curses.newwin.box object containing ap information
    :param key: the key user have keyed in
    :param box_info: list of window height, window len, and max row number
    :type self: ApDisplayInfo
    :type pos: int
    :type page_number: int
    :type box: curse.newwin.box
    :type key: str
    :return: None
    :rtype: None
    """
    
    
