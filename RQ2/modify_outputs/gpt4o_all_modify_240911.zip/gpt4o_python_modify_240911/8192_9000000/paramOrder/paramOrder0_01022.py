def __init__(self, height=0, width=0):
    """初始化方法"""
    
