def on_reset_stats():
    """
    Event handler activated upon clicking the Reset Stats button in the web UI
    """
