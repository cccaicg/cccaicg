def unknown_msg(self, msgfunc):
    '''Establish a message for instances when an unrecognized key is detected
    
    An "unrecognized" key is one that was neither given during initialization nor 
    added using :py:meth:`Spec.update`, and it also does not correspond to any 
    ``keyfunc`` defined with :py:meth:`Spec.unknown_spec`.
    
    :param msgfunc:
    	A function that accepts the unrecognized key as an input and outputs the 
    	message text. The text will be placed at the beginning (start of the sentence).
    
    :return: self.
    '''
