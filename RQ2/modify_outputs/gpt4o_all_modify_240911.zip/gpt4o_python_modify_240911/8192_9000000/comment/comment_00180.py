def test_noun_chunks_is_parsed_de(de_tokenizer):
    """Verify that noun_chunks throws a ValueError for the 'de' language when the Doc has not been parsed."""
