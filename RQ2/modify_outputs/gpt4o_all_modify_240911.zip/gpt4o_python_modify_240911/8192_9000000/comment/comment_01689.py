def __init__(self, data):
    ```python
    # Sets up the variables data and h. The variable h is initialized as a list of 5 hexadecimal numbers,
    # each 8 digits long, equivalent to (1732584193, 4023233417, 2562383102, 271733878, 3285377520). 
    # This will serve as an initial message digest. In Python, hexadecimal numbers are prefixed with 0x.
    ```
