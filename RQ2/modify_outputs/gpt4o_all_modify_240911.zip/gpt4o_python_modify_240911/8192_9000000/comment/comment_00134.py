def __init__(self, pos, page_number, box, box_info):
    ```python
    """
    Initialize the class
    :param self: Instance of ApDisplayInfo
    :param pos: Index of the line in the AP selection interface
    :param page_number: Current page number in the AP selection
    :param box: curses.newwin.box object that holds AP details
    :param key: Input from the user
    :param box_info: Contains window height, length, and maximum number of rows
    :type self: ApDisplayInfo
    :type pos: int
    :type page_number: int
    :type box: curses.newwin.box
    :type key: str
    :return: None
    :rtype: None
    """
    ```
