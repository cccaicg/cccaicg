def __init__(self, width=0, height=0):
    """Constructor Method"""
