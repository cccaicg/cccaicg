def __init__(Self, Width=0, Height=0):
    """初始化方法"""
    
