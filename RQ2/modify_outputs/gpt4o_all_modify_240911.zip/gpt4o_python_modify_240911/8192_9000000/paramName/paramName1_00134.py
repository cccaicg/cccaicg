def __init__(Self, Pos, PageNumber, Box, Box_info):
    """
    Construct the class
    :param Self: ApDisplayInfo
    :param Pos: Position of the line in the ap selection page
    :param PageNumber: page number of the ap selection
    :param Box: the curses.newwin.Box object containing ap information
    :param key: the key user have keyed in
    :param Box_info: list of window height, window len, and max row number
    :type Self: ApDisplayInfo
    :type Pos: int
    :type PageNumber: int
    :type Box: curse.newwin.Box
    :type key: str
    :return: None
    :rtype: None
    """
    
    
