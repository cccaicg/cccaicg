def test_noun_chunks_is_parsed_de(deTokenizer):
    """Test that noun_chunks raises Value Error for 'de' language if Doc is not parsed."""
    
