def __init__(self, pos, pageNumber, box, boxInfo):
    """
    Construct the class
    :param self: ApDisplayInfo
    :param pos: position of the line in the ap selection page
    :param pageNumber: page number of the ap selection
    :param box: the curses.newwin.box object containing ap information
    :param key: the key user have keyed in
    :param boxInfo: list of window height, window len, and max row number
    :type self: ApDisplayInfo
    :type pos: int
    :type pageNumber: int
    :type box: curse.newwin.box
    :type key: str
    :return: None
    :rtype: None
    """
    
    
