def ExtendRight(self, table):
    """Return None.
    Extend each row of `self` with corresponding row of `table`.
    Does **not** import formatting from ``table``.
    This generally makes sense only if the two tables have
    the same number of rows, but that is not enforced.
    :note: To extend append a table below, just use `extend`,
    which is the ordinary list method.  This generally makes sense
    only if the two tables have the same number of columns,
    but that is not enforced.
    """
    
