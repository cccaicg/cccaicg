def SetSelf(self, level, name):
    '''Sets the user access level and name'''
    
