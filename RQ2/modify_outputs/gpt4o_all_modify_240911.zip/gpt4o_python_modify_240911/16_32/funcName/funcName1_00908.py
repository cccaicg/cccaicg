def Init(self, parent, action) :
    """Saves a pointer to the parent object, and the method name."""
    
