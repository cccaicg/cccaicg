def InputSequence(self, char_sequence):
    """Updates the DFA's current state based on an iterable of inputs."""
    
