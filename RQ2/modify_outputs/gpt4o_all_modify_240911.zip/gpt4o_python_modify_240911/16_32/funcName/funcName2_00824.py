def set_self(self, level, name):
    '''Sets the user access level and name'''
    
