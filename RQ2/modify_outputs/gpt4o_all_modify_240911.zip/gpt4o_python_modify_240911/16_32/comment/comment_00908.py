def __init__(self, parent, action) :
    """Stores a reference to the parent object and the method name."""
