def extend_right(self, table):
    ```python
    """Return None.
    Add each row of the current instance with the matching row from `table`.
    Does **not** carry over formatting from ``table``.
    Typically, this is reasonable only when both tables contain
    the same number of rows, though there is no check for this.
    :note: To add a table beneath another, simply use `extend`,
    which is the standard list method. This is generally advisable
    only when both tables have the same number of columns,
    though this is not validated.
    """
    ```
