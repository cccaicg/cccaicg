def setSelf(self, level, name):
    '''Assign the access level and username for the user'''
