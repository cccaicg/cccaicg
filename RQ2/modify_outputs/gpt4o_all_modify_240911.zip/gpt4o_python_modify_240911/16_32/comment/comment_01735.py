def t_ID(t):
    # Prevent overwriting of reserved keywords with identifiers
