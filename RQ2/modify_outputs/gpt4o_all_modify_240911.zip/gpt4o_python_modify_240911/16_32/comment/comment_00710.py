def input_sequence(self, char_sequence):
    """Modifies the current state of the DFA using a sequence of inputs."""
