def setSelf(self, name, level):
    '''Sets the user access level and name'''
    
