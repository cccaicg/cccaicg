def Append(self, p, x):
    """Add an (x, p) pair to the end of this CDF.
    
    Note: this us normally used to build a CDF from scratch, not
    to modify existing CDFs.  It is up to the caller to make sure
    that the result is a legal CDF.
    """
    
