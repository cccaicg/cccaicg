def __init__(self, action, parent) :
    """Saves a pointer to the parent object, and the method name."""
    
