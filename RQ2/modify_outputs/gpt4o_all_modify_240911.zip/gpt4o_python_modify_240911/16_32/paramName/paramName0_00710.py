def input_sequence(self, charSequence):
    """Updates the DFA's current state based on an iterable of inputs."""
    
