def __init__(Self, Parent, Action) :
    """Saves a pointer to the Parent object, and the method name."""
    
