def extend_right(Self, Table):
    """Return None.
    Extend each row of `Self` with corresponding row of `Table`.
    Does **not** import formatting from ``Table``.
    This generally makes sense only if the two Tables have
    the same number of rows, but that is not enforced.
    :note: To extend append a Table below, just use `extend`,
    which is the ordinary list method.  This generally makes sense
    only if the two Tables have the same number of columns,
    but that is not enforced.
    """
    
