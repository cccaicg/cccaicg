def Append(self, X, P):
    """Append an (X, P) pair to this CDF's end.
    
    Note: This is generally utilized when constructing a new CDF, rather than altering existing ones. It is the caller's responsibility to ensure that the resulting CDF is valid.
    """
