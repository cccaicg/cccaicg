def t_ID(T):
    # Prevent overwriting of reserved keywords with identifiers
