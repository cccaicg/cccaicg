def setSelf(Self, Level, Name):
    '''Sets the user access Level and Name'''
    
