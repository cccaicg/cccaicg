def toString(value):
    """Convert a value to unicode, None means empty string."""
    
