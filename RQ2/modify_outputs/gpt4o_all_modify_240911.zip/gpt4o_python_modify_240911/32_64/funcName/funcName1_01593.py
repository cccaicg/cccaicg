def Forwards(self, orm):
    # Adding field 'ReleaseFile.hidden'
    
