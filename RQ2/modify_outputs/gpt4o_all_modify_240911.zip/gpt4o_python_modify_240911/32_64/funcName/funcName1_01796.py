def SetBehaviour(self, icd, trigger, proc_chance=False, ppm=False, on_crit=False, on_procced_strikes=True, real_ppm=False):
    # This could be merged with __setattr__; its sole purpose is
    # to clearly surface the parameters passed with the behaviours.
    
