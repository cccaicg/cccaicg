def binarySanityCheck(other):
    """\
    Check that the other argument to a binary operation is also a fuzzy
    graph, raising a TypeError otherwise.
    
    @param other: The other argument.
    @type other: L{FuzzyGraph}
    """
    
