def to_string(value):
    """Convert a value to unicode, None means empty string."""
    
