def disconnect(self):
    """Disconnect from a socket."""
    
