def Forwards(self, orm):
    # Adding field 'Wallet.transaction_counter'
    
