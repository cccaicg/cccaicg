def visitRepr(self, node):
    # XXX: python 2.6 only
    
