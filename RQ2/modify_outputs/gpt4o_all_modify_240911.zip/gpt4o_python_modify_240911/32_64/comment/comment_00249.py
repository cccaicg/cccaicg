def forwards(self, orm):
    # Introducing 'transaction_counter' field to Wallet
