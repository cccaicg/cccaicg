def forwards(self, orm):
    # Introduce 'hidden' attribute to ReleaseFile
