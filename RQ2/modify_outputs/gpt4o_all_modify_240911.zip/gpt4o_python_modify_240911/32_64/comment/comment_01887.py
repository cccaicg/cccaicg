def _binary_sanity_check(other):
    """\
    Ensure that the second operand in a binary operation is a fuzzy
    graph; raise a TypeError if it is not.
    
    @param other: The other operand.
    @type other: L{FuzzyGraph}
    """
