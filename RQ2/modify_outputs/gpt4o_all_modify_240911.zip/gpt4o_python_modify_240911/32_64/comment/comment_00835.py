def _to_string(value):
    """Transform a value to a unicode string, use an empty string if None."""
