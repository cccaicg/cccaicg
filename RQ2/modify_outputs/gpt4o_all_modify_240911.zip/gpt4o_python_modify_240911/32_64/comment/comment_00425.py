def visit_Repr(self, node):
    # NOTE: exclusive to Python 2.6
