def _disconnect(self):
    """Close the connection to a socket."""
