def SetXTwitterHeaders(self, client, url, version):
    '''Define the X-Twitter HTTP headers for transmission to the server.
    
    Args:
      client:
         A string representing the client's name. This will be transmitted to the server as
         the 'X-Twitter-Client' header.
      url:
         A string indicating the URL of the meta.xml. This will be transmitted to the server
         as the 'X-Twitter-Client-URL' header.
      version:
         A string representing the client's version. This will be transmitted to the server
         as the 'X-Twitter-Client-Version' header.
    '''
