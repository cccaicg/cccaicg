def _set_behaviour(self, icd, trigger, proc_chance=False, ppm=False, on_crit=False, on_procced_strikes=True, real_ppm=False):
    # This can be combined with __setattr__; it's specifically designed
    # to make the parameters and associated behaviors evident.
