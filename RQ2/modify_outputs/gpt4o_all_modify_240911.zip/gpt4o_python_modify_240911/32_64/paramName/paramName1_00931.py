def SetXTwitterHeaders(Self, Client, Url, Version):
    '''Set the X-Twitter HTTP headers that will be sent to the server.
    
    Args:
      Client:
         The Client name as a string.  Will be sent to the server as
         the 'X-Twitter-Client' header.
      Url:
         The URL of the meta.xml as a string.  Will be sent to the server
         as the 'X-Twitter-Client-URL' header.
      Version:
         The Client Version as a string.  Will be sent to the server
         as the 'X-Twitter-Client-Version' header.
    '''
    
