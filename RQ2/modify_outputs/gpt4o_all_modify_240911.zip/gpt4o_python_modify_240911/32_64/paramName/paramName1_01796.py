def _set_behaviour(Self, Icd, Trigger, ProcChance=False, Ppm=False, OnCrit=False, OnProccedStrikes=True, RealPpm=False):
    # This could be merged with __setattr__; its sole purpose is
    # to clearly surface the parameters passed with the behaviours.
    
