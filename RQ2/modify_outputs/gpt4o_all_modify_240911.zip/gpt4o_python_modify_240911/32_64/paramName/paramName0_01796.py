def _set_behaviour(self, icd, trigger, procChance=False, ppm=False, onCrit=False, onProccedStrikes=True, realPpm=False):
    # This could be merged with __setattr__; its sole purpose is
    # to clearly surface the parameters passed with the behaviours.
    
