def forwards(Self, Orm):
    # Adding field 'ReleaseFile.hidden'
    
