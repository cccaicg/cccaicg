def forwards(Self, Orm):
    # Adding field 'Wallet.transaction_counter'
    
