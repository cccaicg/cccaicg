def _to_string(Value):
    """Convert a Value to unicode, None means empty string."""
    
