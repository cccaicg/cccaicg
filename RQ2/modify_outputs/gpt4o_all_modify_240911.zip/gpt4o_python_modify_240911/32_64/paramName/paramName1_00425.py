def visit_Repr(Self, Node):
    # XXX: python 2.6 only
    
