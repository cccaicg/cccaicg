def _disconnect(Self):
    """Disconnect from a socket."""
    
