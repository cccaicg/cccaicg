def _binary_sanity_check(Other):
    """\
    Check that the Other argument to a binary operation is also a fuzzy
    graph, raising a TypeError Otherwise.
    
    @param Other: The Other argument.
    @type Other: L{FuzzyGraph}
    """
    
