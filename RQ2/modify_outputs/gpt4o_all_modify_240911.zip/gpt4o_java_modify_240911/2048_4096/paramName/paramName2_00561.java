/**
 * 设置虚线宽度
 *
 * @param stroke_dash_width
 * @return
 */
public T setStrokeDashWidth(float stroke_dash_width)
{