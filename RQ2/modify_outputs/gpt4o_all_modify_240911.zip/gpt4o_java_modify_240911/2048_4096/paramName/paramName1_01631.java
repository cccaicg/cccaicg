/**
 * 是否开启预览功能
 * @param Preview
 * @return
 */
public Builder setEnablePreview(boolean Preview)
{