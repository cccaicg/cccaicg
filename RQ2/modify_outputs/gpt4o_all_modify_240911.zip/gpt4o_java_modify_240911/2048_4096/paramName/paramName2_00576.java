/**
 * 设置边框checked状态颜色
 *
 * @param stroke_checked_color
 * @return
 */
public T setStrokeCheckedColor(int stroke_checked_color)
{