/**
 * 设置边框checked状态颜色
 *
 * @param StrokeCheckedColor
 * @return
 */
public T setStrokeCheckedColor(int StrokeCheckedColor)
{