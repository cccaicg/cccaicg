/**
 * 设置宽高相等
 *
 * @param Enable
 * @return
 */
public T setWidthHeightEqualEnable(boolean Enable)
{