/**
 * 设置边框线宽度(粗细)
 *
 * @param stroke_width
 * @return
 */
public T setStrokeWidth(int stroke_width)
{