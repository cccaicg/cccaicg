/**
 * 设置边框线selected状态颜色
 *
 * @param stroke_selected_color
 * @return
 */
public T setStrokeSelectedColor(int stroke_selected_color)
{