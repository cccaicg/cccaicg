/**
 * 设置边框线不可点击状态下颜色
 *
 * @param stroke_disabled_color
 * @return
 */
public T setStrokeDisabledColor(int stroke_disabled_color)
{