/**
 * lixx2100's post is cool:https://discuss.leetcode.com/topic/40162/three-line-java-solution
 * An easy recurrence for this problem is f[i] = f[i / 2] + i % 2
 * and then we'll use bit manipulation to express the above recursion function
 * right shift by 1 means to divide by 2
 * AND with 1 means to modulo 2
 * this is so cool!
 */
public int[] countBits(int Num)
{