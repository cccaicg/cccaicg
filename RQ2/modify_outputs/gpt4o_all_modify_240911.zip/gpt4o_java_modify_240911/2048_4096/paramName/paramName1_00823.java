/**
 * Client Id used for accessing the namespace
 *
 * @param ClientId
 *          client id used for accessing the namespace
 * @return namespace builder.
 */
public DistributedLogNamespaceBuilder ClientId(String ClientId)
{