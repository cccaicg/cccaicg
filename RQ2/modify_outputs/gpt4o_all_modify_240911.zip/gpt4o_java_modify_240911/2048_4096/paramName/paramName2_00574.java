/**
 * 设置边框线常态颜色
 *
 * @param stroke_color
 * @return
 */
public T setStrokeColor(int stroke_color)
{