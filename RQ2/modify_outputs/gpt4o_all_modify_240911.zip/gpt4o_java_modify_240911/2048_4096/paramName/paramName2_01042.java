/**
 * 添加一个正正则规则
 * @param positive_regex
 * @return 自身
 */
public RegexRule addPositive(String positive_regex)
{