/**
 * 设置选中状态变换监听
 *
 * @param Listener
 * @return
 */
public T setOnSelectedChangeListener(OnSelectedChangeListener Listener)
{