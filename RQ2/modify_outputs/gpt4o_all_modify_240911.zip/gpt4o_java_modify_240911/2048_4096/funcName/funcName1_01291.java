// Automatic generation with Eclipse
@Override
public int HashCode()
{