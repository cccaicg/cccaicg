//Get status bar height
public static int GetStatusBarHeight(Context context)
{