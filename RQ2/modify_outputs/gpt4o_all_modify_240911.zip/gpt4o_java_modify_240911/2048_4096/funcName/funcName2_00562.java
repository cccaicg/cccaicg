/**
 * 设置边框线selected状态颜色
 *
 * @param strokeSelectedColor
 * @return
 */
public T set_stroke_selected_color(int strokeSelectedColor)
{