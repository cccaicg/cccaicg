/**
 * 设置边框线常态颜色
 *
 * @param strokeColor
 * @return
 */
public T set_stroke_color(int strokeColor)
{