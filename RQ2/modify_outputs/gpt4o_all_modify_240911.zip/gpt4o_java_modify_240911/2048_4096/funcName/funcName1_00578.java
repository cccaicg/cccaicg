/**
 * 设置选中状态变换监听
 *
 * @param listener
 * @return
 */
public T SetOnSelectedChangeListener(OnSelectedChangeListener listener)
{