/**
 * 设置边框线宽度(粗细)
 *
 * @param strokeWidth
 * @return
 */
public T set_stroke_width(int strokeWidth)
{