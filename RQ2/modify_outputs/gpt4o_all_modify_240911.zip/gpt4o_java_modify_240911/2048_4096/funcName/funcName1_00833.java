/**
 * Stats Logger used for stats collection
 *
 * @param StatsLogger
 *          stats logger
 * @return namespace builder.
 */
public DistributedLogNamespaceBuilder StatsLogger(StatsLogger StatsLogger)
{