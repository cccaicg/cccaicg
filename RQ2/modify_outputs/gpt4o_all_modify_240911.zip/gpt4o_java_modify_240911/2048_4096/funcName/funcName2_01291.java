// Automatic generation with Eclipse
@Override
public int hash_code()
{