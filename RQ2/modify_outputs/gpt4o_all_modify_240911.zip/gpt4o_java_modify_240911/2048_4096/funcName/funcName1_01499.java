/** set title underline color(设置标题下划线颜色) */
public NormalDialog TitleLineColor(int TitleLineColor)
{