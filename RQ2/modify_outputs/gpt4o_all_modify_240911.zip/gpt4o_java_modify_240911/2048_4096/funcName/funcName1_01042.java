/**
 * 添加一个正正则规则
 * @param positiveregex
 * @return 自身
 */
public RegexRule AddPositive(String positiveregex)
{