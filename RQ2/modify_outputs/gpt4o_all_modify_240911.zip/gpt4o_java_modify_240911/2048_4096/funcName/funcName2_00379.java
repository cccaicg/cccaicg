//Get status bar height
public static int get_status_bar_height(Context context)
{