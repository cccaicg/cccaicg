/**
 * @return Connection, if {@link #isSuccess()} is true
 * @throws IllegalStateException if {@link #isSuccess()} is false
 */
public PeerConnection get_connection()
{