/**
 * 设置宽高相等
 *
 * @param enable
 * @return
 */
public T SetWidthHeightEqualEnable(boolean enable)
{