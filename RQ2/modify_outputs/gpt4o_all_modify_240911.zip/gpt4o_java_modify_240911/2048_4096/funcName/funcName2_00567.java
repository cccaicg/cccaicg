/**
 * 设置宽高相等
 *
 * @param enable
 * @return
 */
public T set_width_height_equal_enable(boolean enable)
{