/**
 * Client Id used for accessing the namespace
 *
 * @param client_id
 *          client id used for accessing the namespace
 * @return namespace builder.
 */
public DistributedLogNamespaceBuilder client_id(String client_id)
{