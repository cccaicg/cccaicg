/**
 * Notify te view is maximized to the DraggableListener
 */
private void NotifyMaximizeToListener()
{