/**
 * Notify te view is maximized to the DraggableListener
 */
private void notify_maximize_to_listener()
{