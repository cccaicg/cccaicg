/**
 * Stats Logger used for stats collection
 *
 * @param stats_logger
 *          stats logger
 * @return namespace builder.
 */
public DistributedLogNamespaceBuilder stats_logger(StatsLogger stats_logger)
{