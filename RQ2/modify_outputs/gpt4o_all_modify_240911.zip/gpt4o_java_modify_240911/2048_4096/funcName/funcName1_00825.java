/**
 * Namespace Location.
 *
 * @param Uri
 *          namespace location Uri.
 * @see DistributedLogNamespace
 * @return namespace builder.
 */
public DistributedLogNamespaceBuilder Uri(URI Uri)
{