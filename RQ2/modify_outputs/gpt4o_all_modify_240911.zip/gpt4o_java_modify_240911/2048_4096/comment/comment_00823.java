/**
 * Unique identifier for client to access the namespace
 *
 * @param clientId
 *          unique identifier for accessing the namespace
 * @return builder for namespace.
 */
public DistributedLogNamespaceBuilder clientId(String clientId)
{