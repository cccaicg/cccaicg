/**
 * Inform the DraggableListener that the view has been maximized
 */
private void notifyMaximizeToListener()
{