/**
 * Location of the Namespace.
 *
 * @param uri
 *          URI for the namespace location.
 * @see DistributedLogNamespace
 * @return builder for the namespace.
 */
public DistributedLogNamespaceBuilder uri(URI uri)
{