/**
 * Defines the border color for when the element is in a non-interactive state.
 *
 * @param strokeDisabledColor
 * @return
 */
public T setStrokeDisabledColor(int strokeDisabledColor)
{