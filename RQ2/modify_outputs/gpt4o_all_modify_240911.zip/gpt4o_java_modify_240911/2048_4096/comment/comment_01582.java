/**
 * Assigns a custom error activity class to be initiated when a crash happens.
 * If set to null, the default error activity will be triggered.
 */
@NonNull
public Builder errorActivity(@Nullable Class<? extends Activity> errorActivityClass)
{