/**
 * Stats Logger responsible for gathering statistics
 *
 * @param statsLogger
 *          the logger for statistics
 * @return builder for namespace.
 */
public DistributedLogNamespaceBuilder statsLogger(StatsLogger statsLogger)
{