/**
 * Assign the color for the border line when it is in a selected state.
 *
 * @param strokeSelectedColor
 * @return
 */
public T setStrokeSelectedColor(int strokeSelectedColor)
{