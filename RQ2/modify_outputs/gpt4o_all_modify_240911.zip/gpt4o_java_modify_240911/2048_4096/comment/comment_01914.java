/**
 * Check out lixx2100's awesome post: https://discuss.leetcode.com/topic/40162/three-line-java-solution
 * A simple recurrence relation for this problem is f[i] = f[i / 2] + i % 2
 * We can leverage bit manipulation to implement the recurrence relation
 * right shifting by 1 is equivalent to dividing by 2
 * AND operation with 1 is equivalent to taking modulo 2
 * this is really impressive!
 */
public int[] countBits(int num)
{