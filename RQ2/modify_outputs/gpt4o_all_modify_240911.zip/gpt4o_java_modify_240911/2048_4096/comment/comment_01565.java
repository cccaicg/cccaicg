/**
 * Alert the DraggableListener that the view has been closed by dragging to the left
 */
private void notifyCloseToLeftListener()
{