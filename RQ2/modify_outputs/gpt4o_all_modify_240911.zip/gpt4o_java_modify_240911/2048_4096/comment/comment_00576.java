/**
 * Assigns color to the border when checked
 *
 * @param strokeCheckedColor
 * @return
 */
public T setStrokeCheckedColor(int strokeCheckedColor)
{