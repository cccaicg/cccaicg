/**
 * 设置监听以监测选中状态的变化
 *
 * @param listener
 * @return
 */
public T setOnSelectedChangeListener(OnSelectedChangeListener listener)
{