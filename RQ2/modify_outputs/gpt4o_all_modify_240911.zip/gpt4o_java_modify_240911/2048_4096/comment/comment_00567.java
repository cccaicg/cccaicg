/**
 * Sets equal width and height
 *
 * @param enable
 * @return
 */
public T setWidthHeightEqualEnable(boolean enable)
{