/**
 * @return Connection, provided that {@link #isSuccess()} evaluates to true
 * @throws IllegalStateException when {@link #isSuccess()} evaluates to false
 */
public PeerConnection getConnection()
{