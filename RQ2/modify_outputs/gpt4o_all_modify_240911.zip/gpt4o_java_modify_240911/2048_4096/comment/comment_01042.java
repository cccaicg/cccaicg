/**
 * Adds a positive regular expression rule
 * @param positiveregex
 * @return itself
 */
public RegexRule addPositive(String positiveregex)
{