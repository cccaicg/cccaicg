/**
 * Sets the normal border line color
 *
 * @param strokeColor
 * @return
 */
public T setStrokeColor(int strokeColor)
{