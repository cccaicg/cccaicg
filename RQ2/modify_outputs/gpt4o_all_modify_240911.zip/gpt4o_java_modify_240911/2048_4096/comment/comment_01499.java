/** Configure the color of the title's underline (设置标题下划线的颜色) */
public NormalDialog titleLineColor(int titleLineColor)
{