/**
 * 指定边框的线条粗细
 *
 * @param strokeWidth
 * @return
 */
public T setStrokeWidth(int strokeWidth)
{