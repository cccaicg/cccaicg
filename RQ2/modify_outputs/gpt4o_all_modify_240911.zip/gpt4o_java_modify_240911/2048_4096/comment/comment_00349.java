/**
 * Animate the change in text size
 */
public static void updateTextSize(final TextView textView, float fromSize, float toSize)
{