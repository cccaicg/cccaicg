/**
 * Defines the primary activity class that the error activity should trigger upon a crash.
 * In the absence of a specified class or if it is set to null, the default launch activity is utilized.
 * Should your application lack any launch activities and this isn't defined, the default error activity will terminate itself.
 */
@NonNull
public Builder restartActivity(@Nullable Class<? extends Activity> restartActivityClass)
{