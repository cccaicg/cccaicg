/**
 * Converts a date string in the format yyyy-mm-dd HH:mm:ss to a Date object
 * @param dateString
 * @return
 * @throws Exception
 */
public static Date toDate(String dateString) throws Exception
{