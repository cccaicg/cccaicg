/**
 * Configure the background color for the pressed state
 *
 * @param color
 * @return
 */
public T setBackgroundPressedColor(int color)
{