/**
 * Configure the width of the dashed line
 *
 * @param strokeDashWidth
 * @return
 */
public T setStrokeDashWidth(float strokeDashWidth)
{