/**
 * Specifies the drawable for the default error activity's image.
 * Adjust this setting if a different image is desired instead of the standard one.
 * By default, R.drawable.customactivityoncrash_error_image is used (featuring an adorable upside-down bug).
 */
@NonNull
public Builder errorDrawable(@Nullable @DrawableRes Integer errorDrawable)
{