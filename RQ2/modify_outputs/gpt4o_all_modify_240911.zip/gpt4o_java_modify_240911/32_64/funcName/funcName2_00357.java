/**
 * @see {@link #enqueueDelete(byte[], Delete)}
 */
public void delete_column(byte[] table, byte[] row, byte[] cf, byte[] qualifier)
{