/**
 * Constructor
 * 
 * @param root
 *            The root element
 * @param dragMode
 *            The drag mode of the layout
 */
public v_layout_drag_drop_mouse_handler(Widget root, LayoutDragMode dragMode)
{