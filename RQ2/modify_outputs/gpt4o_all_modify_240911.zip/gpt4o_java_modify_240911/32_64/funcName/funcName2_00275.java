/**
 * Get the optional JSONArray associated with an index.
 * @param index subscript
 * @return      A JSONArray value, or null if the index has no value,
 * or if the value is not a JSONArray.
 */
public JSONArray opt_j_s_o_n_array(int index)
{