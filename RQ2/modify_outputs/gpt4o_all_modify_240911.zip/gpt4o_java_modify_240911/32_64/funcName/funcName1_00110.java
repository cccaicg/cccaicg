/**
 * Install the apk
 *
 * @param context
 * @param filePath
 */
private static void Install(Context context, String filePath)
{