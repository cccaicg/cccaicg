/**
 * Returns the file name.
 *
 * @return false if zipEntry is null
 */
public Value ZipEntryName(Env env,
        @NotNull QuercusZipEntry entry)
{