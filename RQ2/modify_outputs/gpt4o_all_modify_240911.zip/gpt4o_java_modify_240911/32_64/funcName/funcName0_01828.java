/**
 * Constructor
 * 
 * @param root
 *            The root element
 * @param dragMode
 *            The drag mode of the layout
 */
public vLayoutDragDropMouseHandler(Widget root, LayoutDragMode dragMode)
{