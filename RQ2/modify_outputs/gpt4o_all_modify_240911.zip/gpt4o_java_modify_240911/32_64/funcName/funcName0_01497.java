/**
 * Returns the file name.
 *
 * @return false if zipEntry is null
 */
public Value zipEntryName(Env env,
        @NotNull QuercusZipEntry entry)
{