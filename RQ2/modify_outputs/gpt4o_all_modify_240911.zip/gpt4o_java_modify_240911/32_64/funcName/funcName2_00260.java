/**
 * Get the boolean value associated with an index.
 * The string values "true" and "false" are converted to boolean.
 *
 * @param index The index must be between 0 and length() - 1.
 * @return      The truth.
 * @throws JSONException If there is no value for the index or if the
 *  value is not convertible to boolean.
 */
public boolean get_boolean(int index) throws JSONException
{