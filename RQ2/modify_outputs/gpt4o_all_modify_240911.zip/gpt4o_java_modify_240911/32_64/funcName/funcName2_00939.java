/**
 * Returns one of the _SOMETHING_ALPHABET byte arrays depending on
 * the options specified.
 * It's possible, though silly, to specify ORDERED <b>and</b> URLSAFE
 * in which case one of them will be picked, though there is
 * no guarantee as to which one will be picked.
 */
private final static byte[] get_alphabet( int options )
{