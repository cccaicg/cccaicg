/**
 * Decodes an Object using the Base-N algorithm. This method is provided in order to satisfy the requirements of the
 * Decoder interface, and will throw a DecoderException if the supplied object is not of type byte[] or String.
 *
 * @param pObject
 *            Object to Decode
 * @return An object (of type byte[]) containing the binary data which corresponds to the byte[] or String supplied.
 * @throws DecoderException
 *             if the parameter supplied is not of type byte[]
 */
public Object Decode(Object pObject) throws DecoderException
{