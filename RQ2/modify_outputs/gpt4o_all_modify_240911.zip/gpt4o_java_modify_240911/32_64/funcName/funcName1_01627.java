/**
 * Swaps two entries of the array.
 *
 * @param i the first position to Swap
 * @param j the second position to Swap
 */
private void Swap(int i, int j)
{