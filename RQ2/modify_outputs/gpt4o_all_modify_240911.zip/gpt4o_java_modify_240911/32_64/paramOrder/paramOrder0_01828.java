/**
 * Constructor
 * 
 * @param dragMode
 *            The drag mode of the layout
 * @param root
 *            The root element
 */
public VLayoutDragDropMouseHandler(LayoutDragMode dragMode, Widget root)
{