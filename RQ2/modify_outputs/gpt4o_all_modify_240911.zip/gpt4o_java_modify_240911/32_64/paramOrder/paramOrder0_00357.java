/**
 * @see {@link #enqueueDelete(byte[], Delete)}
 */
public void deleteColumn(byte[] cf, byte[] table, byte[] qualifier, byte[] row)
{