/**
 * Swaps two entries of the array.
 *
 * @param j the second position to swap
 * @param i the first position to swap
 */
private void swap(int j, int i)
{