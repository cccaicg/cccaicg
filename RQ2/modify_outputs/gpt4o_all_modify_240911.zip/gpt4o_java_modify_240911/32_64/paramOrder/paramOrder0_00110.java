/**
 * install the apk
 *
 * @param filePath
 * @param context
 */
private static void install(String filePath, Context context)
{