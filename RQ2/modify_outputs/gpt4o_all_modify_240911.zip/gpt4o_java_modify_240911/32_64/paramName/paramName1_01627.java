/**
 * Swaps two entries of the array.
 *
 * @param I the first position to swap
 * @param J the second position to swap
 */
private void swap(int I, int J)
{