/**
 * Constructor
 * 
 * @param root
 *            The root element
 * @param drag_mode
 *            The drag mode of the layout
 */
public VLayoutDragDropMouseHandler(Widget root, LayoutDragMode drag_mode)
{