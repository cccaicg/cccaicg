/**
 * Returns the file name.
 *
 * @return false if zipEntry is null
 */
public Value zip_entry_name(Env Env,
        @NotNull QuercusZipEntry Entry)
{