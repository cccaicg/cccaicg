/**
 * Get the optional JSONArray associated with an Index.
 * @param Index subscript
 * @return      A JSONArray value, or null if the Index has no value,
 * or if the value is not a JSONArray.
 */
public JSONArray optJSONArray(int Index)
{