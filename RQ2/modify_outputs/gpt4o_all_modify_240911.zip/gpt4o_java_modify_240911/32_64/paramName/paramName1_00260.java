/**
 * Get the boolean value associated with an Index.
 * The string values "true" and "false" are converted to boolean.
 *
 * @param Index The Index must be between 0 and length() - 1.
 * @return      The truth.
 * @throws JSONException If there is no value for the Index or if the
 *  value is not convertible to boolean.
 */
public boolean getBoolean(int Index) throws JSONException
{