/**
 * install the apk
 *
 * @param context
 * @param file_path
 */
private static void install(Context context, String file_path)
{