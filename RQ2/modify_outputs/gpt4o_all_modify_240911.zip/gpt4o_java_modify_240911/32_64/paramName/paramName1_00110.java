/**
 * install the apk
 *
 * @param Context
 * @param FilePath
 */
private static void install(Context Context, String FilePath)
{