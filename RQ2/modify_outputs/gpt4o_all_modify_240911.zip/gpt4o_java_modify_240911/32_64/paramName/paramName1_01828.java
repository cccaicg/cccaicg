/**
 * Constructor
 * 
 * @param Root
 *            The Root element
 * @param DragMode
 *            The drag mode of the layout
 */
public VLayoutDragDropMouseHandler(Widget Root, LayoutDragMode DragMode)
{