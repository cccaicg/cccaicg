// Simple assertion mechanism: terminate with |msg| if |condition| is false.
private static void abortUnless(boolean condition, String msg)
{