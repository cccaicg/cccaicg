/**
 * Exchanges two elements in the array.
 *
 * @param i the index of the first element to exchange
 * @param j the index of the second element to exchange
 */
private void swap(int i, int j)
{