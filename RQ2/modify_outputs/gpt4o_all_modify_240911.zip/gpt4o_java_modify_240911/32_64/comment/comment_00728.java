/**
 * Terminate the connection to the GAE Channel.
 */
public void disconnect()
{