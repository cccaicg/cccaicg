/**
 * Retrieve the optional JSONArray linked to a given index.
 * @param index position in the array
 * @return      A JSONArray object, or null if the index has no corresponding value,
 * or if the value is not an instance of JSONArray.
 */
public JSONArray optJSONArray(int index)
{