/**
 * Retrieve the boolean value from a specified index.
 * Converts string literals "true" and "false" to their boolean counterparts.
 *
 * @param index The index should be within the range of 0 to length() - 1.
 * @return      The boolean result.
 * @throws JSONException If the index has no value or if the
 *  value cannot be converted to a boolean.
 */
public boolean getBoolean(int index) throws JSONException
{