```java
/**
 * Refer to {@link #enqueueDelete(byte[], Delete)}
 */
```
public void deleteColumn(byte[] table, byte[] row, byte[] cf, byte[] qualifier)
{