/**
 * Retrieves the name of the file.
 *
 * @return false if zipEntry is not present
 */
public Value zip_entry_name(Env env,
        @NotNull QuercusZipEntry entry)
{