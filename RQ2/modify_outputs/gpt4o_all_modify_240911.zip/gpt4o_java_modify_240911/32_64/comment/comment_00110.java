/**
 * Initiate the APK installation process
 *
 * @param context
 * @param filePath
 */
private static void install(Context context, String filePath)
{