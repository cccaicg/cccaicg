/**
 * Retrieves a byte array from _SOMETHING_ALPHABET based on the given options.
 * Although it's illogical, you can specify both ORDERED <b>and</b> URLSAFE.
 * If you do so, one option will be chosen at random, without any certainty as to which one.
 */
private final static byte[] getAlphabet( int options )
{