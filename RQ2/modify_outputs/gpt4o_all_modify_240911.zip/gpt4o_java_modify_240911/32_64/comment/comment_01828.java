/**
 * Initializes a new instance
 * 
 * @param root
 *            The initial root element
 * @param dragMode
 *            Determines the layout's drag mode
 */
public VLayoutDragDropMouseHandler(Widget root, LayoutDragMode dragMode)
{