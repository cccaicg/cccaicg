/**
 * Utilizes the Base-N algorithm to interpret an Object. This function is implemented to fulfill the specifications of the
 * Decoder interface. A DecoderException will be thrown if the input object is neither a byte[] nor a String.
 *
 * @param pObject
 *            The Object intended for decoding
 * @return A byte[] Object containing the binary data equivalent to that of the provided byte[] or String.
 * @throws DecoderException
 *             if the provided parameter is not a byte[]
 */
public Object decode(Object pObject) throws DecoderException
{