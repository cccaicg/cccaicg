/**
 * This constructor enables the initialization of all attributes.
 *
 * @param delegateIndexer
 *            Supplies a delegate indexer through a constructor.
 * @param childIndexer
 *            Supplies a child indexer.
 * @param id
 *            Identifier assigned to this indexer.
 * @param sharedId
 *            Indicates whether shared ID mode is activated. In this mode, every component generated with this indexer
 *            will share the same ID, resulting in writes to the same file.
 */
public StorageBranchIndexer(IBranchIndexer<E> delegateIndexer, StorageBranchIndexer<E> childIndexer, int id, boolean sharedId)
{