/**
 * Modifies the value of a property if it is present; otherwise, it initializes a new one.
 * 
 * @param name
 *            The name of the property.
 * @param value
 *            The property's value.
 * 
 * @throws IllegalArgumentException
 *             If {@code name} is {@code null}.
 */
public void setProperty(String name, Object value)
{