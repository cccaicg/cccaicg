// Informs the listener if it's present.
protected void safelyNotifyOnHide()
{