/**
 * Combine the IV and cipherText using array copy.
 * This is applied, for instance, prior to mac calculation.
 * @param iv The IV to prepend
 * @param cipherText the cipherText to append
 * @return iv:cipherText, a newly created byte array.
 */
public static byte[] ivCipherConcat(byte[] iv, byte[] cipherText)
{