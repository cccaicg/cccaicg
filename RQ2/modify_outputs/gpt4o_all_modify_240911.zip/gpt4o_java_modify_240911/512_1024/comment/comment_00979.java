// Using a stack-based solution, unclear on the details
public int[] dailyTemperatures2(int[] temperatures)
{