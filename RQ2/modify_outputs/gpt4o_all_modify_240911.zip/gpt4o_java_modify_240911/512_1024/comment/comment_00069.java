/**
 * Constructs a new {@link GeoDistanceCondition} using the given reference point for the specified field.
 *
 * @param field the field name to match against
 * @param latitude the reference point's latitude
 * @param longitude the reference point's longitude
 * @param maxDistance the maximum permissible distance
 */
@JsonCreator
public GeoDistanceCondition(@JsonProperty("field") String field,
                            @JsonProperty("latitude") double latitude,
                            @JsonProperty("longitude") double longitude,
                            @JsonProperty("max_distance") String maxDistance)
{