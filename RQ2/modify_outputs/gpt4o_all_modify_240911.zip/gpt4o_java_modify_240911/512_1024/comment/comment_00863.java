/**
 * 将 Bitmap 转换为字节数组
 *
 * @param bitmap Bitmap 对象
 * @return 字节数组
 */
public static byte[] bitmap2Bytes(Bitmap bitmap)
{