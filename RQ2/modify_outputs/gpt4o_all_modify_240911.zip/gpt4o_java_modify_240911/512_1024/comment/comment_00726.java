/** Scroll interval; defaults to 5 seconds */
public T setPeriod(long period)
{