/**
 * Alerts observers regarding the change in purchase status of the given item.
 * 
 * @param itemId
 *            ID of the item with an updated purchase status.
 * @param state
 *            updated purchase status of the item.
 */
private static void notifyPurchaseStateChange(String itemId, Transaction.PurchaseState state)
{