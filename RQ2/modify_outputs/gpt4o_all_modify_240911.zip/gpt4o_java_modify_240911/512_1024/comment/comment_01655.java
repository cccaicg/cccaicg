/**
 * Sets up using a resource for text entries and the limits for autocomplete queries.
 *
 * @see ArrayAdapter#ArrayAdapter(Context, int)
 */
public GooglePlacesAdapter(Context context, int resource, GoogleApiClient googleApiClient,
                           LatLngBounds bounds, AutocompleteFilter filter)
{