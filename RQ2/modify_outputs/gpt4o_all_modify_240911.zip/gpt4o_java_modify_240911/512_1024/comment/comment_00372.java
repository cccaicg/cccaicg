/**
 * Fetches the value associated with the specified property.
 * 
 * @param name
 *            The name of the property.
 * 
 * @throws IllegalArgumentException
 *             If {@code name} is {@code null}.
 * 
 * @return The property's value, or {@code null} if the property is not found.
 */
public Object getProperty(String name)
{