/** Configure the display style: either STYLE_DRAWABLE_RESOURCE or STYLE_CORNER_RECTANGLE */
public T setIndicatorStyle(int indicatorStyle)
{