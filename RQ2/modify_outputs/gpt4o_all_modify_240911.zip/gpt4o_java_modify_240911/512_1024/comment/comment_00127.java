/**
 * Assigns an ImageResource to the ImageView
 * @param viewId  ID of the view
 * @param resId   ID of the resource
 * @return
 */
public ViewHolder setImageResource(int viewId,int resId)
{