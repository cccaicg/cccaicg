/**
 * 隐藏Toast
 */
public static void cancelToast()
{