/**
 * Concatenation of strings, not thread-safe, high efficiency
 */
public static String builder(String... array)
{