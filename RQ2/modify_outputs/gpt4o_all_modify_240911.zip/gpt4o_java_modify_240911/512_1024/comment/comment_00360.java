/**
 * Utility function to associate several {@link Rule}s with a specific {@link View}.
 * 
 * @param view
 *            The {@link View} that needs validation.
 * @param rules
 *            A {@link List} of {@link Rule}s tied to the view.
 * 
 * @throws IllegalArgumentException
 *             Thrown if {@code rules} is {@code null}.
 */
public void put(View view, List<Rule<?>> rules)
{