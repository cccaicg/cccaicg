/** 延迟滚动，默认时间为5秒 */
public T setDelay(long delay)
{