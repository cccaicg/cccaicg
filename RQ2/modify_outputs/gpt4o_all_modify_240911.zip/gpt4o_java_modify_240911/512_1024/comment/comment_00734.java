/** Sets the selected color for the display (when using STYLE_CORNER_RECTANGLE), default is "#ffffff" */
public T setIndicatorSelectColor(int selectColor)
{