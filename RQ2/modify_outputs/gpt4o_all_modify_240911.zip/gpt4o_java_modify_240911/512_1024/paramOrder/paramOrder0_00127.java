/**
 * 给ImageView设置ImageResource
 * @param resId   资源id
 * @param viewId  控件id
 * @return
 */
public ViewHolder setImageResource(int resId, int viewId)
{