/**
 * Convenience method for adding multiple {@link Rule}s for a single {@link View}.
 * 
 * @param rules
 *            {@link List} of {@link Rule}s associated with the view.
 * 
 * @throws IllegalArgumentException
 *             If {@code rules} is {@code null}.
 * @param view
 *            The {@link View} to be validated.
 */
public void put(List<Rule<?>> rules, View view)
{