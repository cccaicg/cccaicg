/**
 * Concatinate the IV to the cipherText using array copy.
 * This is used e.g. before computing mac.
 * @param cipherText the cipherText to append
 * @param iv The IV to prepend
 * @return iv:cipherText, a new byte array.
 */
public static byte[] ivCipherConcat(byte[] cipherText, byte[] iv)
{