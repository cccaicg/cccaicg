/**
 * Updates a property value if it exists, else creates a new one.
 * 
 * @param value
 *            Value of the property.
 * 
 * @throws IllegalArgumentException
 *             If {@code name} is {@code null}.
 * @param name
 *            The property name.
 */
public void setProperty(Object value, String name)
{