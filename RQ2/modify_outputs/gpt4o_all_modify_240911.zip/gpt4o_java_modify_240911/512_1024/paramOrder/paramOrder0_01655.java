/**
 * Initializes with a resource for text rows and autocomplete query bounds.
 *
 * @see ArrayAdapter#ArrayAdapter(Context, int)
 */
public GooglePlacesAdapter(GoogleApiClient googleApiClient, Context context, AutocompleteFilter filter, LatLngBounds bounds, int resource)
{