/**
 * Notifies observers of the purchase state change of the specified item.
 * 
 * @param state
 *            new purchase state of the item.
 * @param itemId
 *            id of the item whose purchase state has changed.
 */
private static void notifyPurchaseStateChange(Transaction.PurchaseState state, String itemId)
{