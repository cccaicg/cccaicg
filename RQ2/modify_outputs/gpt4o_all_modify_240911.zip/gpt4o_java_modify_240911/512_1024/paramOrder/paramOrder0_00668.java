/**
 * This constructor allows setting of all properties.
 *
 * @param id
 *            Id given to this indexer.
 * @param childIndexer
 *            Provides child indexer.
 * @param sharedId
 *            If shared ID mode is on. With this mode, all components created with this indexer
 *            will have same ID, thus write will be done in same file.
 * @param delegateIndexer
 *            Provides delegate indexer with a constructor.
 */
public StorageBranchIndexer(int id, StorageBranchIndexer<E> childIndexer, boolean sharedId, IBranchIndexer<E> delegateIndexer)
{