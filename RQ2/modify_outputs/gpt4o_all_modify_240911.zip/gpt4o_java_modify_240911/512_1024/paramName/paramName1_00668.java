/**
 * This constructor allows setting of all properties.
 *
 * @param DelegateIndexer
 *            ProvIdes delegate indexer with a constructor.
 * @param ChildIndexer
 *            ProvIdes child indexer.
 * @param Id
 *            Id given to this indexer.
 * @param SharedId
 *            If shared ID mode is on. With this mode, all components created with this indexer
 *            will have same ID, thus write will be done in same file.
 */
public StorageBranchIndexer(IBranchIndexer<E> DelegateIndexer, StorageBranchIndexer<E> ChildIndexer, int Id, boolean SharedId)
{