/**
 * Notifies observers of the purchase State change of the specified item.
 * 
 * @param ItemId
 *            id of the item whose purchase State has changed.
 * @param State
 *            new purchase State of the item.
 */
private static void notifyPurchaseStateChange(String ItemId, Transaction.PurchaseState State)
{