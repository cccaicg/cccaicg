/**
 * Concatinate the IV to the CipherText using array copy.
 * This is used e.g. before computing mac.
 * @param Iv The IV to prepend
 * @param CipherText the CipherText to append
 * @return Iv:CipherText, a new byte array.
 */
public static byte[] IvCipherConcat(byte[] Iv, byte[] CipherText)
{