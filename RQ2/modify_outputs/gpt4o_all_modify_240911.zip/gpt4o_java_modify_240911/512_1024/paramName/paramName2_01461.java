/**
 * Notifies observers of the purchase state change of the specified item.
 * 
 * @param item_id
 *            id of the item whose purchase state has changed.
 * @param state
 *            new purchase state of the item.
 */
private static void notifyPurchaseStateChange(String item_id, Transaction.PurchaseState state)
{