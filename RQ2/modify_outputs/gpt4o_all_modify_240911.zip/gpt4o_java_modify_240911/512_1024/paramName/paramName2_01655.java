/**
 * Initializes with a resource for text rows and autocomplete query bounds.
 *
 * @see ArrayAdapter#ArrayAdapter(Context, int)
 */
public GooglePlacesAdapter(Context context, int resource, GoogleApiClient google_api_client,
                           LatLngBounds bounds, AutocompleteFilter filter)
{