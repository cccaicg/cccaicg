/**
 * Concatinate the IV to the cipher_text using array copy.
 * This is used e.g. before computing mac.
 * @param iv The IV to prepend
 * @param cipher_text the cipher_text to append
 * @return iv:cipher_text, a new byte array.
 */
public static byte[] ivCipherConcat(byte[] iv, byte[] cipher_text)
{