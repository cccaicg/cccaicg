/**
 * 给ImageView设置ImageResource
 * @param view_id  控件id
 * @param res_id   资源id
 * @return
 */
public ViewHolder setImageResource(int view_id,int res_id)
{