/**
 * 给ImageView设置ImageResource
 * @param ViewId  控件id
 * @param ResId   资源id
 * @return
 */
public ViewHolder setImageResource(int ViewId,int ResId)
{