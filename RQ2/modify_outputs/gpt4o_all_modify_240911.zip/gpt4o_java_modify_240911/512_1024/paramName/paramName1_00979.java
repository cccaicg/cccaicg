//用栈的解法，没看懂
public int[] dailyTemperatures2(int[] Temperatures)
{