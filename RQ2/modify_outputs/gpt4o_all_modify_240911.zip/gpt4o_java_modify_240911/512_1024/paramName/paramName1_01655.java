/**
 * Initializes with a Resource for text rows and autocomplete query Bounds.
 *
 * @see ArrayAdapter#ArrayAdapter(Context, int)
 */
public GooglePlacesAdapter(Context Context, int Resource, GoogleApiClient GoogleApiClient,
                           LatLngBounds Bounds, AutocompleteFilter Filter)
{