/**
 * 把Bitmap转Byte
 *
 * @param Bitmap Bitmap对象
 * @return Bytes
 */
public static byte[] Bitmap2Bytes(Bitmap Bitmap)
{