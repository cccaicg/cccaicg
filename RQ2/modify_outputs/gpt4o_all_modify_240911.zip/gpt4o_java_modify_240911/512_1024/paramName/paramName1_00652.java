/**
 * 字符串拼接,线程不安全,效率高
 */
public static String builder(String... Array)
{