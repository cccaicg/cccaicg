/**
 * This constructor allows setting of all properties.
 *
 * @param delegate_indexer
 *            Provides delegate indexer with a constructor.
 * @param child_indexer
 *            Provides child indexer.
 * @param id
 *            Id given to this indexer.
 * @param shared_id
 *            If shared ID mode is on. With this mode, all components created with this indexer
 *            will have same ID, thus write will be done in same file.
 */
public StorageBranchIndexer(IBranchIndexer<E> delegate_indexer, StorageBranchIndexer<E> child_indexer, int id, boolean shared_id)
{