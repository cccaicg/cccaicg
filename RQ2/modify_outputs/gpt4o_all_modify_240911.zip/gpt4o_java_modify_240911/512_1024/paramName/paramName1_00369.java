/**
 * Updates a property Value if it exists, else creates a new one.
 * 
 * @param Name
 *            The property Name.
 * @param Value
 *            Value of the property.
 * 
 * @throws IllegalArgumentException
 *             If {@code Name} is {@code null}.
 */
public void setProperty(String Name, Object Value)
{