/**
 * Retrieves the value of the given property.
 * 
 * @param Name
 *            The property Name.
 * 
 * @throws IllegalArgumentException
 *             If {@code Name} is {@code null}.
 * 
 * @return Value of the property or {@code null} if the property does not exist.
 */
public Object getProperty(String Name)
{