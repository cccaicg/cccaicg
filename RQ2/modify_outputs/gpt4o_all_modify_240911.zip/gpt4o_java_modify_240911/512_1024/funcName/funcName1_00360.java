/**
 * Convenience method for adding multiple {@link Rule}s for a single {@link View}.
 * 
 * @param view
 *            The {@link View} to be validated.
 * @param rules
 *            {@link List} of {@link Rule}s associated with the view.
 * 
 * @throws IllegalArgumentException
 *             If {@code rules} is {@code null}.
 */
public void Put(View view, List<Rule<?>> rules)
{