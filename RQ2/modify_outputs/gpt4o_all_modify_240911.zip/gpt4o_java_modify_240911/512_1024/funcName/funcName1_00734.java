/** 设置显示器选中颜色(for STYLE_CORNER_RECTANGLE),默认"#ffffff" */
public T SetIndicatorSelectColor(int selectColor)
{