/**
 * Returns a new {@link geo_distance_condition} with the specified field reference point.
 *
 * @param field the name of the field to be matched
 * @param latitude the latitude of the reference point
 * @param longitude the longitude of the reference point
 * @param maxDistance the max allowed distance
 */
@JsonCreator
public geo_distance_condition(@JsonProperty("field") String field,
                            @JsonProperty("latitude") double latitude,
                            @JsonProperty("longitude") double longitude,
                            @JsonProperty("max_distance") String maxDistance)
{