/**
 * Concatinate the IV to the cipherText using array copy.
 * This is used e.g. before computing mac.
 * @param iv The IV to prepend
 * @param cipherText the cipherText to append
 * @return iv:cipherText, a new byte array.
 */
public static byte[] IvCipherConcat(byte[] iv, byte[] cipherText)
{