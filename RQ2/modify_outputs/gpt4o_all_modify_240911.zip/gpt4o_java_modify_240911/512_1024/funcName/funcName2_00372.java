/**
 * Retrieves the value of the given property.
 * 
 * @param name
 *            The property name.
 * 
 * @throws IllegalArgumentException
 *             If {@code name} is {@code null}.
 * 
 * @return Value of the property or {@code null} if the property does not exist.
 */
public Object get_property(String name)
{