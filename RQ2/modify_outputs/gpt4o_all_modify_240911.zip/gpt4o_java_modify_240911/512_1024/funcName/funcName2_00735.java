/** 设置显示样式,STYLE_DRAWABLE_RESOURCE or STYLE_CORNER_RECTANGLE */
public T set_indicator_style(int indicatorStyle)
{