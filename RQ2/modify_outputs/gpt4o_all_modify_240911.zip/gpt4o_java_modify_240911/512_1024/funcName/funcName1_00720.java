/** 滚动延时,默认5秒 */
public T SetDelay(long delay)
{