/**
 * 把Bitmap转Byte
 *
 * @param bitmap bitmap对象
 * @return Bytes
 */
public static byte[] bitmap_2_bytes(Bitmap bitmap)
{