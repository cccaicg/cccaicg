/**
 * Initializes with a resource for text rows and autocomplete query bounds.
 *
 * @see ArrayAdapter#ArrayAdapter(Context, int)
 */
public google_places_adapter(Context context, int resource, GoogleApiClient googleApiClient,
                           LatLngBounds bounds, AutocompleteFilter filter)
{