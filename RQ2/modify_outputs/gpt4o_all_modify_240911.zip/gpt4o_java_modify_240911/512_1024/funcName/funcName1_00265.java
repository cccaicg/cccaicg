/**
 * Notifies listener if available.
 */
protected void SafelyNotifyOnHide()
{