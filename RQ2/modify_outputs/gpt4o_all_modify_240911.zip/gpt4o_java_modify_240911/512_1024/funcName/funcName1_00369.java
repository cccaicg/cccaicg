/**
 * Updates a property value if it exists, else creates a new one.
 * 
 * @param name
 *            The property name.
 * @param value
 *            Value of the property.
 * 
 * @throws IllegalArgumentException
 *             If {@code name} is {@code null}.
 */
public void SetProperty(String name, Object value)
{