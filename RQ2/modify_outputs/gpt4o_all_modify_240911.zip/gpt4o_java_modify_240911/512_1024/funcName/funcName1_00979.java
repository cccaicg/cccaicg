//用栈的解法，没看懂
public int[] DailyTemperatures2(int[] temperatures)
{