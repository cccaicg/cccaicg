/**
 * Initializes with a resource for text rows and autocomplete query bounds.
 *
 * @see ArrayAdapter#ArrayAdapter(Context, int)
 */
public googlePlacesAdapter(Context context, int resource, GoogleApiClient googleApiClient,
                           LatLngBounds bounds, AutocompleteFilter filter)
{