/**
 * 取消吐司显示
 */
public static void CancelToast()
{