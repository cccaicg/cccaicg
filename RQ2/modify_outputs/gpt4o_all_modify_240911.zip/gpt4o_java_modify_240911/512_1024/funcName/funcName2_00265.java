/**
 * Notifies listener if available.
 */
protected void safely_notify_on_hide()
{