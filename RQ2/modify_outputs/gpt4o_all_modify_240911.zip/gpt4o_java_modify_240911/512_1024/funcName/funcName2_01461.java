/**
 * Notifies observers of the purchase state change of the specified item.
 * 
 * @param itemId
 *            id of the item whose purchase state has changed.
 * @param state
 *            new purchase state of the item.
 */
private static void notify_purchase_state_change(String itemId, Transaction.PurchaseState state)
{