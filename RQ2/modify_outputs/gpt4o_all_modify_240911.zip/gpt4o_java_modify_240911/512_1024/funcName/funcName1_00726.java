/** 滚动间隔,默认5秒 */
public T SetPeriod(long period)
{