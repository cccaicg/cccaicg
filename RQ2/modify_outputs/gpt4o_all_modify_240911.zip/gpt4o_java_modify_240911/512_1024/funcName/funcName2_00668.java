/**
 * This constructor allows setting of all properties.
 *
 * @param delegateIndexer
 *            Provides delegate indexer with a constructor.
 * @param childIndexer
 *            Provides child indexer.
 * @param id
 *            Id given to this indexer.
 * @param sharedId
 *            If shared ID mode is on. With this mode, all components created with this indexer
 *            will have same ID, thus write will be done in same file.
 */
public storage_branch_indexer(IBranchIndexer<E> delegateIndexer, storage_branch_indexer<E> childIndexer, int id, boolean sharedId)
{