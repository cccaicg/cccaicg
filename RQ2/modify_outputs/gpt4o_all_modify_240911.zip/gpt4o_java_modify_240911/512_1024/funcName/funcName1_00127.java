/**
 * 给ImageView设置ImageResource
 * @param viewId  控件id
 * @param resId   资源id
 * @return
 */
public ViewHolder SetImageResource(int viewId,int resId)
{