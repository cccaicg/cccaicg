/** 滚动延时,默认5秒 */
public T set_delay(long delay)
{