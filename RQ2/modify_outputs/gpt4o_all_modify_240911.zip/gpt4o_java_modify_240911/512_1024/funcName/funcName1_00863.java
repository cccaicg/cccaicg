/**
 * 把Bitmap转Byte
 *
 * @param bitmap bitmap对象
 * @return Bytes
 */
public static byte[] Bitmap2Bytes(Bitmap bitmap)
{