/**
  * @brief  Checks whether the specified CRYP interrupt has occurred or not.
  * @note   This function checks the status of the masked interrupt (i.e the 
  *         interrupt should be previously enabled).     
  * @param  c_r_y_p__i_t: specifies the CRYP (masked) interrupt source to check.
  *           This parameter can be one of the following values:
  *            @arg c_r_y_p__i_t_INI: Input FIFO interrupt
  *            @arg c_r_y_p__i_t_OUTI: Output FIFO interrupt
  * @retval The new state of c_r_y_p__i_t (SET or RESET).
  */
ITStatus CRYP_GetITStatus(uint8_t c_r_y_p__i_t)
{