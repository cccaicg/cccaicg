/**
  * @brief  Checks whether the specified FSMC interrupt has occurred or not.
  * @param  f_s_m_c__bank: specifies the FSMC Bank to be used
  *   This parameter can be one of the following values:
  *     @arg f_s_m_c__bank2_NAND: FSMC Bank2 NAND 
  *     @arg f_s_m_c__bank3_NAND: FSMC Bank3 NAND
  *     @arg f_s_m_c__bank4_PCCARD: FSMC Bank4 PCCARD
  * @param  f_s_m_c__i_t: specifies the FSMC interrupt source to check.
  *   This parameter can be one of the following values:
  *     @arg f_s_m_c__i_t_RisingEdge: Rising edge detection interrupt. 
  *     @arg f_s_m_c__i_t_Level: Level edge detection interrupt.
  *     @arg f_s_m_c__i_t_FallingEdge: Falling edge detection interrupt. 
  * @retval The new state of f_s_m_c__i_t (SET or RESET).
  */
ITStatus FSMC_GetITStatus(uint32_t f_s_m_c__bank, uint32_t f_s_m_c__i_t)
{