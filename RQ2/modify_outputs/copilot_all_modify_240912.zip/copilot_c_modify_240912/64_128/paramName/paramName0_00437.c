/**
  * @brief  Checks whether the specified FSMC interrupt has occurred or not.
  * @param  fSMC_Bank: specifies the FSMC Bank to be used
  *   This parameter can be one of the following values:
  *     @arg fSMC_Bank2_NAND: FSMC Bank2 NAND 
  *     @arg fSMC_Bank3_NAND: FSMC Bank3 NAND
  *     @arg fSMC_Bank4_PCCARD: FSMC Bank4 PCCARD
  * @param  fSMC_IT: specifies the FSMC interrupt source to check.
  *   This parameter can be one of the following values:
  *     @arg fSMC_IT_RisingEdge: Rising edge detection interrupt. 
  *     @arg fSMC_IT_Level: Level edge detection interrupt.
  *     @arg fSMC_IT_FallingEdge: Falling edge detection interrupt. 
  * @retval The new state of fSMC_IT (SET or RESET).
  */
ITStatus FSMC_GetITStatus(uint32_t fSMC_Bank, uint32_t fSMC_IT)
{