/*
 * Write Errors are reported with an console message in Sharktools.
 */
static void
write_failure_message(const char *Filename, int Err)
{