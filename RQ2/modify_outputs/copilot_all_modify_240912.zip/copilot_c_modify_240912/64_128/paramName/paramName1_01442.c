/*
 * Stcp_socket_close_cb
 * --------------------
 *
 * Callback (shim) for when the linger has expired.
 * Just calls through to Stcp_socket_shutdown()
 */
void Stcp_socket_close_cb(
    struct ev_loop *Loop,
    ev_timer *CloseTimer,
    int Revents)
{