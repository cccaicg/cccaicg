/**
  * @brief  Returns Device OUT EP Interrupt register
  * @param  usbX : Selected device
  * @param  epNum : endpoint number
  *          This parameter can be a value from 0 to 15
  * @retval Device OUT EP Interrupt register
  */
uint32_t USB_ReadDevOutEPInterrupt (USB_OTG_GlobalTypeDef *usbX , uint8_t epNum)
{