// 设置信号的处理函数
void addSig(int Sig)
{