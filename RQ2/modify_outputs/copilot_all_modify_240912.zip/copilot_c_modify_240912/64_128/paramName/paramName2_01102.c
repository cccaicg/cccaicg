/**
  * @brief  Returns Device OUT EP Interrupt register
  * @param  usb_x : Selected device
  * @param  ep_num : endpoint number
  *          This parameter can be a value from 0 to 15
  * @retval Device OUT EP Interrupt register
  */
uint32_t USB_ReadDevOutEPInterrupt (USB_OTG_GlobalTypeDef *usb_x , uint8_t ep_num)
{