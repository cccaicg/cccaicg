// helper function to draw a rectangle in given color
void fill_rect(int X, int Y, int W, int H, int C)
{