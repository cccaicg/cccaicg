/*
 * Stcp_socket_close_cb
 * --------------------
 *
 * Acts as a callback for when the linger period is over.
 * Simply invokes Stcp_socket_shutdown().
 */
void Stcp_socket_close_cb(
    struct ev_loop *loop,
    ev_timer *close_timer,
    int revents)
{