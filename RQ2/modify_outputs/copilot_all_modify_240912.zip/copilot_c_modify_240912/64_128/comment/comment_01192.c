/**@brief Function for initializing the GAP settings.
 *
 * @details This function configures all essential parameters of the GAP (Generic Access Profile) for the
 *          device, such as the device name, appearance, and desired connection parameters.
 */
static void gap_params_init(void)
{