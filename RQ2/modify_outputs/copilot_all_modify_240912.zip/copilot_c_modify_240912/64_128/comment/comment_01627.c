/*
 * In Sharktools, console messages are used to report write errors.
 */
static void
write_failure_message(const char *filename, int err)
{