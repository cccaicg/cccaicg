// Utility function to render a rectangle with the specified color
void fill_rect(int x, int y, int w, int h, int c)
{