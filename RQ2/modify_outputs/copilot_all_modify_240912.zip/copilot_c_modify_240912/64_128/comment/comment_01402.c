/*!SETUP_SYSTEM_SPD_MEMORY*/
int checkboard (void)
{