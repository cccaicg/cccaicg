/**
  * @brief  Determines if the given FSMC interrupt has triggered.
  * @param  FSMC_Bank: defines the FSMC Bank to utilize
  *   This parameter may be one of the following options:
  *     @arg FSMC_Bank2_NAND: FSMC Bank2 for NAND
  *     @arg FSMC_Bank3_NAND: FSMC Bank3 for NAND
  *     @arg FSMC_Bank4_PCCARD: FSMC Bank4 for PCCARD
  * @param  FSMC_IT: identifies the FSMC interrupt source to verify.
  *   This parameter could be one of the following options:
  *     @arg FSMC_IT_RisingEdge: Interrupt on rising edge detection. 
  *     @arg FSMC_IT_Level: Interrupt on level edge detection.
  *     @arg FSMC_IT_FallingEdge: Interrupt on falling edge detection. 
  * @retval The current status of FSMC_IT (SET or RESET).
  */
ITStatus FSMC_GetITStatus(uint32_t FSMC_Bank, uint32_t FSMC_IT)
{