```cpp
// Step 3: Disconnect the new node from the original node to form a new linked list
```
ListNode *reconnectNodes(ListNode *phead)
{