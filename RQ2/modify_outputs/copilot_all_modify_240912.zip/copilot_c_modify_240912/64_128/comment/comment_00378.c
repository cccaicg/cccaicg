/**
  * @brief  Determines if the specified CRYP interrupt has occurred.
  * @note   This function verifies the status of the masked interrupt, meaning
  *         that the interrupt should have been enabled prior.     
  * @param  CRYP_IT: specifies the CRYP (masked) interrupt source to verify.
  *           This parameter can be one of the following values:
  *            @arg CRYP_IT_INI: Interrupt for Input FIFO
  *            @arg CRYP_IT_OUTI: Interrupt for Output FIFO
  * @retval The current state of CRYP_IT (SET or RESET).
  */
ITStatus CRYP_GetITStatus(uint8_t CRYP_IT)
{