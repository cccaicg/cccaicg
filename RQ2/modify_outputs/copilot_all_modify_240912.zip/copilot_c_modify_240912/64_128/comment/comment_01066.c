// A double pointer is used to allow changes to the head node's value if necessary.
void delete_node(list_node **ppHead,list_node *pToDelete)
{