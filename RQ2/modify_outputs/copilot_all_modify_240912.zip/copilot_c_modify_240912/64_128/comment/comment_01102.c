/**
  * @brief  Retrieves the Interrupt Register for Device OUT Endpoint
  * @param  USBx : Targeted device
  * @param  epnum : Endpoint index
  *          This parameter can be between 0 and 15
  * @retval Interrupt register for Device OUT Endpoint
  */
uint32_t USB_ReadDevOutEPInterrupt (USB_OTG_GlobalTypeDef *USBx , uint8_t epnum)
{