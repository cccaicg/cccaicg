// 定义信号处理器函数
void addsig(int sig)
{