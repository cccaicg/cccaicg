/*!CONFIG_SYS_SPD_EEPROM*/
int check_board (void)
{