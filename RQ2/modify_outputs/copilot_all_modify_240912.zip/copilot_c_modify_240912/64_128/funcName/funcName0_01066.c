//因为可能要改变头节点的值，所以要传二维指针
void deleteNode(list_node **ppHead,list_node *pToDelete)
{