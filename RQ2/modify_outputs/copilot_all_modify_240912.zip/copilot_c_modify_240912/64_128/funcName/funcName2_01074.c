//第三步:让新节点脱离原始节点形成新链表
ListNode *reconnect_nodes(ListNode *phead)
{