// 设置信号的处理函数
void add_sig(int sig)
{