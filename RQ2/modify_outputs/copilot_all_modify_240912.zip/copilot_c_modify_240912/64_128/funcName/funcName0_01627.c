/*
 * Write errors are reported with an console message in Sharktools.
 */
static void
writeFailureMessage(const char *filename, int err)
{