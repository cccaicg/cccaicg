/*!CONFIG_SYS_SPD_EEPROM*/
int CheckBoard (void)
{