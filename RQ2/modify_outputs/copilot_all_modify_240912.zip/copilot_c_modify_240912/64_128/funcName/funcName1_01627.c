/*
 * Write errors are reported with an console message in Sharktools.
 */
static void
WriteFailureMessage(const char *filename, int err)
{