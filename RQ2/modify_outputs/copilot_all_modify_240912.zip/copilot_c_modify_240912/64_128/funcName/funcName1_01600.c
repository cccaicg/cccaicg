// helper function to draw a rectangle in given color
void FillRect(int x, int y, int w, int h, int c)
{