// helper function to draw a rectangle in given color
void fillRect(int x, int y, int w, int h, int c)
{