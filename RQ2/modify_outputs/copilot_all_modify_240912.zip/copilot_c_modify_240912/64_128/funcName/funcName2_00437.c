/**
  * @brief  Checks whether the specified FSMC interrupt has occurred or not.
  * @param  FSMC_Bank: specifies the FSMC Bank to be used
  *   This parameter can be one of the following values:
  *     @arg FSMC_Bank2_NAND: FSMC Bank2 NAND 
  *     @arg FSMC_Bank3_NAND: FSMC Bank3 NAND
  *     @arg FSMC_Bank4_PCCARD: FSMC Bank4 PCCARD
  * @param  FSMC_IT: specifies the FSMC interrupt source to check.
  *   This parameter can be one of the following values:
  *     @arg FSMC_IT_RisingEdge: Rising edge detection interrupt. 
  *     @arg FSMC_IT_Level: Level edge detection interrupt.
  *     @arg FSMC_IT_FallingEdge: Falling edge detection interrupt. 
  * @retval The new state of FSMC_IT (SET or RESET).
  */
ITStatus f_s_m_c__get_i_t_status(uint32_t FSMC_Bank, uint32_t FSMC_IT)
{