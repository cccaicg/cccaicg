//因为可能要改变头节点的值，所以要传二维指针
void delete_node(list_node *pToDelete, list_node **ppHead)
{