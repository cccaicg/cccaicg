// helper function to draw a rectangle in given color
void fill_rect(int y, int x, int c, int w, int h)
{