/*
 * Write errors are reported with an console message in Sharktools.
 */
static void
write_failure_message(int err, const char *filename)
{