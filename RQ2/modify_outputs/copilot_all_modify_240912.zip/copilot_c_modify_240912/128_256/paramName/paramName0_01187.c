/**
  * @brief  Clears the aDCx's pending flags.
  * @param  aDCx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @param  aDC_FLAG: specifies the flag to clear. 
  *   This parameter can be any combination of the following values:
  *     @arg aDC_FLAG_AWD: Analog watchdog flag
  *     @arg aDC_FLAG_EOC: End of conversion flag
  *     @arg aDC_FLAG_JEOC: End of injected group conversion flag
  *     @arg aDC_FLAG_JSTRT: Start of injected group conversion flag
  *     @arg aDC_FLAG_STRT: Start of regular group conversion flag
  * @retval None
  */
void ADC_ClearFlag(ADC_TypeDef* aDCx, uint8_t aDC_FLAG)
{