/*
 * Set functions pointers and initialize global mutexes
 */
void mbedtls_threading_set_alt( void (*mutexInit)( mbedtls_threading_mutex_t * ),
                       void (*mutexFree)( mbedtls_threading_mutex_t * ),
                       int (*mutexLock)( mbedtls_threading_mutex_t * ),
                       int (*mutexUnlock)( mbedtls_threading_mutex_t * ) )
{