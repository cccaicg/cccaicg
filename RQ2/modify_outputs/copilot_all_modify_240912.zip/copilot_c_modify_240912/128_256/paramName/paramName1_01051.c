/* Cursor (logo) based line drawing */
void MoveTo(COOR X, COOR Y)
{