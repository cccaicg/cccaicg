/*++
  Purpose:

    Set the caption of the window. For compatibility with SDL2 only.

  Parameters:

    [IN]  lpsz_caption - the new caption of the window.

    [IN]  lp_reserved - not used, for compatibility only.

  Return value:

    None.

--*/
VOID
SDL_WM_SetCaption(
   LPCSTR         lpsz_caption,
   LPVOID         lp_reserved
)
{