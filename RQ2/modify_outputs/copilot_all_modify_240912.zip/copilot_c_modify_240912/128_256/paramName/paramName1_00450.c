/* write `Len` bytes starting from `Buf` into the `Offset` of ramdisk */
void ramdisk_write(uint8_t *Buf, uint32_t Offset, uint32_t Len)
{