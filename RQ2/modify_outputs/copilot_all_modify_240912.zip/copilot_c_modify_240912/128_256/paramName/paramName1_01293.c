// STBI_NO_HDR
static int stbi_bmp_info(stbi *S, int *X, int *Y, int *Comp)
{