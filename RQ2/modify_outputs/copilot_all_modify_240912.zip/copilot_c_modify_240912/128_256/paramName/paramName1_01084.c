/* JPEG library callback to initialize the input data source.
 */
static void init_source (j_decompress_ptr CInfo)
{