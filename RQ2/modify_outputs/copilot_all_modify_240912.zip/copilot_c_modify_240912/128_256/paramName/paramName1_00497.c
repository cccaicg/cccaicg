/* вգɾQжͷԪأeֵ */
Status deQueue(SqQueue *Q,QElemType *E)
{