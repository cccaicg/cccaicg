/* Create a new hash table */
static dict *dictCreate(dictType *Type, void *PrivDataPtr)
{