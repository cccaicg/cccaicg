/*
 * Here's the routine that will replace the standard error_exit method:
 */
METHODDEF(void)
extended_error_exit (j_common_ptr cInfo)
{