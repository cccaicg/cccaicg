/**
  * @brief  Configures the sequencer length for injected channels
  * @param  aDCx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @param  length: The sequencer length. 
  *   This parameter must be a number between 1 to 4.
  * @retval None
  */
void ADC_InjectedSequencerlengthConfig(ADC_TypeDef* aDCx, uint8_t length)
{