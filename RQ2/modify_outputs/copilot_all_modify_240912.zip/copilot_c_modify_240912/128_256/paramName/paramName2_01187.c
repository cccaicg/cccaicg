/**
  * @brief  Clears the a_d_cx's pending flags.
  * @param  a_d_cx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @param  a_d_c__f_l_a_g: specifies the flag to clear. 
  *   This parameter can be any combination of the following values:
  *     @arg a_d_c__f_l_a_g_AWD: Analog watchdog flag
  *     @arg a_d_c__f_l_a_g_EOC: End of conversion flag
  *     @arg a_d_c__f_l_a_g_JEOC: End of injected group conversion flag
  *     @arg a_d_c__f_l_a_g_JSTRT: Start of injected group conversion flag
  *     @arg a_d_c__f_l_a_g_STRT: Start of regular group conversion flag
  * @retval None
  */
void ADC_ClearFlag(ADC_TypeDef* a_d_cx, uint8_t a_d_c__f_l_a_g)
{