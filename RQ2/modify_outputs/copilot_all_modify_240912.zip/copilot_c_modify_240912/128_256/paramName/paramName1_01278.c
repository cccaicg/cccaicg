// A utility function to create a new tree node
struct Node* newNode(int Data)
{