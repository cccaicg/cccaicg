/*
 * Set functions pointers and initialize global mutexes
 */
void mbedtls_threading_set_alt( void (*MutexInit)( mbedtls_threading_mutex_t * ),
                       void (*MutexFree)( mbedtls_threading_mutex_t * ),
                       int (*MutexLock)( mbedtls_threading_mutex_t * ),
                       int (*MutexUnlock)( mbedtls_threading_mutex_t * ) )
{