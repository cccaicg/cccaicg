/* вգɾQжͷԪأeֵ */
Status DeQueue(SqQueue *q,QElemType *e)
{