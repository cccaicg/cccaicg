/**
  * @brief  Configures the sequencer length for injected channels
  * @param  a_d_cx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @param  Length: The sequencer length. 
  *   This parameter must be a number between 1 to 4.
  * @retval None
  */
void ADC_InjectedSequencerLengthConfig(ADC_TypeDef* a_d_cx, uint8_t Length)
{