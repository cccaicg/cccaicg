/* Destroy an entire hash table */
static int _dictClear(dict *Ht)
{