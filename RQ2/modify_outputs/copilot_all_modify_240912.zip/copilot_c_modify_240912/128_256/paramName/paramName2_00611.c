/* Create a new hash table */
static dict *dictCreate(dictType *type, void *priv_data_ptr)
{