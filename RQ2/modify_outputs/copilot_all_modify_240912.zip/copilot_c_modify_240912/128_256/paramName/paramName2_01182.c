/**
  * @brief  Resets the selected ADC calibration registers.
  * @param  a_d_cx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @retval None
  */
void ADC_ResetCalibration(ADC_TypeDef* a_d_cx)
{