/* Line drawing based on cursor (logo) movement */
void MoveTo(COOR x, COOR y)
{