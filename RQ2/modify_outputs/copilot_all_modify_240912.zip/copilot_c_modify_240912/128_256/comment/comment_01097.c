/* Callback for JPEG library to begin module setup.
 */
void jpeg_stdio_src (j_decompress_ptr cinfo, FILE * infile)
{