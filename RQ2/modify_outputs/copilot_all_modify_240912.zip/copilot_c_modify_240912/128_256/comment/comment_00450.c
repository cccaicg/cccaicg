/* store `len` bytes beginning from `buf` at the `offset` location within the ramdisk */
void ramdisk_write(uint8_t *buf, uint32_t offset, uint32_t len)
{