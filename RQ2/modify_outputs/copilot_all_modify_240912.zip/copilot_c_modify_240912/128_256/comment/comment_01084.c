/* Callback function for initializing the input data source in the JPEG library.
 */
static void init_source (j_decompress_ptr cinfo)
{