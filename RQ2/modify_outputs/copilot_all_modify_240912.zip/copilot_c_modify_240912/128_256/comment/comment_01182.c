/**
  * @brief  Clears the specified ADC calibration registers.
  * @param  ADCx: where x can range from 1 to 3 to choose the ADC peripheral.
  * @retval None
  */
void ADC_ResetCalibration(ADC_TypeDef* ADCx)
{