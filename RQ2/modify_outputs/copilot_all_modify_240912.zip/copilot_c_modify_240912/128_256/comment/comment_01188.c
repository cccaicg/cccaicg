/**
  * @brief  Sets the sequencer length for injected channels
  * @param  ADCx: 'x' represents 1, 2, or 3 to designate the ADC peripheral.
  * @param  Length: The length of the sequencer.
  *   This parameter should be a value ranging from 1 to 4.
  * @retval None
  */
void ADC_InjectedSequencerLengthConfig(ADC_TypeDef* ADCx, uint8_t Length)
{