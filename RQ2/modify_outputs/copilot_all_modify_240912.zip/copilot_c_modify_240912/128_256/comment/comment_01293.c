// Disable support for HDR images in STBI
static int stbi_bmp_info(stbi *s, int *x, int *y, int *comp)
{