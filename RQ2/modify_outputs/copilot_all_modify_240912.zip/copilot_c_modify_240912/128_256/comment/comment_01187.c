/**
  * @brief  Resets the pending flags for the specified ADCx.
  * @param  ADCx: where x can be either 1, 2, or 3, indicating the ADC peripheral.
  * @param  ADC_FLAG: determines which flag(s) to reset.
  *   This parameter can include any combination of these values:
  *     @arg ADC_FLAG_AWD: Flag for analog watchdog
  *     @arg ADC_FLAG_EOC: Flag indicating end of conversion
  *     @arg ADC_FLAG_JEOC: Flag indicating end of injected group conversion
  *     @arg ADC_FLAG_JSTRT: Flag for start of injected group conversion
  *     @arg ADC_FLAG_STRT: Flag for start of regular group conversion
  * @retval None
  */
void ADC_ClearFlag(ADC_TypeDef* ADCx, uint8_t ADC_FLAG)
{