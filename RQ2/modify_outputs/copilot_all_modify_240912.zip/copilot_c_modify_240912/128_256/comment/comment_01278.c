// Helper function to generate a new tree node
struct Node* newNode(int data)
{