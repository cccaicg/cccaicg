/**@brief Initializes the module for connection parameters.
 */
static void conn_params_init(void)
{