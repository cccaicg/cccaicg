/*release the previously mentioned pair*/
static void string_cleanup(char** out)
{