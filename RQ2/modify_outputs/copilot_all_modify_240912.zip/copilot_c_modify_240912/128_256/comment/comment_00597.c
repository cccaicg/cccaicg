/*
 * Return true if the memcache command is one of the storage commands; otherwise, return false.
 */
static bool
memcache_storage(struct msg *r)
{