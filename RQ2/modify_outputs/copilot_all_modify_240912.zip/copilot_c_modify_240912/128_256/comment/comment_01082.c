/*
 * This is the function designed to substitute the usual error_exit approach:
 */
METHODDEF(void)
extended_error_exit (j_common_ptr cinfo)
{