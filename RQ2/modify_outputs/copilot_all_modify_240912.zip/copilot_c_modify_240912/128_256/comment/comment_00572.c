/*-----------------------------------------------------------
 * PUBLIC TASK UTILITIES as described in task.h
 *----------------------------------------------------------*/
portTickType xTaskGetTickCount( void )
{