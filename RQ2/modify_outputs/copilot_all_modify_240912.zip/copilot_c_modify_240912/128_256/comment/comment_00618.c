/* Completely remove a hash table */
static int _dictClear(dict *ht)
{