/* Initialize a fresh hash table */
static dict *dictCreate(dictType *type, void *privDataPtr)
{