/* ԪأeֵվղQжͷ */
Status DeQueue(SqQueue *Q,QElemType *e)
{