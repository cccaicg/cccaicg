```cpp
/*++
  Purpose:

    Update the window title. This is solely for SDL2 compatibility.

  Parameters:

    [IN]  lpszCaption - specifies the new window title.

    [IN]  lpReserved - unused, retained for compatibility purposes.

  Return value:

    None.

--*/
```
VOID
SDL_WM_SetCaption(
   LPCSTR         lpszCaption,
   LPVOID         lpReserved
)
{