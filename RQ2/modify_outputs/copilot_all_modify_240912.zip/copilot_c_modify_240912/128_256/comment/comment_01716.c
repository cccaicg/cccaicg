/**@brief Function for processing the Connection Parameters Module events.
 *
 * @details This function is invoked for every event within the Connection Parameters Module that is
 *          communicated to the application.
 *          @note The sole function of this method is to initiate a disconnection. Although this could
 *                be accomplished by configuring the disconnect_on_fail parameter, we utilize the
 *                event handler framework here to illustrate its application.
 *
 * @param[in] p_evt  Event data received from the Connection Parameters Module.
 */
static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{