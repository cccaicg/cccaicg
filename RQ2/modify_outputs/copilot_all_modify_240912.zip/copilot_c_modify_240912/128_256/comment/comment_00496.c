/* βδQΪµeԪĶԪ */
Status EnQueue(SqQueue *Q,QElemType e)
{