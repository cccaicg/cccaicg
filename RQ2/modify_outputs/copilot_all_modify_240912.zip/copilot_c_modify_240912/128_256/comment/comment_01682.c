/**
 * Converts integer data for storage in a buffer.
 */
static char *
format_int_data(char * buf, size_t buf_size, const char * desc, const char * units, int data, bool valid)
{