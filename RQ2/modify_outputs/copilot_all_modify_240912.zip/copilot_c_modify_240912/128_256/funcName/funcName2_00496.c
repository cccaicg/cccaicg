/* δԪeΪQµĶβԪ */
Status en_queue(SqQueue *Q,QElemType e)
{