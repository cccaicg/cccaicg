/**@brief Function for initializing the Connection Parameters module.
 */
static void connParamsInit(void)
{