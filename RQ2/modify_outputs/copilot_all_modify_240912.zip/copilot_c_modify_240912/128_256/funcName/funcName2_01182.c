/**
  * @brief  Resets the selected ADC calibration registers.
  * @param  ADCx: where x can be 1, 2 or 3 to select the ADC peripheral.
  * @retval None
  */
void a_d_c__reset_calibration(ADC_TypeDef* ADCx)
{