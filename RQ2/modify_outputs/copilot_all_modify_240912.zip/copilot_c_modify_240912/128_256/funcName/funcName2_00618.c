/* Destroy an entire hash table */
static int dict_clear(dict *ht)
{