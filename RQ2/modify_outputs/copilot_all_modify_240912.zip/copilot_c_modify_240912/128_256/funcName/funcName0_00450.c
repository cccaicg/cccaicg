/* write `len` bytes starting from `buf` into the `offset` of ramdisk */
void ramdiskWrite(uint8_t *buf, uint32_t offset, uint32_t len)
{