/* Create a new hash table */
static dict *DictCreate(dictType *type, void *privDataPtr)
{