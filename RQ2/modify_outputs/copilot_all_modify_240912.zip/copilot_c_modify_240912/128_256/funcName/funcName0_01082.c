/*
 * Here's the routine that will replace the standard error_exit method:
 */
mETHODDEF(void)
extended_error_exit (j_common_ptr cinfo)
{