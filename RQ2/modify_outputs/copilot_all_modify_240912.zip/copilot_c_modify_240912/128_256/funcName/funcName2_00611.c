/* Create a new hash table */
static dict *dict_create(dictType *type, void *privDataPtr)
{