/* δԪeΪQµĶβԪ */
Status enQueue(SqQueue *Q,QElemType e)
{