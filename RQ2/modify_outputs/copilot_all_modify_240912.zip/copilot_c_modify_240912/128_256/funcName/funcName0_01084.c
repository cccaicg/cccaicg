/* JPEG library callback to initialize the input data source.
 */
static void initSource (j_decompress_ptr cinfo)
{