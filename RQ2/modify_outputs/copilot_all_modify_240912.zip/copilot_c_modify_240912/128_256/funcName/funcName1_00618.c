/* Destroy an entire hash table */
static int DictClear(dict *ht)
{