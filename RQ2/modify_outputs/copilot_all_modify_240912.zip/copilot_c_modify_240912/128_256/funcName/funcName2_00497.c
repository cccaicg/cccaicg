/* вգɾQжͷԪأeֵ */
Status de_queue(SqQueue *Q,QElemType *e)
{