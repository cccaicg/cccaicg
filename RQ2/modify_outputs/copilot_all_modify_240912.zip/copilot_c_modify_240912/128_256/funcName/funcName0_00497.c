/* вգɾQжͷԪأeֵ */
Status deQueue(SqQueue *Q,QElemType *e)
{