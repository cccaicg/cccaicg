/*free the above pair again*/
static void StringCleanup(char** out)
{