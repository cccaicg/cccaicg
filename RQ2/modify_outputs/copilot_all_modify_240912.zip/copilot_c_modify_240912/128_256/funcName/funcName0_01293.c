// STBI_NO_HDR
static int stbiBmpInfo(stbi *s, int *x, int *y, int *comp)
{