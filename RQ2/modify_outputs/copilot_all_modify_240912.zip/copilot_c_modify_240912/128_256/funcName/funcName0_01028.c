/*free the above pair again*/
static void stringCleanup(char** out)
{