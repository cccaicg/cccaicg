/* Destroy an entire hash table */
static int dictClear(dict *ht)
{