// A utility function to create a new tree node
struct Node* new_node(int data)
{