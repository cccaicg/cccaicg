/*
 * Return true, if the memcache command is a storage command, otherwise
 * return false
 */
static bool
memcacheStorage(struct msg *r)
{