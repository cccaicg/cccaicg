/* Cursor (logo) based line drawing */
void move_to(COOR x, COOR y)
{