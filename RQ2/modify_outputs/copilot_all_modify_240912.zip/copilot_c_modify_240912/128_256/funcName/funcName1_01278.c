// A utility function to create a new tree node
struct Node* NewNode(int data)
{