/* JPEG library callback to initialize the input data source.
 */
static void InitSource (j_decompress_ptr cinfo)
{