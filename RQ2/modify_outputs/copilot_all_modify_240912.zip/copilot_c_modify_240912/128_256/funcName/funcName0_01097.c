/* JPEG library callback to initialize this module.
 */
void jpegStdioSrc (j_decompress_ptr cinfo, FILE * infile)
{