/* Cursor (logo) based line drawing */
void moveTo(COOR x, COOR y)
{