// STBI_NO_HDR
static int StbiBmpInfo(stbi *s, int *x, int *y, int *comp)
{