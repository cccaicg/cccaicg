/* вգɾQжͷԪأeֵ */
Status DeQueue(QElemType *e, SqQueue *Q)
{