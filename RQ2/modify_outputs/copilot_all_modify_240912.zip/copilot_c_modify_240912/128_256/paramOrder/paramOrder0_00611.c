/* Create a new hash table */
static dict *dictCreate(void *privDataPtr, dictType *type)
{