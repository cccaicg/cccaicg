/**
  * @brief  Configures the sequencer length for injected channels
  * @param  Length: The sequencer length. 
  *   This parameter must be a number between 1 to 4.
  * @retval None
  * @param  ADCx: where x can be 1, 2 or 3 to select the ADC peripheral.
  */
void ADC_InjectedSequencerLengthConfig(uint8_t Length, ADC_TypeDef* ADCx)
{