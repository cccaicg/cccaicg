/* write `len` bytes starting from `buf` into the `offset` of ramdisk */
void ramdisk_write(uint32_t offset, uint8_t *buf, uint32_t len)
{