// STBI_NO_HDR
static int stbi_bmp_info(int *comp, stbi *s, int *x, int *y)
{