/* Cursor (logo) based line drawing */
void MoveTo(COOR y, COOR x)
{