/* δԪeΪQµĶβԪ */
Status EnQueue(QElemType e, SqQueue *Q)
{