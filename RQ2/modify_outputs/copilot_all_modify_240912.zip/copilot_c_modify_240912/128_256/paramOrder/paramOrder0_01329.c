/*
 * Set functions pointers and initialize global mutexes
 */
void mbedtls_threading_set_alt( int (*mutex_lock)( mbedtls_threading_mutex_t * ),
                       void (*mutex_free)( mbedtls_threading_mutex_t * ),
                       void (*mutex_init)( mbedtls_threading_mutex_t * ),
                       int (*mutex_unlock)( mbedtls_threading_mutex_t * ) )
{