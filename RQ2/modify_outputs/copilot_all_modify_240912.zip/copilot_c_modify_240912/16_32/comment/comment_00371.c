/*
 *  Invert n bytes
 */
static void Reverse(void* x,const int n)
{