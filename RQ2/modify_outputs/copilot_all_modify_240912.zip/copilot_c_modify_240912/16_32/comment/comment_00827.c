/**
 * \brief Transform a NMEA degree (NDEG) into radians
 */
double nmea_ndeg2radian(double val)
{