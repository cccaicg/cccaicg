/* transmit a single data byte */
void lcd_txData(uint8_t ch)
{