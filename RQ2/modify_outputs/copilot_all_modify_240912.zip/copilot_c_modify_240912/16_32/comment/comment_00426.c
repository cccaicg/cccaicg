```c
/*
=>   list            = "LIST" followed by a space, then a mailbox, another space, and finally a list-mailbox
*/
```
int mailimap_list_send(mailstream * fd,
				const char * mb,
				const char * list_mb)
{