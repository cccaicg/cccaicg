```c
/*
 * Before accessing the register, IT8671F_CONFIG_REG_LDN (index 0x07) 
 * must be assigned the LDN corresponding to the register's domain.
 */
```
static void it8671f_sio_write(uint8_t ldn, uint8_t index, uint8_t value)
{