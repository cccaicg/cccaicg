/*
** Function optimized for "fasttm" macro when tag methods are not present.
*/
const TValue *luaT_gettm (Table *events, TMS event, TString *ename)
{