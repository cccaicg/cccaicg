/*
 * FUNCTION NAME:	reduce_timer()
 * PURPOSE:		convert fractional component of the timer into full seconds
 */
static
void reduce_timer(mad_timer_t *timer)
{