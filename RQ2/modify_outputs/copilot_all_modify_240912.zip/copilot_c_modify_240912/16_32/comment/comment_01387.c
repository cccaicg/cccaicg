/* Release memory for an index created by build_index() */
local void free_index(struct access *index)
{