/* display an error alert and exit */
void err_quit(char *fmt, ...)
{