/**
 * \brief Transform angular position in radians to an INFOs position format
 */
void nmea_pos2info(const nmeaPOS *pos, nmeaINFO *info)
{