/*******************************************************************************
* Function Name  : I2C_StructInit
* Description    : Initializes each member of I2C_InitStruct to its default settings.
* Input          : - I2C_InitStruct: pointer to an I2C_InitTypeDef structure
*                    that will be set up.
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_StructInit(I2C_InitTypeDef* I2C_InitStruct)
{