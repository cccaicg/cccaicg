/**
 * \brief Transform position from INFO format to radians measurement
 */
void nmea_info2pos(const nmeaINFO *info, nmeaPOS *pos)
{