/**
 * \brief Convert position from INFO to radians position
 */
void nmea_info2pos(nmeaPOS *pos, const nmeaINFO *info)
{