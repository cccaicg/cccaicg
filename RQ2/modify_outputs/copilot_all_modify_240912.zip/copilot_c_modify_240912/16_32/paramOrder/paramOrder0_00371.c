/*
 *  Reverse n bytes
 */
static void Reverse(const int n, void* x)
{