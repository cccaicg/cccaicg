/**
 * \brief Convert radians position to INFOs position
 */
void nmea_pos2info(nmeaINFO *info, const nmeaPOS *pos)
{