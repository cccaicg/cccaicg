/**
 * \brief Convert radians position to INFOs position
 */
void nmeaPos2Info(const nmeaPOS *pos, nmeaINFO *info)
{