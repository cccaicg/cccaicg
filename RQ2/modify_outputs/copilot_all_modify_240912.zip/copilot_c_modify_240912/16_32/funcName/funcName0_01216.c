/* print an error message and quit */
void errQuit(char *fmt, ...)
{