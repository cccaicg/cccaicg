/*
** function to be used with macro "fasttm": optimized for absence of
** tag methods
*/
const TValue *luaTGettm (Table *events, TMS event, TString *ename)
{