/* send a data byte */
void lcdTxData(uint8_t ch)
{