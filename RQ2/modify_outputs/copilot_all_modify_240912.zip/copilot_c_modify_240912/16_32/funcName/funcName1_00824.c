/**
 * \brief Convert radians position to INFOs position
 */
void NmeaPos2Info(const nmeaPOS *pos, nmeaINFO *info)
{