/*
=>   list            = "LIST" SP mailbox SP list-mailbox
*/
int mailimapListSend(mailstream * fd,
				const char * mb,
				const char * list_mb)
{