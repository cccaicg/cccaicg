/**
 * \brief Convert radians position to INFOs position
 */
void nmea_pos_2_info(const nmeaPOS *pos, nmeaINFO *info)
{