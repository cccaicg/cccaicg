/* send a data byte */
void LcdTxData(uint8_t ch)
{