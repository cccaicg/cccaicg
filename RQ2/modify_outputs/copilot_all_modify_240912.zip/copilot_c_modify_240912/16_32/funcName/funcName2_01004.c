/*******************************************************************************
* Function Name  : I2C_struct_init
* Description    : Fills each I2C_InitStruct member with its default value.
* Input          : - I2C_InitStruct: pointer to an I2C_InitTypeDef structure
*                    which will be initialized.
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_struct_init(I2C_InitTypeDef* I2C_InitStruct)
{