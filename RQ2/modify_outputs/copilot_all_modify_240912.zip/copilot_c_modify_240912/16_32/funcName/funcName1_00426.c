/*
=>   list            = "LIST" SP mailbox SP list-mailbox
*/
int MailimapListSend(mailstream * fd,
				const char * mb,
				const char * list_mb)
{