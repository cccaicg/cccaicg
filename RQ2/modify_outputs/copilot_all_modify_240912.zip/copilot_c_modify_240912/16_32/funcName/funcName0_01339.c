/*
 * NAME:	reduceTimer()
 * DESCRIPTION:	carry timer fraction into seconds
 */
static
void reduceTimer(mad_timer_t *timer)
{