/**
 * \brief Convert position from INFO to radians position
 */
void NmeaInfo2Pos(const nmeaINFO *info, nmeaPOS *pos)
{