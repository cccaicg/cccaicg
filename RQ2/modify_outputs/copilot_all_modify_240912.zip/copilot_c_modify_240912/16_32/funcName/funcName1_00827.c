/**
 * \brief Convert NDEG (NMEA degree) to radian
 */
double NmeaNdeg2Radian(double val)
{