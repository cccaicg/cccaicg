/**
 * \brief Convert position from INFO to radians position
 */
void nmeaInfo2Pos(const nmeaINFO *info, nmeaPOS *pos)
{