/* Deallocate an index built by build_index() */
local void freeIndex(struct access *index)
{