/*******************************************************************************
* Function Name  : I2CFastModeDutyCycleConfig
* Description    : Selects the specified I2C fast mode duty cycle.
* Input          : - I2Cx: where x can be 1 or 2 to select the I2C peripheral.
*                  - I2C_DutyCycle: specifies the fast mode duty cycle.
*                    This parameter can be one of the following values:
*                       - I2C_DutyCycle_2: I2C fast mode Tlow/Thigh = 2
*                       - I2C_DutyCycle_16_9: I2C fast mode Tlow/Thigh = 16/9
* Output         : None
* Return         : None
*******************************************************************************/
void I2CFastModeDutyCycleConfig(I2C_TypeDef* I2Cx, u16 I2C_DutyCycle)
{