/*
 * The content of IT8671F_CONFIG_REG_LDN (index 0x07) must be set to the
 * LDN the register belongs to, before you can access the register.
 */
static void It8671fSioWrite(uint8_t ldn, uint8_t index, uint8_t value)
{