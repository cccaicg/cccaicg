/**
 * \brief Convert NDEG (NMEA degree) to radian
 */
double nmea_ndeg_2_radian(double val)
{