/* print an error message and quit */
void ErrQuit(char *fmt, ...)
{