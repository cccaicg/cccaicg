/**
 * \brief Convert position from INFO to radians position
 */
void nmea_info_2_pos(const nmeaINFO *info, nmeaPOS *pos)
{