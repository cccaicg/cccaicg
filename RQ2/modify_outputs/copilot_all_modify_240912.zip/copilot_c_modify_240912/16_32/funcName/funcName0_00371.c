/*
 *  reverse n bytes
 */
static void reverse(void* x,const int n)
{