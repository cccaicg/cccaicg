/*
 * NAME:	ReduceTimer()
 * DESCRIPTION:	carry timer fraction into seconds
 */
static
void ReduceTimer(mad_timer_t *timer)
{