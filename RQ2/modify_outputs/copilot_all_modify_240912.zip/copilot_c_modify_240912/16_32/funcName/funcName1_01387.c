/* Deallocate an index built by build_index() */
local void FreeIndex(struct access *index)
{