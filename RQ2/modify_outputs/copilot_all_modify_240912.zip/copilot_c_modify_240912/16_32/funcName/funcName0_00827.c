/**
 * \brief Convert NDEG (NMEA degree) to radian
 */
double nmeaNdeg2Radian(double val)
{