/* Deallocate an index built by build_index() */
local void free_index(struct access *Index)
{