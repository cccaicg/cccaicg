/**
 * \brief Convert NDEG (NMEA degree) to radian
 */
double nmea_ndeg2radian(double Val)
{