/*
 * The content of IT8671F_CONFIG_REG_LDN (index 0x07) must be set to the
 * LDN the register belongs to, before you can access the register.
 */
static void it8671f_sio_write(uint8_t Ldn, uint8_t Index, uint8_t Value)
{