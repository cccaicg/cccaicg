/**
 * \brief Convert radians position to INFOs position
 */
void nmea_pos2info(const nmeaPOS *Pos, nmeaINFO *Info)
{