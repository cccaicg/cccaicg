/**
 * \brief Convert position from INFO to radians position
 */
void nmea_info2pos(const nmeaINFO *Info, nmeaPOS *Pos)
{