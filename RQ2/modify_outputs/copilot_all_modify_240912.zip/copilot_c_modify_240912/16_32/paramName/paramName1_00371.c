/*
 *  Reverse N bytes
 */
static void Reverse(void* X,const int N)
{