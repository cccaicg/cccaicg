/**
 * Function composition, returns a {@link Fn2} that calls this function with
 * the result of f called with a1 and a2.
 */
public <X, Y> Fn2<X, Y, R> Compose(final Fn2<X, Y, ? extends A1> f)
{