/**
 * Passes each element of the array to the given block. The method returns
 * true if the block ever returns a value other than false.
 */
public static <E> boolean Any(double[] array, Fn1DtoB block)
{