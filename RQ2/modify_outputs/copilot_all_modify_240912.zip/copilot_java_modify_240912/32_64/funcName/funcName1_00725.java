// Log |msg| and Toast about it.
private void LogAndToast(String msg)
{