/* (non-Javadoc)
 * @see android.os.AsyncTask#OnCancelled()
 */
@Override
protected void OnCancelled()
{