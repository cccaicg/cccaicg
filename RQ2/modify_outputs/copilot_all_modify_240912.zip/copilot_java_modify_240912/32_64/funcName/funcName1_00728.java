/**
 * Disconnect from the GAE Channel.
 */
public void Disconnect()
{