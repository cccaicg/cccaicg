//	public ByteBuffer convertWritesToAvro(Row[] ops, 
//			Class<? extends Writable> opClass) {
//		MArrayWritable arrayWritable = new MArrayWritable(opClass, ops);
//		ByteArrayOutputStream bos = new ByteArrayOutputStream();
//		DataOutputStream dos = new DataOutputStream(bos);
//		try {
//			arrayWritable.write(dos);
//			dos.flush();
//			bos.flush();
//		} catch (IOException e) { // This is inconceivable
//			throw new AssertionError(e);
//		}
//		return ByteBuffer.wrap(bos.toByteArray());
//	}
public wALEntry(long n, Map<CmpBytes, List<Put>> puts, 
	Map<CmpBytes, List<Delete>> deletes, Status status)
{