/**
 * @param context
 * @param textViewResourceId
 * @param objects
 */
public wiFiPeerListAdapter(Context context, int textViewResourceId,
        List<WifiP2pDevice> objects)
{