/**
 * Set the target image width and height.
 *
 * @param width
 * @param height
 */
public void SetImageSize(int width, int height)
{