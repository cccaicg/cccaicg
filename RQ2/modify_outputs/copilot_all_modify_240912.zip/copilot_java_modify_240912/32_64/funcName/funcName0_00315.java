/**
 * @param manager WifiP2pManager system service
 * @param channel Wifi p2p channel
 * @param activity activity associated with the receiver
 */
public wiFiDirectBroadcastReceiver(AppNetService service, WifiP2pNetServiceListener listener)
{