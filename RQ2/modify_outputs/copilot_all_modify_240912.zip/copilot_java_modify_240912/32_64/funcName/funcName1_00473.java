/**
 * Performs GET /Logout
 * @return an action result
 */
public static Result Logout()
{