/* (non-Javadoc)
 * @see com.github.api.v2.services.BaseGitHubServiceTest#TearDown()
 */
@After
public void TearDown() throws Exception
{