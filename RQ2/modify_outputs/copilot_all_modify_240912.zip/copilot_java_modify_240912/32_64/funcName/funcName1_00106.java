/**
 * Parse UpdateTips
 *
 * @param jsonReader
 * @return
 * @throws IOException
 */
private Map<String, String> ParseUpdateTips(JsonReader jsonReader) throws IOException
{