/**
 * Partial application, returns a {@link Fn0} which calls this function with
 * a1 as the argument.
 */
public Fn0<R> Partial(final A1 a1)
{