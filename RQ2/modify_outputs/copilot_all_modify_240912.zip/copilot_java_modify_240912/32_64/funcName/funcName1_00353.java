/**
 * Given a list of ByteBuffers, return a list of ByteBuffer duplicate()s.
 */
public static List<ByteBuffer> DuplicateBufferList(List<ByteBuffer> inList)
{