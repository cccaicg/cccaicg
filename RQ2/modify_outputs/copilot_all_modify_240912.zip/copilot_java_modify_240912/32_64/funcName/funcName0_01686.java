/**
 * UTF8 -> GBK
 * 
 * @param utf
 * @return
 */
public static String utf82Gbk(String utf)
{