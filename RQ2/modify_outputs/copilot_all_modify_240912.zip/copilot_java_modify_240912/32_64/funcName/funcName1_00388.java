/**
 * get simple job status
 * @param status hadoop job status
 * @return job status
 * @throws Exception
 */
private String GetSimpleJobStatus(int status) throws IOException
{