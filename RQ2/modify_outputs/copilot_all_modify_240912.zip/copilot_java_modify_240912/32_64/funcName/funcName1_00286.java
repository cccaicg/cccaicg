/**
 * Guarantees that all of len bytes are actually read off the transport.
 *
 * @param buf Array to read into
 * @param off Index to start reading at
 * @param len Maximum number of bytes to read
 * @return The number of bytes actually read, which must be equal to len
 * @throws TTransportException if there was an error reading data
 */
public int ReadAll(byte[] buf, int off, int len)
  throws TTransportException
{