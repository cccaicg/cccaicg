/**
 *  toString() provides a String depiction of this DList.
 *
 *  PLEASE DO NOT MODIFY THIS METHOD.
 *
 *  @return a String depiction of this DList.
 */
public String toString()
{