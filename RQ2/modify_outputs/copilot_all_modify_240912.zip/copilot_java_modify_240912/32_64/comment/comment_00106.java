/**
 * Interpret UpdateTips
 *
 * @param jsonReader
 * @return
 * @throws IOException
 */
private Map<String, String> parseUpdateTips(JsonReader jsonReader) throws IOException
{