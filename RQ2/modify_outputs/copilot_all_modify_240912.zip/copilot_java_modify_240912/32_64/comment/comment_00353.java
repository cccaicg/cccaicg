/**
 * Returns a list containing duplicate()s of each ByteBuffer from an input list.
 */
public static List<ByteBuffer> duplicateBufferList(List<ByteBuffer> inList)
{