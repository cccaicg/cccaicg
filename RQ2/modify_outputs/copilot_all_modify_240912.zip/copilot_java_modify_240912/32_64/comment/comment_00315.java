/**
 * @param manager The system service for WifiP2pManager
 * @param channel The channel used for Wifi peer-to-peer communication
 * @param activity The activity linked to the receiver
 */
public WiFiDirectBroadcastReceiver(AppNetService service, WifiP2pNetServiceListener listener)
{