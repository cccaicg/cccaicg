/**
 * Generates and provides a complete duplicate of this {@link GeometryCollection} instance,
 * encompassing all of its contained coordinates.
 *
 * @return a replica of this object
 */
public Object clone()
{