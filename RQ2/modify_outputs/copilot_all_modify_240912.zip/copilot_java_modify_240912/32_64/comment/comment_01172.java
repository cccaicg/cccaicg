/**
 * Converts a quoted-printable string back to its initial form. Encoded characters are reverted to their original state.
 * 
 * @param pObject
 *                  The quoted-printable input to be transformed back to its initial form.
 * 
 * @return the restored original object
 * 
 * @throws DecoderException
 *                  Raised if the input is not a <code>String</code> or if an error occurs during decoding.
 */
public Object decode(Object pObject) throws DecoderException
{