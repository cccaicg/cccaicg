/**
 * Updates the header's status.
 * 
 * @param status
 * @return
 */
public ResponseBuilder status(int code, String message)
{