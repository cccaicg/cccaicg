/**
 * Convert UTF8 to GBK
 *
 * @param utf
 * @return
 */
public static String utf82gbk(String utf)
{