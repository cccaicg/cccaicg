/* (overrides method)
 * @refer to android.os.AsyncTask#onCancelled()
 */
@Override
protected void onCancelled()
{