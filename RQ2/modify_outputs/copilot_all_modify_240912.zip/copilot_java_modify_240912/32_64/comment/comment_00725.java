// Display |msg| in the logs and show a Toast notification.
private void logAndToast(String msg)
{