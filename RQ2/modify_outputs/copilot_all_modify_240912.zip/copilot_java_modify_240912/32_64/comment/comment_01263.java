// attach descriptive information to the PDF, accessible in Adobe Reader
	// through File -> Properties
private void addMetaData(Document document)
{