/**
 * Composes two functions, producing a {@link Fn2} that invokes this function using
 * the output from applying f with inputs a1 and a2.
 */
public <X, Y> Fn2<X, Y, R> compose(final Fn2<X, Y, ? extends A1> f)
{