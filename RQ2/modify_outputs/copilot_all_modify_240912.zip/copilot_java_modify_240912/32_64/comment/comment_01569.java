/**
 * Internal utility that contains the list of tables which {@link LocalyticsProvider} has access to handle.
 *
 * @return produces a set of the permissible tables.
 */
private static Set<String> getValidTables()
{