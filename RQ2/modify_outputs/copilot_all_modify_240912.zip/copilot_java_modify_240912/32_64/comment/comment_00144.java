/**
 * Iterates over each item in the array, passing it to the specified block. The method
 * will return true if the block returns a non-false value at any point.
 */
public static <E> boolean any(double[] array, Fn1DtoB block)
{