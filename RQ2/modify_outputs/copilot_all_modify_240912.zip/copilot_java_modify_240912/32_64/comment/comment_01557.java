/**
 * Builds a string for indentation.
 * @param indent the count of indentation units
 */
public String makeIndent(int indent)
{