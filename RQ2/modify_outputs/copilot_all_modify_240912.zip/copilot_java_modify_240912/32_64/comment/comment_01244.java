/**
 * 读取文件信息
 * 
 * @param fileName
 * @return
 */
private String getInfoFromFile(String fileName)
{