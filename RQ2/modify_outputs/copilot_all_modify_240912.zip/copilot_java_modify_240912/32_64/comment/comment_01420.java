```java
/*
public void setRow(int row, String[] pieces) {
  checkSize(row, pieces.length - 1);
  // pieces.length might be less than columns.length, so iterate over pieces
  for (int col = 0; col < pieces.length; col++) {
    setRowCol(row, col, pieces[col]);
  }
}


protected void setRowCol(int row, int col, String piece) {
  switch (columnTypes[col]) {
  case STRING:
    String[] stringData = (String[]) columns[col];
    stringData[row] = piece;
    break;
  case INT:
    int[] intData = (int[]) columns[col];
    intData[row] = PApplet.parseInt(piece, missingInt);
    break;
  case LONG:
    long[] longData = (long[]) columns[col];
    try {
      longData[row] = Long.parseLong(piece);
    } catch (NumberFormatException nfe) {
      longData[row] = missingLong;
    }
    break;
  case FLOAT:
    float[] floatData = (float[]) columns[col];
    floatData[row] = PApplet.parseFloat(piece, missingFloat);
    break;
  case DOUBLE:
    double[] doubleData = (double[]) columns[col];
    try {
      doubleData[row] = Double.parseDouble(piece);
    } catch (NumberFormatException nfe) {
      doubleData[row] = missingDouble;
    }
public void setRow(int row, Object[] pieces)
{