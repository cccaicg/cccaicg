/**
 * Ensures all specified len bytes are fully read from the transport.
 *
 * @param buf Buffer array for storing read bytes
 * @param off Starting position for reading
 * @param len Total bytes to read
 * @return The exact count of bytes read, which should match len
 * @throws TTransportException if an error occurs while reading
 */
public int readAll(byte[] buf, int off, int len)
  throws TTransportException
{