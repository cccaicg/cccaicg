```java
/**
 * @param context The environment used for the adapter
 * @param textViewResourceId The resource ID for a TextView
 * @param objects The data set to be represented in the ListView
 */
```
public WiFiPeerListAdapter(Context context, int textViewResourceId,
        List<WifiP2pDevice> objects)
{