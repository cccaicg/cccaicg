/**
 * Retrieve basic job status
 * @param status Status of the Hadoop job
 * @return Current job status
 * @throws Exception
 */
private String getSimpleJobStatus(int status) throws IOException
{