/**
 * Define the width and height for the destination image.
 *
 * @param width
 * @param height
 */
public void setImageSize(int width, int height)
{