/**
 *  insertFront() adds an element to the beginning of a DList2.
 */
public void insertFront(int i)
{