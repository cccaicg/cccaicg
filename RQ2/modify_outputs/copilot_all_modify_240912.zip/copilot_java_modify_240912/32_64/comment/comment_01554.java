/**
 * Provides the root node of the tree to which this node belongs.
 * @return the {@link AstRoot} located at the top of this node's parent
 * hierarchy, or {@code null} if the highest parent isn't an {@code AstRoot}.
 */
public AstRoot getAstRoot()
{