/* (overridden method)
 * @refer com.github.api.v2.services.BaseGitHubServiceTest#tearDown()
 */
@After
public void tearDown() throws Exception
{