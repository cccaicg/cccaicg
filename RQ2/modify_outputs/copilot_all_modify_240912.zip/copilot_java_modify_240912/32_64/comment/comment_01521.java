/**
 * Terminates all requests within this queue that match the specified filter criteria.
 * @param filter The function used to determine applicable requests
 */
public void cancelAll(RequestFilter filter)
{