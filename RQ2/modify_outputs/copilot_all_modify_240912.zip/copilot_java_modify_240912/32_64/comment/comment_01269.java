////// ****  Halts Audio Playback When Dialog Closes *****  ///////
@Override
public void onDismiss(DialogInterface dialog)
{