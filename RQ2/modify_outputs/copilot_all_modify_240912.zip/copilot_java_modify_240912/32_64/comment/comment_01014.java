/**
 * Increases the count for a specified (key, value) pair.
 */
public void incrementCount(K key, V value, double count)
{