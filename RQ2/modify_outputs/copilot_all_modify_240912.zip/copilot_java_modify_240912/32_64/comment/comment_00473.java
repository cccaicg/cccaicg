/**
 * Executes a GET request to /logout
 * @return the result of the action
 */
public static Result logout()
{