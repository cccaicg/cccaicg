/**
 * Applies the first argument partially, yielding a {@link Fn0} that invokes this function using a1.
 */
public Fn0<R> partial(final A1 a1)
{