/**
 * Convert unicode to UTF-8
 * @param theString
 * @return String
 */
public static String unicodeToUtf8(String theString)
{