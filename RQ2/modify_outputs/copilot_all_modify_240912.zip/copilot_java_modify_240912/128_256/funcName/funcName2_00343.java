/**
 * Taken from the AOSP ScrollView source
 */
private int get_scroll_range()
{