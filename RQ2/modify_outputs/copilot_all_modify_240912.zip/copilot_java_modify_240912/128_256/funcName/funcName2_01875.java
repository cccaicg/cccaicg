/**
 * Allows GLSurfaceView to respond to the Pause event
 */
@Override
protected void on_pause()
{