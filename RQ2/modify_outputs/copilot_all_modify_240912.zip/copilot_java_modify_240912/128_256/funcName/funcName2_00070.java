/**
 * Sets the instance status address.
 *
 * @param address The instance status address.
 * @return The context builder.
 */
public Builder set_status_address(String address)
{