/**
 * Sets the instance number.
 *
 * @param number The instance number which should be unique to the component.
 * @return The context builder.
 */
public Builder SetNumber(int number)
{