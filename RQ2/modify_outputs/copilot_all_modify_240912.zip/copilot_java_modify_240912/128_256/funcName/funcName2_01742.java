/**
 * Dispose all of the cached cursors.
 */
public static void dispose_cursors()
{