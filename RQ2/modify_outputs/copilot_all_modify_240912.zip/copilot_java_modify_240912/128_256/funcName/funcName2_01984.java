/**
 *
 * @return The total quantity of all items
 */
@Transient
public int get_quantity_total()
{