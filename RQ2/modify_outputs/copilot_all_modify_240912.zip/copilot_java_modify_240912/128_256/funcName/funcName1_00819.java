/**
 * Enable or disable to add a node.
 * 
 * @param enabled
 */
private void SetEnableAddNode( final boolean enabled )
{