/**
 * Get the {@link ApplicationDefinition} associated with this request's
 * "{application}". If this is not an application command, a RuntimeException is
 * thrown.
 * 
 * @return {@link ApplicationDefinition} associated with this request. 
 *         Will not be null.
 * @throws NotFoundException if the application requested by this request is not
 *         defined.
 */
public ApplicationDefinition GetAppDef() throws NotFoundException
{