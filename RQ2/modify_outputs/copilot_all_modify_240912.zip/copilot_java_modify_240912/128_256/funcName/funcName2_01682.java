/**
 * Sets basic authentication for the request. You should pass in your
 * AuthScope for security. It should be like this
 * set_basic_auth("username","password", new
 * AuthScope("host",port,AuthScope.ANY_REALM))
 *
 * @param user
 * @param pass
 * @param scope
 *            - an AuthScope object
 *
 */
public void set_basic_auth(String user, String pass, AuthScope scope)
{