/***********************
 * process_window_event() processes the close window event
 * 
 * @param e
 *            The window event to process
 * 
 **/
protected void process_window_event(WindowEvent e)
{