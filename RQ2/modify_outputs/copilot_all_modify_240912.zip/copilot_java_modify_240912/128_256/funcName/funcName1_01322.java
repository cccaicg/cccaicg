// Poor-man's assert(): die with |msg| unless |condition| is true.
private static void AbortUnless(boolean condition, String msg)
{