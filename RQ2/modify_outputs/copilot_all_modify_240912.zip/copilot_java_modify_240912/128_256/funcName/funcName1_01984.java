/**
 *
 * @return The total quantity of all items
 */
@Transient
public int GetQuantityTotal()
{