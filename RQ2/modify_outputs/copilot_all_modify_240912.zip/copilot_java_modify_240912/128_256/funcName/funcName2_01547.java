/**
 * The header transformer to be used to transfer the header view. If
 * null, an instance of {@link DefaultHeaderTransformer} will be used.
 */
public Builder header_transformer(HeaderTransformer header_transformer)
{