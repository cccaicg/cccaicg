// 用jdk实现:MD2
public static void JdkMD2()
{