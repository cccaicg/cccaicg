/** 
 * Constructor.
 */
public cartesianView(Context context,AttributeSet attrs)
{