/**
 * Change a list of points in an encoded string into a usable list.
 * 
 * @param encoded
 *            The encoded string received from google
 * @return a usable list
 */
public static ArrayList<GeoPoint> DecodePolyline(String encoded)
{