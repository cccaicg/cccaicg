/**
 * Dispose all of the cached cursors.
 */
public static void DisposeCursors()
{