/**
 * Signals for the background thread to shutdown and waits for its execution to finish.
 * @throws InterruptedException if the calling thread is interrupted while waiting for
 * the background thread to {@link Thread#join()}.
 */
public void stop_monitoring() throws InterruptedException
{