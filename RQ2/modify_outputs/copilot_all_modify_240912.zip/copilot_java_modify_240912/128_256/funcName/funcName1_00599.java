/**
 * Closes the cache and Deletes all of its stored values. This will Delete
 * all files in the cache directory including files that weren't created by
 * the cache.
 */
public void Delete() throws IOException
{