/**
 * Construct a timer with a specific start time and length.
 *
 * @param startTime the start time of the timer.
 * @param timerLength the length of the timer.
 */
public timer_obj(long startTime, long timerLength)
{