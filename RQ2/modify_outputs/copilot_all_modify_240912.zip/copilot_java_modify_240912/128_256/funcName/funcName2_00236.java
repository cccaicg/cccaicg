/**
 * 设置数据和数据类型
 * @param type 类型
 * @param data 数据
 */
public void set_data_and_type(AdapterType type, ISearchAdapter data)
{