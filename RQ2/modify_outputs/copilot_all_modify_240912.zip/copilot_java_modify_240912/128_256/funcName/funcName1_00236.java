/**
 * 设置数据和数据类型
 * @param type 类型
 * @param data 数据
 */
public void SetDataAndType(AdapterType type, ISearchAdapter data)
{