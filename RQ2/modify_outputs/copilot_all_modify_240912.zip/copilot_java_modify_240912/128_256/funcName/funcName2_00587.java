/**
 * Returns the remainder of 'reader' as a string, closing it when done.
 */
public static String read_fully(Reader reader) throws IOException
{