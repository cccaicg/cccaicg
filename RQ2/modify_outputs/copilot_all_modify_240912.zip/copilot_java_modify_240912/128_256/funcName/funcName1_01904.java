// 用bouncy castle实现
public static void BouncyCastleBase64()
{