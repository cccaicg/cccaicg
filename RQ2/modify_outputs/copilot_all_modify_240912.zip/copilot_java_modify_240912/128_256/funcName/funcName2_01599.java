/**
 * Constructs a new p_x_shape_view.
 * 
 * @param context
 * @param attrs
 * @param defStyle
 */
public p_x_shape_view(Context context, AttributeSet attrs, int defStyle)
{