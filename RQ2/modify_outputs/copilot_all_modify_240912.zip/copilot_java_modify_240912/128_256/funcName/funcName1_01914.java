// 用jdk实现:MD5
public static void JdkMD5()
{