/**
 * 根据当前所在线程更新界面
 */
private void InvalidateView()
{