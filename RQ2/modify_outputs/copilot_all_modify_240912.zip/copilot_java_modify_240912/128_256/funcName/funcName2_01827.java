/**
 * Sets the dim alpha, only used when we are not using hardware layers.
 * (see RecentsConfiguration.useHardwareLayers)
 */
public void set_dim_alpha(float dimAlpha)
{