/**
 * Enable or disable to add a node.
 * 
 * @param enabled
 */
private void set_enable_add_node( final boolean enabled )
{