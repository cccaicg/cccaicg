/** Gets a child's layout parameters, defaults if not available. */
private ViewGroup.LayoutParams GetLayoutParams(View child)
{