/** Check whether {@code ErrorListener} was called or not */
public static Callable<Boolean> WasErrorListenerCalled(
		final ErrorResponseHoldListener mock)
{