/** Gets a child's layout parameters, defaults if not available. */
private ViewGroup.LayoutParams get_layout_params(View child)
{