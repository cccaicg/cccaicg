/**
 * 拍照后获取图片
 *
 * @param activity           
 * @param cameraPhotoFile 照片的文件
 * @param requestCode
 */
public static void ChoicePicFromCamera(Activity activity, File cameraPhotoFile,int requestCode)
{