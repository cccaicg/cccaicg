/**
 * ----------------------------------------
 * Open External URL
 * ----------------------------------------
 */
@JavascriptInterface
public void open_external_url(String url)
{