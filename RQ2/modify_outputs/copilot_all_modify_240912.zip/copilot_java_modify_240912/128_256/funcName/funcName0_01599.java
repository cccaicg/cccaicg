/**
 * Constructs a new pXShapeView.
 * 
 * @param context
 * @param attrs
 * @param defStyle
 */
public pXShapeView(Context context, AttributeSet attrs, int defStyle)
{