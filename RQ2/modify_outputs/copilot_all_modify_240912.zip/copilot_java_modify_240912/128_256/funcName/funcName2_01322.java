// Poor-man's assert(): die with |msg| unless |condition| is true.
private static void abort_unless(boolean condition, String msg)
{