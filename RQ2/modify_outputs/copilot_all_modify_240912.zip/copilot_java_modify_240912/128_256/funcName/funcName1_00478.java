/**
 * Write bytes to output or random access file.
 * @param data the byte array to write
 * @param offset the start position to write from
 * @param length the number of bytes to write
 * @throws IOException on error
 */
protected final void WriteOut(byte[] data, int offset, int length)
        throws IOException
{