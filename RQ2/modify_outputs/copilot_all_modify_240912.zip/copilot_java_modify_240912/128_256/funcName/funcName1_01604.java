/**
 * obtain the image rotation angle
 *
 * @param path path of target image
 */
private int GetImageSpinAngle(String path)
{