/**
 * Taken from the AOSP ScrollView source
 */
private int GetScrollRange()
{