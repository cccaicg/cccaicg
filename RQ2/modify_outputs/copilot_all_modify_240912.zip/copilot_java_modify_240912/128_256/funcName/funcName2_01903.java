// 用jdk实现:MD2
public static void jdk_MD2()
{