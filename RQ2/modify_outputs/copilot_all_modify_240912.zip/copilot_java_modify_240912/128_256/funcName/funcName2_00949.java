/**
 * Set Show time in milliseconds
 */
public static BannerTime shown_time(int time)
{