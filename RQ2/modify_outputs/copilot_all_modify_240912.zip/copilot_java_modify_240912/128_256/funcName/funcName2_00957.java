/**
 * Set touch overlay detection
 *
 * @param touchOverlay The desired overlay touch.
 */
public static BannerTime set_touch_overlay(boolean touchOverlay)
{