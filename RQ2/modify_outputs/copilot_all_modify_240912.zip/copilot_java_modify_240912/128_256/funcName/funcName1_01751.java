/**
 * Dispose of all the cached {@link Color}'s.
 */
public static void DisposeColors()
{