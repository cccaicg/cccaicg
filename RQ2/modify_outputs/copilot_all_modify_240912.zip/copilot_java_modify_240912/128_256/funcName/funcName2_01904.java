// 用bouncy castle实现
public static void bouncy_castle_base64()
{