/**
 * 根据传入视频的大小设置，设置视频的画面大小
 *
 * @param screenWidth
 * @param screeHeight
 */
public void SetViewSize(int screenWidth, int screeHeight)
{