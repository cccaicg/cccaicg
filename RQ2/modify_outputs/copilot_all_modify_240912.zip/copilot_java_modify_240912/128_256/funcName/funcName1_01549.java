/**
 * EnvironmentDelegate instance which will be used. If null, we will
 * create an instance of the default class.
 */
public Builder EnvironmentDelegate(EnvironmentDelegate EnvironmentDelegate)
{