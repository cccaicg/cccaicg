/**
 * Returns the remainder of 'reader' as a string, closing it when done.
 */
public static String ReadFully(Reader reader) throws IOException
{