/**
 * Sets a background task to kill the child process of this monitor
 * if it's taking too long to produce data.  Caller holds reference to passed
 * object and calls {@link KillTimerTask#cancel()} once background work has completed.
 *
 * @param delay millis to wait before killing background process
 * @see Timer
 * @return {@link KillTimerTask} object used to cancel timer.
 */
private KillTimerTask SetKillTimer(long delay)
{