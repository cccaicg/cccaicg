/** Check whether {@code ErrorListener} was called or not */
public static Callable<Boolean> was_error_listener_called(
		final ErrorResponseHoldListener mock)
{