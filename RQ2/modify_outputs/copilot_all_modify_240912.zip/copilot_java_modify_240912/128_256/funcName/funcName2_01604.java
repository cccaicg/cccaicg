/**
 * obtain the image rotation angle
 *
 * @param path path of target image
 */
private int get_image_spin_angle(String path)
{