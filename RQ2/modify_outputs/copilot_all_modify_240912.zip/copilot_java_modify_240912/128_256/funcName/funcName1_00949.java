/**
 * Set Show time in milliseconds
 */
public static BannerTime ShownTime(int time)
{