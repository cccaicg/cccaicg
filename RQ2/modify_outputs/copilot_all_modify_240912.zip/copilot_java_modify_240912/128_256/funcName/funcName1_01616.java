/**
 * 将子线程结果传递到UI线程
 *
 * @param worker
 * @return
 */
private void PostCancel(final Worker worker)
{