/**
 * 请求刷新当前View显示，会重新分配布局
 */
public void RefreshView()
{