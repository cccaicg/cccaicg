// 用jdk实现:MD5
public static void jdk_MD5()
{