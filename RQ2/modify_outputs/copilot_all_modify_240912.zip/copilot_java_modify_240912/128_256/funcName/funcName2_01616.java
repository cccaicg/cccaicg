/**
 * 将子线程结果传递到UI线程
 *
 * @param worker
 * @return
 */
private void post_cancel(final Worker worker)
{