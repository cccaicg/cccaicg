/**
 * Specify if all files read by this fetcher must get the same streamId (default is false). If set to true all files read will get
 * the same streamId and frame numbering is continued (as if the files form a continuous stream)
 * @param value
 * @return
 */
public FileFrameFetcher SingleId (boolean value)
{