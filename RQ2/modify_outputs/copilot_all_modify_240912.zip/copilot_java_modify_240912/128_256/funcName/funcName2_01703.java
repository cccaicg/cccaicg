/** 
 * Constructor.
 */
public cartesian_view(Context context,AttributeSet attrs)
{