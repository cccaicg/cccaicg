/**
 * ----------------------------------------
 * Open External URL
 * ----------------------------------------
 */
@JavascriptInterface
public void OpenExternalUrl(String url)
{