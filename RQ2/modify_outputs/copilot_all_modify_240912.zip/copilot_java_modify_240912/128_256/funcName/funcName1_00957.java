/**
 * Set touch overlay detection
 *
 * @param touchOverlay The desired overlay touch.
 */
public static BannerTime SetTouchOverlay(boolean touchOverlay)
{