/**
 * Disable the header 'minimization', which by default means that the majority of
 * the header is hidden, leaving only the progress bar still showing.
 */
public Builder NoMinimize()
{