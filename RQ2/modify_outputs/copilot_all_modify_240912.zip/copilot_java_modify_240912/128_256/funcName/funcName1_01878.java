/**
 * Creates a buffer of floats using memory outside the normal, garbage collected heap
 * 
 * @param capacity		The number of primitives to create in the buffer.
 */
public static FloatBuffer CreateFloatBuffer(int capacity)
{