/**
 * Request to refresh the current View display, which will reassign the layout
 */
public void refreshView()
{