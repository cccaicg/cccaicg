/** Retrieves a child's layout parameters, using defaults if unspecified. */
private ViewGroup.LayoutParams getLayoutParams(View child)
{