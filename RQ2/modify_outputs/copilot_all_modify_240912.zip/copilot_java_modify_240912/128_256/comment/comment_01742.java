/**
 * Release all stored cursors from cache.
 */
public static void disposeCursors()
{