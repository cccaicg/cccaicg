/**
 * Captures image after taking a photo
 *
 * @param activity           
 * @param cameraPhotoFile File where the photo is stored
 * @param requestCode
 */
public static void choicePicFromCamera(Activity activity, File cameraPhotoFile,int requestCode)
{