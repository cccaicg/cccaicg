/**
 * Assigns the data and its corresponding type
 * @param type The data type
 * @param data The actual data
 */
public void setDataAndType(AdapterType type, ISearchAdapter data)
{