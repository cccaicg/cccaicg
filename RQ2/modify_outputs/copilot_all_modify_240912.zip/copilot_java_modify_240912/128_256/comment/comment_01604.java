/**
 * Retrieve the angle of image rotation
 *
 * @param path path to the desired image
 */
private int getImageSpinAngle(String path)
{