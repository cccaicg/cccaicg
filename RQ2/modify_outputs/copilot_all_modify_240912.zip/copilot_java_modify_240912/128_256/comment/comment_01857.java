/**
 * Indicate whether to assign a consistent streamId to all files accessed by this fetcher (default setting is false). Enabling this option ensures all read files share the same streamId, with frame numbering progressing seamlessly (similar to a unified stream)
 * @param value
 * @return
 */
public FileFrameFetcher singleId (boolean value)
{