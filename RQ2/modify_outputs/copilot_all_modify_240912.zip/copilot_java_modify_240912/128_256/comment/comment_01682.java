/**
 * Configures the request with basic authentication. It is important to
 * provide your AuthScope for enhanced security. The usage should be
 * similar to setBasicAuth("username","password", new
 * AuthScope("host",port,AuthScope.ANY_REALM))
 *
 * @param user
 * @param pass
 * @param scope
 *            - an AuthScope object
 *
 */
public void setBasicAuth(String user, String pass, AuthScope scope)
{