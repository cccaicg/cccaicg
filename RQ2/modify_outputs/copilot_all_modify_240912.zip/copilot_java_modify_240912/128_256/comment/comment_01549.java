/**
 * Instance of EnvironmentDelegate that will be utilized. If it's null,
 * an instance of the default class will be instantiated.
 */
public Builder environmentDelegate(EnvironmentDelegate environmentDelegate)
{