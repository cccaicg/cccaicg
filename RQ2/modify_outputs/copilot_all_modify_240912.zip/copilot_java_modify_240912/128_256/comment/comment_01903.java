// Implemented using JDK: MD2
public static void jdkMD2()
{