/**
 * Output bytes to a file, supporting both sequential and random access.
 * @param data the array of bytes to be outputted
 * @param offset the initial position in the array to begin writing
 * @param length the total count of bytes to be written
 * @throws IOException if an error occurs during the operation
 */
protected final void writeOut(byte[] data, int offset, int length)
        throws IOException
{