/**
 * 设置视频显示尺寸以匹配提供的视频大小设置
 *
 * @param screenWidth
 * @param screenHeight
 */
public void setViewSize(int screenWidth, int screeHeight)
{