/**
 * Configure the detection for touch overlay
 *
 * @param touchOverlay The specified overlay for touch detection.
 */
public static BannerTime setTouchOverlay(boolean touchOverlay)
{