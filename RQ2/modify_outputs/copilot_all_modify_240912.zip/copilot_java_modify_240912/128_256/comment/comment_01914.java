// Implement MD5 using JDK
public static void jdkMD5()
{