/**
 * Empty the reusability cache list
 */
private void resetRecycler()
{