/**
 * Release all the stored instances of {@link Color}.
 */
public static void disposeColors()
{