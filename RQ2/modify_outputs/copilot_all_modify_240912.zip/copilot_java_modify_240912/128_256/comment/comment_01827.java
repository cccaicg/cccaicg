/**
 * Adjusts the dim alpha, applicable only when hardware layers are not utilized.
 * (refer to RecentsConfiguration.useHardwareLayers)
 */
public void setDimAlpha(float dimAlpha)
{