```
// Implemented using Bouncy Castle
```
public static void bouncyCastleBase64()
{