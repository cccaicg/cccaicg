/**
 * Clears the buffer of this output stream, ensuring all buffered data
 * is transmitted to the stream.
 *
 * @exception  IOException  if an input/output error occurs.
 */
@Override
public void flush() throws IOException
{