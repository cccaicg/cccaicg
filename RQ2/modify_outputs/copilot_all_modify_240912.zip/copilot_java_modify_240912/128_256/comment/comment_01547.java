/**
 * The header transformer designated for updating the header view. 
 * If set to null, a {@link DefaultHeaderTransformer} instance will 
 * be utilized by default.
 */
public Builder headerTransformer(HeaderTransformer headerTransformer)
{