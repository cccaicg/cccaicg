/**
 * Assigns the instance identifier.
 *
 * @param number The unique identifier for the component instance.
 * @return The context builder.
 */
public Builder setNumber(int number)
{