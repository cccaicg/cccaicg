/**
 * Initializes a new instance of PXShapeView.
 * 
 * @param context
 * @param attrs
 * @param defStyle
 */
public PXShapeView(Context context, AttributeSet attrs, int defStyle)
{