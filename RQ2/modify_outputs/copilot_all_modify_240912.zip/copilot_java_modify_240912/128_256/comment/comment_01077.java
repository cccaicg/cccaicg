/**
 * ----------------------------------------
 * Launch URL in External Browser
 * ----------------------------------------
 */
@JavascriptInterface
public void openExternalUrl(String url)
{