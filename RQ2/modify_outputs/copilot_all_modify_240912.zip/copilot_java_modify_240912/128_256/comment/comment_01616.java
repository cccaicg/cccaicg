/**
 * 将子线程的计算结果传递到UI主线程
 *
 * @param worker
 * @return
 */
private void postCancel(final Worker worker)
{