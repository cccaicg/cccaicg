/**
 * Configure display duration in milliseconds
 */
public static BannerTime shownTime(int time)
{