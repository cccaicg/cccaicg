/**
 * Instantiates a {@code UnknownAnnotationValueException}. The
 * {@code p} argument allows for passing supplementary data regarding 
 * the situation where the unknown annotation value was found; for instance, 
 * the visit methods from {@link AnnotationValueVisitor} could utilize it 
 * to pass their extra argument.
 *
 * @param av the unidentified annotation value, can be {@code null}
 * @param p an extra parameter, can be {@code null}
 */
public UnknownAnnotationValueException(AnnotationValue av, Object p)
{