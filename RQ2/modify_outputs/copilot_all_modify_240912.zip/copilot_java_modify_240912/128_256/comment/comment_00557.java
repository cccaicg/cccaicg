/**
 * Logs a warning
 * @param msg the message to log
 */
public static void w(String msg)
{