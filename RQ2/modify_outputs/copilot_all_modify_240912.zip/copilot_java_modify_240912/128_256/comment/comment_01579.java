/**
 * Retrieve the value stored in the data column for the specified Uri. 
 * This is particularly beneficial for MediaStore Uris and other 
 * file-oriented ContentProviders.
 *
 * @param context The context in use.
 * @param uri The Uri to be queried.
 * @param selection (Optional) Criteria to filter the query.
 * @param selectionArgs (Optional) Arguments for the selection criteria.
 * @return The value from the _data column, generally a file path.
 */
private static String getDataColumn(Context context, Uri uri, String selection,
        String[] selectionArgs)
{