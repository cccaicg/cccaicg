/**
 * 寻找特定节点在中序遍历中的直接后继节点，该方法的实现与二叉搜索树类（BinSearchTree.java）中的方法相同，
 * 详细思路请参阅二叉搜索树类的对应方法
 *
 * @param e 要查找直接后继节点的节点
 * @return Entry<E> 中序后继节点
 */
private Entry<E> successor(Entry<E> e)
{