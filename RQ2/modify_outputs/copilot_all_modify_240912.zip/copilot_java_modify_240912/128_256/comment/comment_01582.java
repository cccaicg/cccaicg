/**
 * Sets up a newly created line with the given x and y positions
 * 
 * @param x1 The x position of the line's starting point
 * @param y1 The y position of the line's starting point
 * @param x2 The x position of the line's endpoint
 * @param y2 The y position of the line's endpoint
 */
public PXLine(float x1, float y1, float x2, float y2)
{