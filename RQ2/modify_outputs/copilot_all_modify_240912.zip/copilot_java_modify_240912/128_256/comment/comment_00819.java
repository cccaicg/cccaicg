/**
 * Toggle the option to insert a node.
 * 
 * @param enabled
 */
private void setEnableAddNode( final boolean enabled )
{