/** 
 * Initializes a new instance.
 */
public CartesianView(Context context,AttributeSet attrs)
{