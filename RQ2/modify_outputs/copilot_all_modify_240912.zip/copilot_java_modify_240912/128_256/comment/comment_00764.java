/**
 * 使用对方的公钥和个人的私钥创建本地密钥
 */
public static byte[] getSecretKey(byte[] publicKey, byte[] privateKey) throws Exception
{