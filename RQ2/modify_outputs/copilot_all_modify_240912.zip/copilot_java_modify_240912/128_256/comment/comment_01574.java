/**
 * Utilized in version 4.4 and above
 * @see "http://blog.csdn.net/tempersitu/article/details/20557383"
 *
 * @param activity
 * @param requestCode
 */
public static void choicePicFromAlbum_kitkat(Activity activity, int requestCode)
{