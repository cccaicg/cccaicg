/**
 * Display a toast based on the alignment.
 * 
 * @param context
 *            The context object
 * @param text
 *            The content to be displayed
 * @param gravity
 *            The alignment style
 */
public static void makeToast(Context context, String text, int gravity)
{