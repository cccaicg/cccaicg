/**
 * Instructs the background thread to terminate and blocks until it completes execution.
 * @throws InterruptedException if the current thread is interrupted while waiting for
 * the background thread to {@link Thread#join()}.
 */
public void stopMonitoring() throws InterruptedException
{