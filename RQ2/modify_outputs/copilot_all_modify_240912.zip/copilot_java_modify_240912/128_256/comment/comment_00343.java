```
// Sourced from the ScrollView code in AOSP
```
private int getScrollRange()
{