/**
 * Assigns the status address for the instance.
 *
 * @param address The status address of the instance.
 * @return The builder of the context.
 */
public Builder setStatusAddress(String address)
{