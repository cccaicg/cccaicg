/**
 * This function can be invoked directly to make the scroll view handle
 * scrolling triggered by a key event, similar to how it would respond if the
 * event were processed by the view hierarchy.
 * 
 * @param event
 *            The key event to process.
 * @return Returns true if the event was managed, otherwise false.
 */
public boolean executeKeyEvent(KeyEvent event)
{