/**
 * Prevent the header from being compressed, which typically results in most of
 * the header being obscured, displaying solely the progress bar.
 */
public Builder noMinimize()
{