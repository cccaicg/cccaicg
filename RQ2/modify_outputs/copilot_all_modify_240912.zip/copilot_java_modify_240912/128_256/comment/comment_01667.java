/** Determine if {@code ErrorListener} was invoked */
public static Callable<Boolean> wasErrorListenerCalled(
		final ErrorResponseHoldListener mock)
{