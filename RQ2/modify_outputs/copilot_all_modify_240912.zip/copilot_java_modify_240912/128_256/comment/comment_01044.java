/**
 * Retrieve the {@link ApplicationDefinition} linked to the "{application}" in this 
 * request. An exception will be raised if the request is not tied to an application command.
 * 
 * @return {@link ApplicationDefinition} affiliated with this request.
 *         Guaranteed to be non-null.
 * @throws NotFoundException if the application specified in this request is undefined.
 */
public ApplicationDefinition getAppDef() throws NotFoundException
{