/**
 * Allocates a buffer for floats using memory independent from the typical garbage-collected heap.
 * 
 * @param capacity		Specifies the number of float elements to initialize in the buffer.
 */
public static FloatBuffer createFloatBuffer(int capacity)
{