/**
 * Convert an encoded string of points into a functional list.
 * 
 * @param encoded
 *            The string from Google that contains the encoded data
 * @return a functional list
 */
public static ArrayList<GeoPoint> decodePolyline(String encoded)
{