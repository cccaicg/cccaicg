/**
 * Converts the remaining content of 'reader' to a string, then closes it.
 */
public static String readFully(Reader reader) throws IOException
{