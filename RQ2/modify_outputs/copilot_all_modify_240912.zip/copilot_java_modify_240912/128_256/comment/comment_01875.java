/**
 * Enables GLSurfaceView to handle the Pause event
 */
@Override
protected void onPause()
{