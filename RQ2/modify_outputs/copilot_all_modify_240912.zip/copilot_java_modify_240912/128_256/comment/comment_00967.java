/**
 * 更新当前线程上的用户界面
 */
private void invalidateView()
{