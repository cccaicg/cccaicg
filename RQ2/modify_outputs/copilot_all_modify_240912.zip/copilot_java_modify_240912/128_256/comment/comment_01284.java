/**
 * Initialize a timer with a designated starting point and duration.
 *
 * @param startTime the starting point for the timer.
 * @param timerLength the duration of the timer.
 */
public TimerObj(long startTime, long timerLength)
{