/**
 *
 * @return The sum of the quantities for all items
 */
@Transient
public int getQuantityTotal()
{