/**
 * Establishes a timed task to terminate the child process of this monitor if it exceeds
 * the data generation time limit. The caller maintains a reference to the provided 
 * object and invokes {@link KillTimerTask#cancel()} after the background task has finished.
 *
 * @param delay the time in milliseconds to wait before terminating the background process
 * @see Timer
 * @return {@link KillTimerTask} object which can be used to cancel the timer.
 */
private KillTimerTask setKillTimer(long delay)
{