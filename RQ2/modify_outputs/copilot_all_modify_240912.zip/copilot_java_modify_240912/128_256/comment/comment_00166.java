/***********************
 * processWindowEvent() handles the event when a window is closed
 * 
 * @param e
 *            The window event to be handled
 * 
 **/
protected void processWindowEvent(WindowEvent e)
{