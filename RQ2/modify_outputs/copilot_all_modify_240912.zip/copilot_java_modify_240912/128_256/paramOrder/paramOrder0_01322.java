// Poor-man's assert(): die with |msg| unless |condition| is true.
private static void abortUnless(String msg, boolean condition)
{