/**
 * 根据对方的公钥和自己的私钥生成本地密钥
 */
public static byte[] getSecretKey(byte[] privateKey, byte[] publicKey) throws Exception
{