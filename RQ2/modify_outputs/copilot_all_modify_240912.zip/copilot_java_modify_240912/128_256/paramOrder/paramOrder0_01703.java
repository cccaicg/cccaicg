/** 
 * Constructor.
 */
public CartesianView(AttributeSet attrs, Context context)
{