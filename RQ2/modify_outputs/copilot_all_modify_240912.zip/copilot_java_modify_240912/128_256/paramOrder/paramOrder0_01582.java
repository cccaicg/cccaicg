/**
 * Initializes a newly allocated line using the specified x and y locations
 * 
 * @param x1 The x coordinate of the start of the line
 * @param x2 The x coordinate of the end of the line
 * @param y1 The y coordinate of the start of the line
 * @param y2 The y coordinate of the end of the line
 */
public PXLine(float x1, float x2, float y1, float y2)
{