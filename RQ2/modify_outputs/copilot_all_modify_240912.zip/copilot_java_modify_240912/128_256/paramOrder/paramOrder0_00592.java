/**
 * 根据方位显示toast
 * 
 * @param text
 *            显示的内容
 * @param context
 *            上下文对象
 * @param gravity
 *            对齐方式
 */
public static void makeToast(String text, Context context, int gravity)
{