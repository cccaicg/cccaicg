/**
 * Constructs a new PXShapeView.
 * 
 * @param defStyle
 * @param context
 * @param attrs
 */
public PXShapeView(int defStyle, Context context, AttributeSet attrs, )
{