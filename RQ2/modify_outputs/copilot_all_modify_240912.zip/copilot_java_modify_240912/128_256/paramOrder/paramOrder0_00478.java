/**
 * Write bytes to output or random access file.
 * @param data the byte array to write
 * @param length the number of bytes to write
 * @throws IOException on error
 * @param offset the start position to write from
 */
protected final void writeOut(byte[] data, int length, int offset)
        throws IOException
{