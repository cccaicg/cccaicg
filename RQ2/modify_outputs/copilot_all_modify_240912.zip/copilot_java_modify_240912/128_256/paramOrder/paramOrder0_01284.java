/**
 * Construct a timer with a specific start time and length.
 *
 * @param timerLength the length of the timer.
 * @param startTime the start time of the timer.
 */
public TimerObj(long timerLength, long startTime)
{