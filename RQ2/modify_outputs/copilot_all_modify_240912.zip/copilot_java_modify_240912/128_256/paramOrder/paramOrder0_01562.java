/**
 * 拍照后获取图片
 *
 * @param activity           
 * @param requestCode
 * @param cameraPhotoFile 照片的文件
 */
public static void choicePicFromCamera(Activity activity, int requestCode, File cameraPhotoFile)
{