/**
 * Sets basic authentication for the request. You should pass in your
 * AuthScope for security. It should be like this
 * setBasicAuth("username","password", new
 * AuthScope("host",port,AuthScope.ANY_REALM))
 *
 * @param scope
 *            - an AuthScope object
 *
 * @param user
 * @param pass
 */
public void setBasicAuth(AuthScope scope, String user, String pass)
{