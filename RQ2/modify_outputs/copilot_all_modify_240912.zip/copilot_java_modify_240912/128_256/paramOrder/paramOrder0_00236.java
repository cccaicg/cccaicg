/**
 * 设置数据和数据类型
 * @param data 数据
 * @param type 类型
 */
public void setDataAndType(ISearchAdapter data, AdapterType type)
{