/**
 * Get the value of the data column for this Uri. This is useful for 
 * MediaStore Uris, and other file-based ContentProviders. 
 *
 * @param uri The Uri to query. 
 * @param context The context. 
 * @param selectionArgs (Optional) Selection arguments used in the query. 
 * @param selection (Optional) Filter used in the query. 
 * @return The value of the _data column, which is typically a file path. 
 */
private static String getDataColumn(Uri uri, Context context, String[] selectionArgs, String selection)
{