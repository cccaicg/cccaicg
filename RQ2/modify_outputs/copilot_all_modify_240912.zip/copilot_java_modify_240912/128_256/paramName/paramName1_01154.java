/**
 * Change a list of points in an Encoded string into a usable list.
 * 
 * @param Encoded
 *            The Encoded string received from google
 * @return a usable list
 */
public static ArrayList<GeoPoint> decodePolyline(String Encoded)
{