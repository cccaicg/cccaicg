// Poor-man's assert(): die with |Msg| unless |Condition| is true.
private static void abortUnless(boolean Condition, String Msg)
{