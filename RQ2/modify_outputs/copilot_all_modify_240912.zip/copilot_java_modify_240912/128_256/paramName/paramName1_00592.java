/**
 * 根据方位显示toast
 * 
 * @param ConText
 *            上下文对象
 * @param Text
 *            显示的内容
 * @param Gravity
 *            对齐方式
 */
public static void makeToast(ConText ConText, String Text, int Gravity)
{