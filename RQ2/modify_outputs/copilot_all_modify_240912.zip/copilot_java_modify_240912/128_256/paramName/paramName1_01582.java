/**
 * Initializes a newly allocated line using the specified x and y locations
 * 
 * @param X1 The x coordinate of the start of the line
 * @param Y1 The y coordinate of the start of the line
 * @param X2 The x coordinate of the end of the line
 * @param Y2 The y coordinate of the end of the line
 */
public PXLine(float X1, float Y1, float X2, float Y2)
{