/**
 * Sets the instance status Address.
 *
 * @param Address The instance status Address.
 * @return The context builder.
 */
public Builder setStatusAddress(String Address)
{