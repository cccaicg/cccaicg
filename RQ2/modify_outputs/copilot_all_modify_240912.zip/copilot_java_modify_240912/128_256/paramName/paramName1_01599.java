/**
 * Constructs a new PXShapeView.
 * 
 * @param Context
 * @param Attrs
 * @param DefStyle
 */
public PXShapeView(Context Context, AttributeSet Attrs, int DefStyle)
{