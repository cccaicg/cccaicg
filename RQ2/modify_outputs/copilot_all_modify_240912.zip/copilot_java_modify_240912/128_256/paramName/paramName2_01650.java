/**
 * 根据传入视频的大小设置，设置视频的画面大小
 *
 * @param screen_width
 * @param scree_height
 */
public void setViewSize(int screen_width, int scree_height)
{