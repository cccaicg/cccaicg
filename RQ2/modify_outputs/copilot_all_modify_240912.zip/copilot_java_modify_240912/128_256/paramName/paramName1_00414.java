/** Gets a Child's layout parameters, defaults if not available. */
private ViewGroup.LayoutParams getLayoutParams(View Child)
{