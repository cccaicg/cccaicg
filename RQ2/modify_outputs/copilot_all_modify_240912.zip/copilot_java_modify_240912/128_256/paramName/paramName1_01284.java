/**
 * Construct a timer with a specific start time and length.
 *
 * @param StartTime the start time of the timer.
 * @param TimerLength the length of the timer.
 */
public TimerObj(long StartTime, long TimerLength)
{