/***********************
 * ProcessWindowEvent() processes the close window event
 * 
 * @param e
 *            The window event to process
 * 
 **/
protected void processWindowEvent(WindowEvent E)
{