/**
 * obtain the image rotation angle
 *
 * @param Path Path of target image
 */
private int getImageSpinAngle(String Path)
{