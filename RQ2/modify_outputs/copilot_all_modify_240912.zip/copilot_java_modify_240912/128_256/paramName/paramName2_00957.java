/**
 * Set touch overlay detection
 *
 * @param touch_overlay The desired overlay touch.
 */
public static BannerTime setTouchOverlay(boolean touch_overlay)
{