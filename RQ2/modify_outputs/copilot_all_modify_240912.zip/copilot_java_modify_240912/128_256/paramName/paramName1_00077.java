/**
 * Sets the instance Number.
 *
 * @param Number The instance Number which should be unique to the component.
 * @return The context builder.
 */
public Builder setNumber(int Number)
{