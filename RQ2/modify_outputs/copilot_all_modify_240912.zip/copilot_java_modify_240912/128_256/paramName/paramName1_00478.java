/**
 * Write bytes to output or random access file.
 * @param Data the byte array to write
 * @param Offset the start position to write from
 * @param Length the number of bytes to write
 * @throws IOException on error
 */
protected final void writeOut(byte[] Data, int Offset, int Length)
        throws IOException
{