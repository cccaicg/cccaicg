/** Check whether {@code ErrorListener} was called or not */
public static Callable<Boolean> wasErrorListenerCalled(
		final ErrorResponseHoldListener Mock)
{