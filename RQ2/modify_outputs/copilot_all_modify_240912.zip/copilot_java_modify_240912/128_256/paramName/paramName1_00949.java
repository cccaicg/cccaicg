/**
 * Set Show Time in milliseconds
 */
public static BannerTime shownTime(int Time)
{