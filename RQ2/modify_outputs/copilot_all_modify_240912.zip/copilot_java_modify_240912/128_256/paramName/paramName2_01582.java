/**
 * Initializes a newly allocated line using the specified x and y locations
 * 
 * @param x_1 The x coordinate of the start of the line
 * @param y_1 The y coordinate of the start of the line
 * @param x_2 The x coordinate of the end of the line
 * @param y_2 The y coordinate of the end of the line
 */
public PXLine(float x_1, float y_1, float x_2, float y_2)
{