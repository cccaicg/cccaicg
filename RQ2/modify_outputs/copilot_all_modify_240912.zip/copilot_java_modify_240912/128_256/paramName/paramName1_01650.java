/**
 * 根据传入视频的大小设置，设置视频的画面大小
 *
 * @param ScreenWidth
 * @param ScreeHeight
 */
public void setViewSize(int ScreenWidth, int ScreeHeight)
{