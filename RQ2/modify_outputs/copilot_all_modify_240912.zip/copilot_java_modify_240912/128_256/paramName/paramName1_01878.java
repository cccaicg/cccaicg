/**
 * Creates a buffer of floats using memory outside the normal, garbage collected heap
 * 
 * @param Capacity		The number of primitives to create in the buffer.
 */
public static FloatBuffer createFloatBuffer(int Capacity)
{