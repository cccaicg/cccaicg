/**
 * 拍照后获取图片
 *
 * @param activity           
 * @param camera_photo_file 照片的文件
 * @param request_code
 */
public static void choicePicFromCamera(Activity activity, File camera_photo_file,int request_code)
{