/**
 * Construct a timer with a specific start time and length.
 *
 * @param start_time the start time of the timer.
 * @param timer_length the length of the timer.
 */
public TimerObj(long start_time, long timer_length)
{