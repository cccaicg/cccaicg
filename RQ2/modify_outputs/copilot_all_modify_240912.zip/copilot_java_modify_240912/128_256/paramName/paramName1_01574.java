/**
 * 4.4以上版本使用
 * @see "http://blog.csdn.net/tempersitu/article/details/20557383"
 * 
 * @param Activity
 * @param RequestCode
 */
public static void choicePicFromAlbum_kitkat(Activity Activity, int RequestCode)
{