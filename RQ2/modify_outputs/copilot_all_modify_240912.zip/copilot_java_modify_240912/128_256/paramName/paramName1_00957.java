/**
 * Set touch overlay detection
 *
 * @param TouchOverlay The desired overlay touch.
 */
public static BannerTime setTouchOverlay(boolean TouchOverlay)
{