/**
 * 设置数据和数据类型
 * @param Type 类型
 * @param Data 数据
 */
public void setDataAndType(AdapterType Type, ISearchAdapter Data)
{