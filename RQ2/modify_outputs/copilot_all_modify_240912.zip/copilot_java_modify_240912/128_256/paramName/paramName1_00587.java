/**
 * Returns the remainder of 'Reader' as a string, closing it when done.
 */
public static String readFully(Reader Reader) throws IOException
{