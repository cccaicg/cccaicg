/**
 * Sets basic authentication for the request. You should Pass in your
 * AuthScope for security. It should be like this
 * setBasicAuth("Username","Password", new
 * AuthScope("host",port,AuthScope.ANY_REALM))
 *
 * @param User
 * @param Pass
 * @param Scope
 *            - an AuthScope object
 *
 */
public void setBasicAuth(String User, String Pass, AuthScope Scope)
{