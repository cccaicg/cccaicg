/**
 * Enable or disable to add a node.
 * 
 * @param Enabled
 */
private void setEnableAddNode( final boolean Enabled )
{