/**
 * 查找指定节点的中序遍历序列的直接后继节点，此方法的实现与二叉搜索树类（BinSearchTree.java）的此方法是
 * 一样的，具体的思路请参考二叉搜索树类中的相应方法
 *
 * @param E 需要查找哪个节点的直接后继节点
 * @return Entry<E> 直接后继节点
 */
private Entry<E> successor(Entry<E> E)
{