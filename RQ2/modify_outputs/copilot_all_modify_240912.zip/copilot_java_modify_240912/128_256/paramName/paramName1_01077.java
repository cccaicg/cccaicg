/**
 * ----------------------------------------
 * Open External URL
 * ----------------------------------------
 */
@JavascriptInterface
public void openExternalUrl(String Url)
{