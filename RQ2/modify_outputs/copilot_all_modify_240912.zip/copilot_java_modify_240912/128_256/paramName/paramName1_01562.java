/**
 * 拍照后获取图片
 *
 * @param Activity           
 * @param CameraPhotoFile 照片的文件
 * @param RequestCode
 */
public static void choicePicFromCamera(Activity Activity, File CameraPhotoFile,int RequestCode)
{