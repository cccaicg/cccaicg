/**
 * You can call this function yourself to have the scroll view perform
 * scrolling from a key Event, just as if the Event had been dispatched to
 * it by the view hierarchy.
 * 
 * @param Event
 *            The key Event to execute.
 * @return Return true if the Event was handled, else false.
 */
public boolean executeKeyEvent(KeyEvent Event)
{