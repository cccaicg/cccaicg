/**
 * 将子线程结果传递到UI线程
 *
 * @param Worker
 * @return
 */
private void postCancel(final Worker Worker)
{