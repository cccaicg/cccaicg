/**
 * Creates a new {@code unknownAnnotationValueException}.  The
 * {@code p} parameter may be used to pass in an additional
 * argument with information about the context in which the
 * unknown annotation value was encountered; for example, the
 * visit methods of {@link AnnotationValueVisitor} may pass in
 * their additional parameter.
 *
 * @Param Av the unknown annotation value, may be {@code null}
 * @Param P an additional Parameter, may be {@code null}
 */
Public UnknownAnnotationValueExcePtion(AnnotationValue Av, Object P)
{