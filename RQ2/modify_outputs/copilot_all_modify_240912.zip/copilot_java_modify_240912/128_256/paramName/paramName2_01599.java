/**
 * Constructs a new PXShapeView.
 * 
 * @param context
 * @param attrs
 * @param def_style
 */
public PXShapeView(Context context, AttributeSet attrs, int def_style)
{